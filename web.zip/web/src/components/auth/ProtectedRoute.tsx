'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/hooks/useAuth';
import { usePermissions } from '@/hooks/usePermissions';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requireAdmin?: boolean;
  requireUser?: boolean;
}

/**
 * 权限路由守卫组件
 * - requireAdmin: 只允许管理员访问
 * - requireUser: 只允许普通用户访问
 */
export function ProtectedRoute({ children, requireAdmin = false, requireUser = false }: ProtectedRouteProps) {
  const router = useRouter();
  const { user, isAuthenticated, isInitialized } = useAuth();
  const { loadPermissions, permissions, isAdmin } = usePermissions();

  useEffect(() => {
    // 加载权限数据
    if (isAuthenticated && !permissions) {
      loadPermissions();
    }
  }, [isAuthenticated, permissions, loadPermissions]);

  useEffect(() => {
    if (!isInitialized) return;

    // 未认证，跳转登录
    if (!isAuthenticated) {
      router.push('/login');
      return;
    }

    // 等待权限加载
    if (!permissions) return;

    // 需要管理员权限但用户不是管理员
    if (requireAdmin && !isAdmin()) {
      router.push('/dashboard');
      return;
    }

    // 需要普通用户权限但用户是管理员
    if (requireUser && isAdmin()) {
      router.push('/admin/dashboard');
      return;
    }
  }, [isInitialized, isAuthenticated, permissions, requireAdmin, requireUser, router, isAdmin]);

  // 加载中或权限检查未完成
  if (!isInitialized || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在验证权限...</p>
        </div>
      </div>
    );
  }

  // 权限不足
  if (requireAdmin && permissions && !isAdmin()) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="text-6xl mb-4">🚫</div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">权限不足</h2>
          <p className="text-gray-600 mb-4">您没有权限访问此页面</p>
          <button
            onClick={() => router.push('/dashboard')}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            返回首页
          </button>
        </div>
      </div>
    );
  }

  if (requireUser && permissions && isAdmin()) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="text-6xl mb-4">👑</div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">管理员账号</h2>
          <p className="text-gray-600 mb-4">请访问管理员专属页面</p>
          <button
            onClick={() => router.push('/admin/dashboard')}
            className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
          >
            前往管理员面板
          </button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}

