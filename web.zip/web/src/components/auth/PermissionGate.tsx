/**
 * 权限控制组件
 * 根据用户权限显示或隐藏内容
 */

'use client';

import { useEffect, ReactNode } from 'react';
import { usePermissions } from '@/hooks/usePermissions';
import { useAuth } from '@/hooks/useAuth';

interface PermissionGateProps {
  children: ReactNode;
  resource: string;
  action: string;
  fallback?: ReactNode;
}

/**
 * 权限门禁组件
 * 只有具备指定权限的用户才能看到子组件
 * 
 * @example
 * <PermissionGate resource="user" action="delete">
 *   <button>删除用户</button>
 * </PermissionGate>
 */
export function PermissionGate({ children, resource, action, fallback = null }: PermissionGateProps) {
  const { hasPermission, loadPermissions, permissions } = usePermissions();
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    if (isAuthenticated && !permissions) {
      loadPermissions();
    }
  }, [isAuthenticated, permissions, loadPermissions]);

  if (!isAuthenticated) {
    return <>{fallback}</>;
  }

  if (!permissions) {
    return <>{fallback}</>;
  }

  if (!hasPermission(resource, action)) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
}

interface AdminOnlyProps {
  children: ReactNode;
  fallback?: ReactNode;
}

/**
 * 仅管理员可见组件
 * 
 * @example
 * <AdminOnly>
 *   <button>管理员操作</button>
 * </AdminOnly>
 */
export function AdminOnly({ children, fallback = null }: AdminOnlyProps) {
  const { isAdmin, loadPermissions, permissions } = usePermissions();
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    if (isAuthenticated && !permissions) {
      loadPermissions();
    }
  }, [isAuthenticated, permissions, loadPermissions]);

  if (!isAuthenticated || !isAdmin()) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
}

interface RequirePermissionsProps {
  children: ReactNode;
  permissions: Array<{ resource: string; action: string }>;
  requireAll?: boolean; // true: 需要所有权限, false: 只需一个权限
  fallback?: ReactNode;
}

/**
 * 多权限检查组件
 * 
 * @example
 * // 需要所有权限
 * <RequirePermissions 
 *   permissions={[
 *     { resource: 'user', action: 'read' },
 *     { resource: 'user', action: 'write' }
 *   ]} 
 *   requireAll
 * >
 *   <button>编辑用户</button>
 * </RequirePermissions>
 * 
 * // 只需一个权限
 * <RequirePermissions 
 *   permissions={[
 *     { resource: 'tunnel', action: 'update' },
 *     { resource: 'tunnel', action: 'update_own' }
 *   ]}
 * >
 *   <button>编辑隧道</button>
 * </RequirePermissions>
 */
export function RequirePermissions({ 
  children, 
  permissions: requiredPermissions, 
  requireAll = false,
  fallback = null 
}: RequirePermissionsProps) {
  const { hasPermission, loadPermissions, permissions } = usePermissions();
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    if (isAuthenticated && !permissions) {
      loadPermissions();
    }
  }, [isAuthenticated, permissions, loadPermissions]);

  if (!isAuthenticated || !permissions) {
    return <>{fallback}</>;
  }

  const hasRequiredPermissions = requireAll
    ? requiredPermissions.every(p => hasPermission(p.resource, p.action))
    : requiredPermissions.some(p => hasPermission(p.resource, p.action));

  if (!hasRequiredPermissions) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
}

