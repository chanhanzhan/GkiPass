/**
 * 提示框组件
 */

interface AlertProps {
  type: 'info' | 'success' | 'warning' | 'error';
  title?: string;
  message: string;
  onClose?: () => void;
}

export function Alert({ type, title, message, onClose }: AlertProps) {
  const styles = {
    info: {
      container: 'bg-blue-50 border-blue-200',
      icon: 'ℹ️',
      title: 'text-blue-800',
      message: 'text-blue-700',
    },
    success: {
      container: 'bg-green-50 border-green-200',
      icon: '✅',
      title: 'text-green-800',
      message: 'text-green-700',
    },
    warning: {
      container: 'bg-yellow-50 border-yellow-200',
      icon: '⚠️',
      title: 'text-yellow-800',
      message: 'text-yellow-700',
    },
    error: {
      container: 'bg-red-50 border-red-200',
      icon: '❌',
      title: 'text-red-800',
      message: 'text-red-700',
    },
  };

  const style = styles[type];

  return (
    <div className={`border rounded-lg p-4 ${style.container}`}>
      <div className="flex items-start">
        <span className="text-2xl mr-3">{style.icon}</span>
        <div className="flex-1">
          {title && (
            <h3 className={`text-sm font-medium mb-1 ${style.title}`}>{title}</h3>
          )}
          <p className={`text-sm ${style.message}`}>{message}</p>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className={`ml-3 ${style.title} hover:opacity-75`}
          >
            ✕
          </button>
        )}
      </div>
    </div>
  );
}






