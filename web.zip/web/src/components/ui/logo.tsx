"use client"

import { cn } from "@/lib/utils"

interface LogoProps {
  className?: string
  size?: "sm" | "md" | "lg"
  variant?: "light" | "dark" | "gradient"
}

export function Logo({ className, size = "md", variant = "gradient" }: LogoProps) {
  const sizeClasses = {
    sm: "h-6 w-6 text-sm",
    md: "h-8 w-8 text-base", 
    lg: "h-12 w-12 text-2xl"
  }

  const variantClasses = {
    light: "text-foreground",
    dark: "text-background",
    gradient: "text-foreground"
  }

  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div className={cn(
        "rounded-lg flex items-center justify-center font-bold",
        sizeClasses[size],
        variant === "gradient" 
          ? "bg-primary text-primary-foreground" 
          : "bg-muted text-muted-foreground"
      )}>
        ⚡
      </div>
      <span className={cn(
        "font-black tracking-tight",
        size === "sm" ? "text-lg" : size === "md" ? "text-xl" : "text-3xl",
        variantClasses[variant]
      )}>
        RelayX
      </span>
    </div>
  )
}

export function LogoMark({ className, size = "md" }: { className?: string, size?: "sm" | "md" | "lg" }) {
  const sizeClasses = {
    sm: "h-6 w-6 text-sm",
    md: "h-8 w-8 text-base", 
    lg: "h-12 w-12 text-2xl"
  }

  return (
    <div className={cn(
      "rounded-lg bg-primary text-primary-foreground flex items-center justify-center font-bold",
      sizeClasses[size],
      className
    )}>
      ⚡
    </div>
  )
}
