'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';

interface CaptchaProps {
  onChange: (code: string, captchaId: string) => void;
  className?: string;
}

export function ImageCaptcha({ onChange, className = '' }: CaptchaProps) {
  const [captchaId, setCaptchaId] = useState('');
  const [imageData, setImageData] = useState('');
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);

  const refreshCaptcha = async () => {
    setLoading(true);
    try {
      const result = await api.captcha.getImage();
      setCaptchaId(result.captcha_id);
      setImageData(result.image_data);
      setCode('');
      onChange('', result.captcha_id);
    } catch (error) {
      console.error('Failed to load captcha:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshCaptcha();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleCodeChange = (value: string) => {
    setCode(value);
    onChange(value, captchaId);
  };

  return (
    <div className={`space-y-3 ${className}`}>
      <label className="block text-sm font-bold text-gray-700 flex items-center gap-2">
        <span className="text-xl">🔢</span>
        <span>验证码</span>
      </label>
      <div className="flex gap-3">
        <input
          type="text"
          value={code}
          onChange={(e) => handleCodeChange(e.target.value)}
          placeholder="请输入验证码"
          className="flex-1 px-5 py-4 bg-gradient-to-r from-cyan-50 to-blue-50 border-2 border-cyan-300 focus:border-cyan-500 rounded-2xl text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-4 focus:ring-cyan-200 transition-all font-medium shadow-lg"
          maxLength={6}
          autoComplete="off"
        />
        <button
          type="button"
          onClick={refreshCaptcha}
          disabled={loading}
          className="px-5 py-4 bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 text-white rounded-2xl shadow-lg hover:shadow-xl transition-all disabled:opacity-50 font-bold text-lg"
          title="刷新验证码"
        >
          {loading ? '...' : '🔄'}
        </button>
      </div>
      {imageData && (
        <div className="flex justify-center bg-white/90 rounded-2xl p-3 shadow-inner border-2 border-cyan-200">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={imageData}
            alt="验证码"
            className="h-20 w-auto cursor-pointer hover:scale-105 transition-transform"
            onClick={refreshCaptcha}
            title="点击刷新"
          />
        </div>
      )}
    </div>
  );
}

