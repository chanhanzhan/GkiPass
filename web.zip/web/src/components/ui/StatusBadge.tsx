/**
 * 状态徽章组件
 */

import { cn } from '@/lib/utils';

interface StatusBadgeProps {
  status: string;
  label: string;
}

export function StatusBadge({ status, label }: StatusBadgeProps) {
  const getColorClass = (status: string) => {
    const colors: Record<string, string> = {
      online: 'bg-green-100 text-green-800',
      offline: 'bg-gray-100 text-gray-800',
      active: 'bg-green-100 text-green-800',
      disabled: 'bg-red-100 text-red-800',
      enabled: 'bg-green-100 text-green-800',
      expired: 'bg-red-100 text-red-800',
      published: 'bg-green-100 text-green-800',
      draft: 'bg-gray-100 text-gray-800',
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  return (
    <span className={cn('px-2 py-1 text-xs font-medium rounded', getColorClass(status))}>
      {label}
    </span>
  );
}






