"use client"

import { useState, useEffect, useRef, ReactNode } from 'react'

interface LazyLoadProps {
  children: ReactNode
  height?: string
  threshold?: number
  placeholder?: ReactNode
  className?: string
}

export function LazyLoad({ 
  children, 
  height = '200px',
  threshold = 0.1,
  placeholder,
  className 
}: LazyLoadProps) {
  const [isVisible, setIsVisible] = useState(false)
  const [hasLoaded, setHasLoaded] = useState(false)
  const elementRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          setHasLoaded(true)
          observer.disconnect()
        }
      },
      { threshold }
    )

    if (elementRef.current) {
      observer.observe(elementRef.current)
    }

    return () => observer.disconnect()
  }, [threshold])

  return (
    <div 
      ref={elementRef}
      className={className}
      style={{ minHeight: hasLoaded ? 'auto' : height }}
    >
      {isVisible ? (
        children
      ) : (
        placeholder || (
          <div 
            className="flex items-center justify-center bg-muted/30 rounded-lg animate-pulse"
            style={{ height }}
          >
            <div className="text-muted-foreground text-sm">正在加载...</div>
          </div>
        )
      )}
    </div>
  )
}

// 图片懒加载组件
interface LazyImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string
  alt: string
  placeholder?: string
  blurDataURL?: string
}

export function LazyImage({ 
  src, 
  alt, 
  placeholder = '/placeholder.jpg',
  blurDataURL,
  className,
  ...props 
}: LazyImageProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [hasError, setHasError] = useState(false)
  const [isVisible, setIsVisible] = useState(false)
  const imgRef = useRef<HTMLImageElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.disconnect()
        }
      },
      { threshold: 0.1 }
    )

    if (imgRef.current) {
      observer.observe(imgRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <div 
      ref={imgRef}
      className={`relative overflow-hidden ${className}`}
      {...props}
    >
      {isVisible && (
        <>
          <img
            src={hasError ? placeholder : src}
            alt={alt}
            onLoad={() => setIsLoading(false)}
            onError={() => {
              setHasError(true)
              setIsLoading(false)
            }}
            className={`transition-opacity duration-300 ${
              isLoading ? 'opacity-0' : 'opacity-100'
            }`}
          />
          {isLoading && (
            <div className="absolute inset-0 bg-muted animate-pulse flex items-center justify-center">
              <div className="text-muted-foreground text-xs">加载中...</div>
            </div>
          )}
        </>
      )}
    </div>
  )
}
