"use client"

import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

interface QuotaCardProps {
  title: string
  used: number
  max: number
  formatter?: (value: number) => string
  unit?: string
  icon: React.ReactNode
  color?: 'blue' | 'green' | 'purple' | 'red' | 'relay' | 'tunnel'
  className?: string
}

export function QuotaCard({
  title,
  used,
  max,
  formatter = (v: number) => v.toString(),
  unit = '',
  icon,
  color = 'blue',
  className
}: QuotaCardProps) {
  const percentage = max > 0 ? Math.min((used / max) * 100, 100) : 0

  const colorClasses = {
    blue: {
      gradient: 'bg-blue-600',
      bg: 'from-blue-50 to-blue-100',
      text: 'text-blue-600',
      border: 'border-blue-200',
    },
    green: {
      gradient: 'bg-green-600',
      bg: 'from-green-50 to-green-100',
      text: 'text-green-600',
      border: 'border-green-200',
    },
    purple: {
      gradient: 'bg-purple-600',
      bg: 'from-purple-50 to-purple-100',
      text: 'text-purple-600',
      border: 'border-purple-200',
    },
    red: {
      gradient: 'bg-red-600',
      bg: 'from-red-50 to-red-100',
      text: 'text-red-600',
      border: 'border-red-200',
    },
    relay: {
      gradient: 'bg-slate-600',
      bg: 'from-slate-50 to-slate-100',
      text: 'text-slate-600',
      border: 'border-slate-200',
    },
    tunnel: {
      gradient: 'bg-stone-600',
      bg: 'from-stone-50 to-stone-100',
      text: 'text-stone-600',
      border: 'border-stone-200',
    },
  }

  const colors = colorClasses[color]

  return (
    <Card className={cn("bg-card border-border p-6", className)}>
      <div className="text-center space-y-3">
        <div className="text-3xl font-bold text-foreground">
          {formatter(used)}{unit}
        </div>
        <div className="text-sm text-muted-foreground">{title}</div>
        
        <div className="w-full bg-muted rounded-full h-2">
          <div
            className={cn("h-2 rounded-full transition-all duration-500", colors.gradient)}
            style={{ width: `${Math.min(percentage, 100)}%` }}
          />
        </div>
        
        <div className="flex items-center justify-center gap-2 text-xs">
          <span className="text-muted-foreground">
            {percentage.toFixed(1)}% 已使用
          </span>
          {percentage > 90 && (
            <Badge variant="error" className="text-xs">
              ⚠️ 接近限额
            </Badge>
          )}
        </div>
      </div>
    </Card>
  )
}
