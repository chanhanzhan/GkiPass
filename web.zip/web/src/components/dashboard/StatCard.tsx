"use client"

import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

interface StatCardProps {
  title: string
  value: string | number
  change?: {
    value: number
    type: 'increase' | 'decrease' | 'neutral'
  }
  icon: React.ReactNode
  color?: 'blue' | 'green' | 'purple' | 'red' | 'relay' | 'tunnel'
  description?: string
  className?: string
}

export function StatCard({ 
  title, 
  value, 
  change,
  icon, 
  color = 'blue', 
  description,
  className 
}: StatCardProps) {
  const colorClasses = {
    blue: 'from-blue-50 to-blue-100 text-blue-600 border-blue-200',
    green: 'from-green-50 to-green-100 text-green-600 border-green-200',
    purple: 'from-purple-50 to-purple-100 text-purple-600 border-purple-200',
    red: 'from-red-50 to-red-100 text-red-600 border-red-200',
    relay: 'from-relay-50 to-relay-100 text-relay-600 border-relay-200',
    tunnel: 'from-tunnel-50 to-tunnel-100 text-tunnel-600 border-tunnel-200',
  }

  return (
    <Card className={cn("hover:shadow-lg transition-all duration-200", className)}>
      <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between space-y-2 sm:space-y-0 pb-2">
        <div className="text-sm font-medium text-muted-foreground">{title}</div>
        <div className={cn(
          "p-2 rounded-lg bg-gradient-to-br self-start sm:self-auto",
          colorClasses[color]
        )}>
          {icon}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-1">
          <div className="text-xl sm:text-2xl font-bold">{value}</div>
          {change && (
            <div className="flex items-center space-x-1">
              <Badge variant={
                change.type === 'increase' ? 'success' : 
                change.type === 'decrease' ? 'error' : 'secondary'
              }>
                {change.type === 'increase' && '↑'}
                {change.type === 'decrease' && '↓'}
                {change.type === 'neutral' && '→'}
                {Math.abs(change.value)}%
              </Badge>
              {description && (
                <p className="text-xs text-muted-foreground">{description}</p>
              )}
            </div>
          )}
          {description && !change && (
            <p className="text-xs text-muted-foreground">{description}</p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
