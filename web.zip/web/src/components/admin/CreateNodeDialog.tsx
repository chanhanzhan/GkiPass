"use client"

import { useState, useEffect } from "react"
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { useToast } from "@/components/ui/Toast"
import { api } from "@/lib/api"
import { 
  ServerIcon, 
  Plus, 
  Network,
  MapPin,
  Hash,
  Info,
  Copy,
  Terminal
} from "lucide-react"

interface NodeGroup {
  id: string
  name: string
  type: 'entry' | 'exit'
  node_count?: number
}

interface CreateNodeDialogProps {
  onNodeCreated: () => void
  nodeGroups: NodeGroup[]
  trigger?: React.ReactNode
}

interface ConnectionKeyModalProps {
  isOpen: boolean
  onClose: () => void
  nodeId: string
  connectionKey: string
  nodeName: string
}

function ConnectionKeyModal({ isOpen, onClose, nodeId, connectionKey, nodeName }: ConnectionKeyModalProps) {
  const handleCopy = () => {
    navigator.clipboard.writeText(connectionKey)
    // 可以添加toast提示
  }

  if (!isOpen) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Hash className="w-5 h-5" />
            节点 Connection Key
          </DialogTitle>
          <DialogDescription>
            为节点 &ldquo;{nodeName}&rdquo; 生成的连接密钥
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Info className="w-4 h-4 text-yellow-600" />
              <span className="text-sm font-medium text-yellow-800">重要提示</span>
            </div>
            <p className="text-sm text-yellow-700">
              Connection Key 仅显示一次，请妥善保存！丢失后需要重新生成。
            </p>
          </div>

          <div className="space-y-2">
            <Label>Connection Key</Label>
            <div className="flex items-center gap-2">
              <code className="flex-1 text-sm bg-muted p-3 rounded-lg font-mono break-all">
                {connectionKey}
              </code>
              <Button variant="outline" size="sm" onClick={handleCopy}>
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Terminal className="w-4 h-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-800">启动命令</span>
              </div>
              <code className="text-sm text-blue-900 bg-white p-2 rounded block">
                curl -sSL http://dl.relayx.cc/install.sh | bash -s --- -s http://localhost:3001 -t {connectionKey.substring(0, 20)}...
              </code>
            </CardContent>
          </Card>
        </div>

        <DialogFooter>
          <Button onClick={onClose} variant="admin">
            我已保存密钥
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

export function CreateNodeDialog({ onNodeCreated, nodeGroups, trigger }: CreateNodeDialogProps) {
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [showCK, setShowCK] = useState<{ nodeId: string; ck: string; nodeName: string } | null>(null)
  const { showToast } = useToast()
  const [formData, setFormData] = useState({
    name: '',
    type: 'entry' as 'entry' | 'exit',
    group_id: '',
    ip: '',
    port: '9443',
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.name || !formData.group_id || !formData.ip || !formData.port) {
      showToast('error', '请填写完整信息')
      return
    }

    // IP地址验证
    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/
    if (!ipRegex.test(formData.ip)) {
      showToast('error', '请输入有效的IP地址')
      return
    }

    // 端口验证
    const port = parseInt(formData.port)
    if (port < 1 || port > 65535) {
      showToast('error', '端口范围应在1-65535之间')
      return
    }

    setLoading(true)
    try {
      const result = await api.nodes.create({
        name: formData.name,
        type: formData.type,
        group_id: formData.group_id,
        ip: formData.ip,
        port: port,
      })

      // 显示生成的 Connection Key
      if (result.connection_key) {
        setShowCK({ 
          nodeId: result.id, 
          ck: result.connection_key,
          nodeName: formData.name 
        })
      }

      showToast('success', '节点创建成功')
      setOpen(false)
      setFormData({
        name: '',
        type: 'entry',
        group_id: '',
        ip: '',
        port: '9443',
      })
      onNodeCreated()
    } catch (error: unknown) {
      showToast('error', (error as { data?: { error?: string } }).data?.error || '创建失败')
    } finally {
      setLoading(false)
    }
  }

  const filteredGroups = nodeGroups.filter(g => g.type === formData.type)

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          {trigger || (
            <Button variant="admin">
              <Plus className="w-4 h-4 mr-2" />
              创建节点
            </Button>
          )}
        </DialogTrigger>
      <DialogContent className="max-w-2xl bg-card border-border">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle className="text-foreground">创建新节点</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              RelayX 系统添加新的网络节点
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-foreground">节点名称 *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="claude"
                className="bg-muted border-border text-foreground"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="type" className="text-foreground">节点类型 *</Label>
                <Select value={formData.type} onValueChange={(value: 'entry' | 'exit') => setFormData({ ...formData, type: value, group_id: '' })}>
                  <SelectTrigger className="bg-muted border-border text-foreground">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    <SelectItem value="entry">入口节点</SelectItem>
                    <SelectItem value="exit">出口节点</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="group_id" className="text-foreground">节点组 *</Label>
                <Select value={formData.group_id} onValueChange={(value) => setFormData({ ...formData, group_id: value })}>
                  <SelectTrigger className="bg-muted border-border text-foreground">
                    <SelectValue placeholder="选择节点组" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {filteredGroups.map((group) => (
                      <SelectItem key={group.id} value={group.id}>
                        {group.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="ip" className="text-foreground">IP 地址 *</Label>
              <Input
                id="ip"
                value={formData.ip}
                onChange={(e) => setFormData({ ...formData, ip: e.target.value })}
                placeholder="192.168.1.237"
                className="bg-muted border-border text-foreground font-mono"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="port" className="text-foreground">端口 *</Label>
                <Input
                  id="port"
                  type="number"
                  min="1"
                  max="65535"
                  value={formData.port}
                  onChange={(e) => setFormData({ ...formData, port: e.target.value })}
                  className="bg-muted border-border text-foreground font-mono"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="port" className="text-foreground">端口</Label>
                <Input
                  value="9443"
                  className="bg-muted border-border text-foreground font-mono"
                  disabled
                />
              </div>
            </div>

            <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg">
              <div className="flex items-center gap-2 mb-1">
                <Info className="w-4 h-4 text-amber-500" />
                <span className="text-sm font-medium text-amber-200">创建说明</span>
              </div>
              <p className="text-sm text-amber-100">
                创建成功后将自动生成 UUID 和 Connection Key，请妥善保存用于节点部署。
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              取消
            </Button>
            <Button type="submit" variant="default" disabled={loading}>
              {loading ? '创建中...' : '创建节点'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
      </Dialog>

      {/* Connection Key 显示 */}
      <ConnectionKeyModal
        isOpen={!!showCK}
        onClose={() => setShowCK(null)}
        nodeId={showCK?.nodeId || ''}
        connectionKey={showCK?.ck || ''}
        nodeName={showCK?.nodeName || ''}
      />
    </>
  )
}
