"use client"

import { useState } from "react"
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { useToast } from "@/components/ui/Toast"
import { api } from "@/lib/api"
import { 
  Bell, 
  Calendar, 
  Flag,
  Type,
  FileText,
  AlertTriangle
} from "lucide-react"

interface Announcement {
  id: string;
  title: string;
  content: string;
  type: 'notice' | 'maintenance' | 'update' | 'warning';
  priority: 'low' | 'normal' | 'high';
  enabled: boolean;
  start_time: string;
  end_time: string;
  created_at: string;
}

interface CreateAnnouncementDialogProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
  editingAnnouncement?: Announcement | null
}

export function CreateAnnouncementDialog({ 
  isOpen, 
  onClose, 
  onSuccess, 
  editingAnnouncement 
}: CreateAnnouncementDialogProps) {
  const [loading, setLoading] = useState(false)
  const { showToast } = useToast()
  const [formData, setFormData] = useState({
    title: editingAnnouncement?.title || '',
    content: editingAnnouncement?.content || '',
    type: (editingAnnouncement?.type as 'notice' | 'maintenance' | 'update' | 'warning') || 'notice',
    priority: (editingAnnouncement?.priority as 'low' | 'normal' | 'high') || 'normal',
    enabled: editingAnnouncement?.enabled ?? true,
    start_time: editingAnnouncement 
      ? new Date(editingAnnouncement.start_time).toISOString().slice(0, 16)
      : new Date().toISOString().slice(0, 16),
    end_time: editingAnnouncement
      ? new Date(editingAnnouncement.end_time).toISOString().slice(0, 16)
      : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 16),
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.title || !formData.content) {
      showToast('error', '请填写标题和内容')
      return
    }

    if (new Date(formData.start_time) >= new Date(formData.end_time)) {
      showToast('error', '结束时间必须晚于开始时间')
      return
    }

    setLoading(true)
    try {
      const data = {
        ...formData,
        start_time: new Date(formData.start_time).toISOString(),
        end_time: new Date(formData.end_time).toISOString(),
      }

      if (editingAnnouncement) {
        await api.announcements.update(editingAnnouncement.id, data)
        showToast('success', '公告已更新')
      } else {
        await api.announcements.create(data)
        showToast('success', '公告已创建')
      }

      onClose()
      onSuccess()
    } catch (error: unknown) {
      showToast('error', (error as { data?: { error?: string } }).data?.error || '操作失败')
    } finally {
      setLoading(false)
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'maintenance': return '🔧'
      case 'update': return '🚀'
      case 'warning': return '⚠️'
      default: return '📢'
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600'
      case 'low': return 'text-gray-600'
      default: return 'text-blue-600'
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" />
              {editingAnnouncement ? '编辑公告' : '创建公告'}
            </DialogTitle>
            <DialogDescription>
              {editingAnnouncement 
                ? '修改系统公告信息和显示设置' 
                : '为 RelayX 系统创建新的公告通知'
              }
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            <div className="space-y-2">
              <Label htmlFor="title" className="flex items-center gap-2">
                <Type className="w-4 h-4" />
                公告标题 *
              </Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="输入公告标题"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="content" className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                公告内容 *
              </Label>
              <textarea
                id="content"
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                className="w-full min-h-32 px-3 py-2 border border-input rounded-md text-sm resize-none focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                placeholder="输入公告内容，支持 Markdown 格式"
                required
              />
              <p className="text-xs text-muted-foreground">
                支持 Markdown 语法，如 **粗体**、*斜体*、[链接](url) 等
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Flag className="w-4 h-4" />
                  公告类型
                </Label>
                <Select 
                  value={formData.type} 
                  onValueChange={(value: 'notice' | 'maintenance' | 'update' | 'warning') => 
                    setFormData({ ...formData, type: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="notice">
                      <div className="flex items-center gap-2">
                        <span>📢</span>
                        <span>通知公告</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="maintenance">
                      <div className="flex items-center gap-2">
                        <span>🔧</span>
                        <span>维护通知</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="update">
                      <div className="flex items-center gap-2">
                        <span>🚀</span>
                        <span>功能更新</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="warning">
                      <div className="flex items-center gap-2">
                        <span>⚠️</span>
                        <span>重要警告</span>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>优先级</Label>
                <Select 
                  value={formData.priority} 
                  onValueChange={(value: 'low' | 'normal' | 'high') => 
                    setFormData({ ...formData, priority: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">
                      <span className="text-gray-600">低优先级</span>
                    </SelectItem>
                    <SelectItem value="normal">
                      <span className="text-blue-600">普通</span>
                    </SelectItem>
                    <SelectItem value="high">
                      <span className="text-red-600">⭐ 高优先级</span>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="start_time" className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  开始时间
                </Label>
                <Input
                  id="start_time"
                  type="datetime-local"
                  value={formData.start_time}
                  onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="end_time">结束时间</Label>
                <Input
                  id="end_time"
                  type="datetime-local"
                  value={formData.end_time}
                  onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <input
                id="enabled"
                type="checkbox"
                checked={formData.enabled}
                onChange={(e) => setFormData({ ...formData, enabled: e.target.checked })}
                className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
              />
              <Label htmlFor="enabled">立即启用此公告</Label>
            </div>

            {/* 预览区域 */}
            <Card className="bg-muted/50">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-lg">{getTypeIcon(formData.type)}</span>
                  <span className="font-medium">预览效果</span>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold">{formData.title || '公告标题'}</h4>
                  <p className="text-sm text-muted-foreground">
                    {formData.content || '公告内容将在这里显示...'}
                  </p>
                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-medium ${getPriorityColor(formData.priority)}`}>
                      {formData.priority === 'high' ? '⭐ 高优先级' : 
                       formData.priority === 'low' ? '普通' : '正常'}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {new Date(formData.start_time).toLocaleDateString()} - {new Date(formData.end_time).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              取消
            </Button>
            <Button type="submit" variant="admin" disabled={loading}>
              {loading ? '处理中...' : (editingAnnouncement ? '更新公告' : '创建公告')}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
