"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { formatBytes, formatDate, getProtocolText } from "@/lib/utils"
import { 
  Activity, 
  User, 
  Network,
  Target,
  TrendingUp,
  ToggleLeft,
  ToggleRight,
  Eye
} from "lucide-react"
import Link from "next/link"

interface TunnelMonitorCardProps {
  tunnel: {
    id: string
    name: string
    enabled: boolean
    traffic_in: number
    traffic_out: number
    protocol: string
    status: string
    entry_group_id?: string
    exit_group_id?: string
    entry_group?: { name: string }
    exit_group?: { name: string }
    targets?: Array<{ [key: string]: unknown }>
    connections?: number
    description?: string
    [key: string]: unknown
  }
  user: {
    id: string
    username: string
    email?: string
    [key: string]: unknown
  }
  onToggle?: (tunnelId: string, currentStatus: boolean) => void
  className?: string
}

export function TunnelMonitorCard({ tunnel, user, onToggle, className }: TunnelMonitorCardProps) {
  const totalTraffic = (tunnel.traffic_in || 0) + (tunnel.traffic_out || 0)
  const isEnabled = tunnel.enabled
  
  return (
    <Card className={className}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg">{tunnel.name}</CardTitle>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="outline">
                {getProtocolText(tunnel.protocol)}
              </Badge>
              <Badge variant={isEnabled ? 'success' : 'secondary'}>
                {isEnabled ? '运行中' : '已停止'}
              </Badge>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onToggle?.(tunnel.id, isEnabled)}
            >
              {isEnabled ? (
                <ToggleRight className="w-4 h-4" />
              ) : (
                <ToggleLeft className="w-4 h-4" />
              )}
            </Button>
            <Button variant="outline" size="sm" asChild>
              <Link href={`/tunnels/${tunnel.id}`}>
                <Eye className="w-4 h-4" />
              </Link>
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* 用户信息 */}
        <div className="flex items-center gap-2 text-sm">
          <User className="w-4 h-4 text-muted-foreground" />
          <span className="font-medium">{user?.username || '未知用户'}</span>
          <span className="text-muted-foreground">({user?.email || '-'})</span>
        </div>

        {/* 节点组信息 */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-1">
            <Network className="w-3 h-3 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">入口:</span>
            <span className="font-medium">{tunnel.entry_group?.name || tunnel.entry_group_id || ''}</span>
          </div>
          <div className="flex items-center gap-1">
            <Target className="w-3 h-3 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">出口:</span>
            <span className="font-medium">{tunnel.exit_group?.name || tunnel.exit_group_id || ''}</span>
          </div>
        </div>

        {/* 流量统计 */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1">
              <TrendingUp className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-medium">流量使用</span>
            </div>
            <span className="font-mono font-medium">{formatBytes(totalTraffic)}</span>
          </div>
          
          {tunnel.targets && tunnel.targets.length > 0 && (
            <div className="text-xs text-muted-foreground">
              {tunnel.targets.length} 个转发目标 • 活跃连接: {tunnel.connections || 0}
            </div>
          )}
        </div>

        {/* 描述信息 */}
        {tunnel.description && (
          <div className="text-sm text-muted-foreground bg-muted/50 p-2 rounded">
            {tunnel.description}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
