"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { 
  Shield, 
  CheckCircle, 
  AlertTriangle, 
  XCircle,
  RefreshCw
} from "lucide-react"

interface ServiceStatus {
  name: string
  status: 'healthy' | 'warning' | 'error'
  uptime?: string
  responseTime?: string
  lastCheck?: string
}

interface SystemHealthCardProps {
  services: ServiceStatus[]
  onRefresh?: () => void
  refreshing?: boolean
}

export function SystemHealthCard({ services, onRefresh, refreshing }: SystemHealthCardProps) {
  const getStatusIcon = (status: ServiceStatus['status']) => {
    switch (status) {
      case 'healthy':
        return <CheckCircle className="w-4 h-4 text-green-600" />
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-yellow-600" />
      case 'error':
        return <XCircle className="w-4 h-4 text-red-600" />
    }
  }

  const getStatusBadge = (status: ServiceStatus['status']) => {
    switch (status) {
      case 'healthy':
        return <Badge variant="success">正常运行</Badge>
      case 'warning':
        return <Badge variant="warning">存在警告</Badge>
      case 'error':
        return <Badge variant="error">服务异常</Badge>
    }
  }

  const getOverallHealth = () => {
    const errorCount = services.filter(s => s.status === 'error').length
    const warningCount = services.filter(s => s.status === 'warning').length
    
    if (errorCount > 0) return 'error'
    if (warningCount > 0) return 'warning'
    return 'healthy'
  }

  const overallHealth = getOverallHealth()

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              系统健康状态
            </CardTitle>
            <CardDescription>
              服务组件运行状态监控
            </CardDescription>
          </div>
          <div className="flex items-center gap-3">
            {getStatusBadge(overallHealth)}
            {onRefresh && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={onRefresh}
                disabled={refreshing}
              >
                <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {services.map((service, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
              <div className="flex items-center gap-3">
                {getStatusIcon(service.status)}
                <div>
                  <p className="font-medium">{service.name}</p>
                  {service.responseTime && (
                    <p className="text-xs text-muted-foreground">
                      响应时间: {service.responseTime}
                    </p>
                  )}
                </div>
              </div>
              <div className="text-right">
                {getStatusBadge(service.status)}
                {service.uptime && (
                  <p className="text-xs text-muted-foreground mt-1">
                    运行时间: {service.uptime}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-4 pt-4 border-t text-center">
          <p className="text-xs text-muted-foreground">
            最后检查时间: {new Date().toLocaleString()}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
