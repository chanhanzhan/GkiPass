"use client"

import { useState } from "react"
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { useToast } from "@/components/ui/Toast"
import { api } from "@/lib/api"
import { 
  Package, 
  Plus, 
  Activity, 
  Database,
  Zap,
  Wifi,
  DollarSign,
  Clock
} from "lucide-react"

interface CreatePlanDialogProps {
  onPlanCreated: () => void
  trigger?: React.ReactNode
}

export function CreatePlanDialog({ onPlanCreated, trigger }: CreatePlanDialogProps) {
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const { showToast } = useToast()
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: 0,
    original_price: 0,
    max_tunnels: 5,
    max_traffic: 10 * 1024 * 1024 * 1024, // 10GB
    max_bandwidth: 100 * 1024 * 1024, // 100Mbps
    ip_limit: 0, // 0表示不限制
    billing_period: 'monthly' as 'monthly' | 'yearly',
    status: 'active' as 'active' | 'disabled',
    is_default: false,
    allow_custom_nodes: false,
    allow_users_custom_nodegroup: false,
    allow_custom_exit_nodegroup: false,
    nodegroup_id: ''
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.name || formData.price < 0) {
      showToast('error', '请填写完整的套餐信息')
      return
    }

    setLoading(true)
    try {
      await api.plans.create(formData)
      showToast('success', '套餐创建成功')
      setOpen(false)
      setFormData({
        name: '',
        description: '',
        price: 0,
        original_price: 0,
        max_tunnels: 5,
        max_traffic: 10 * 1024 * 1024 * 1024,
        max_bandwidth: 100 * 1024 * 1024,
        ip_limit: 0,
        billing_period: 'monthly',
        status: 'active',
        is_default: false,
        allow_custom_nodes: false,
        allow_users_custom_nodegroup: false,
        allow_custom_exit_nodegroup: false,
        nodegroup_id: ''
      })
      onPlanCreated()
    } catch (error: unknown) {
      showToast('error', (error as { data?: { error?: string } }).data?.error || '创建失败')
    } finally {
      setLoading(false)
    }
  }

  const formatTrafficGB = (bytes: number) => Math.round(bytes / (1024 * 1024 * 1024))
  const formatBandwidthMbps = (bytes: number) => Math.round(bytes / (1024 * 1024))

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="admin">
            <Plus className="w-4 h-4 mr-2" />
            创建套餐
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="w-5 h-5" />
              创建新套餐
            </DialogTitle>
            <DialogDescription>
              为 RelayX 系统配置新的订阅套餐
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* 基本信息 */}
            <div className="space-y-4">
              <h3 className="font-medium flex items-center gap-2">
                <Package className="w-4 h-4" />
                基本信息
              </h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">套餐名称 *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="例如：标准版"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="billing_period">计费周期</Label>
                  <Select 
                    value={formData.billing_period} 
                    onValueChange={(value: 'monthly' | 'yearly') => 
                      setFormData({ ...formData, billing_period: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="monthly">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4" />
                          月付
                        </div>
                      </SelectItem>
                      <SelectItem value="yearly">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4" />
                          年付
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">套餐描述</Label>
                <Input
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="套餐功能描述..."
                />
              </div>
            </div>

            {/* 价格配置 */}
            <div className="space-y-4">
              <h3 className="font-medium flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                价格配置
              </h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="price">售价 (¥) *</Label>
                  <Input
                    id="price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
                    placeholder="0.00"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="original_price">原价 (¥)</Label>
                  <Input
                    id="original_price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.original_price}
                    onChange={(e) => setFormData({ ...formData, original_price: parseFloat(e.target.value) || 0 })}
                    placeholder="可选，用于显示折扣"
                  />
                </div>
              </div>
            </div>

            {/* 资源限制 */}
            <div className="space-y-4">
              <h3 className="font-medium flex items-center gap-2">
                <Activity className="w-4 h-4" />
                资源限制
              </h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="max_tunnels">最大隧道数</Label>
                  <Input
                    id="max_tunnels"
                    type="number"
                    min="1"
                    value={formData.max_tunnels}
                    onChange={(e) => setFormData({ ...formData, max_tunnels: parseInt(e.target.value) || 1 })}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="max_traffic">流量限制 (GB)</Label>
                  <Input
                    id="max_traffic"
                    type="number"
                    min="1"
                    value={formatTrafficGB(formData.max_traffic)}
                    onChange={(e) => {
                      const gb = parseInt(e.target.value) || 1
                      setFormData({ ...formData, max_traffic: gb * 1024 * 1024 * 1024 })
                    }}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="max_bandwidth">带宽限制 (Mbps)</Label>
                  <Input
                    id="max_bandwidth"
                    type="number"
                    min="1"
                    value={formatBandwidthMbps(formData.max_bandwidth)}
                    onChange={(e) => {
                      const mbps = parseInt(e.target.value) || 1
                      setFormData({ ...formData, max_bandwidth: mbps * 1024 * 1024 })
                    }}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="ip_limit">IP限制</Label>
                  <Input
                    id="ip_limit"
                    type="number"
                    min="0"
                    value={formData.ip_limit}
                    onChange={(e) => setFormData({ ...formData, ip_limit: parseInt(e.target.value) || 0 })}
                    placeholder="0表示不限制"
                  />
                </div>
              </div>
            </div>

            {/* 权限设置 */}
            <div className="space-y-4">
              <h3 className="font-medium">权限设置</h3>
              
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <input
                    id="is_default"
                    type="checkbox"
                    checked={formData.is_default}
                    onChange={(e) => setFormData({ ...formData, is_default: e.target.checked })}
                    className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
                  />
                  <Label htmlFor="is_default">设为默认套餐</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <input
                    id="allow_custom_nodes"
                    type="checkbox"
                    checked={formData.allow_custom_nodes}
                    onChange={(e) => setFormData({ ...formData, allow_custom_nodes: e.target.checked })}
                    className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
                  />
                  <Label htmlFor="allow_custom_nodes">允许自定义入口节点组</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <input
                    id="allow_users_custom_nodegroup"
                    type="checkbox"
                    checked={formData.allow_users_custom_nodegroup}
                    onChange={(e) => setFormData({ ...formData, allow_users_custom_nodegroup: e.target.checked })}
                    className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
                  />
                  <Label htmlFor="allow_users_custom_nodegroup">允许用户有序使用节点组</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <input
                    id="allow_custom_exit_nodegroup"
                    type="checkbox"
                    checked={formData.allow_custom_exit_nodegroup}
                    onChange={(e) => setFormData({ ...formData, allow_custom_exit_nodegroup: e.target.checked })}
                    className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
                  />
                  <Label htmlFor="allow_custom_exit_nodegroup">允许自定义出口节点组</Label>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              取消
            </Button>
            <Button type="submit" variant="admin" disabled={loading}>
              {loading ? '创建中...' : '创建套餐'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
