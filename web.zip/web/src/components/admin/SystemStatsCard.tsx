"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { 
  TrendingUp, 
  TrendingDown, 
  Minus,
  Users,
  Server,
  Activity,
  CreditCard
} from "lucide-react"

interface SystemStatsCardProps {
  title: string
  value: string | number
  icon: React.ReactNode
  trend?: {
    value: number
    type: 'up' | 'down' | 'stable'
    label: string
  }
  description?: string
  color?: 'blue' | 'green' | 'purple' | 'orange' | 'red' | 'relay' | 'tunnel'
  className?: string
}

export function SystemStatsCard({ 
  title, 
  value, 
  icon, 
  trend, 
  description,
  color = 'blue',
  className 
}: SystemStatsCardProps) {
  const colorClasses = {
    blue: {
      gradient: 'from-blue-500 to-blue-600',
      bg: 'from-blue-50 to-blue-100',
      text: 'text-blue-600',
      border: 'border-blue-200',
      hover: 'hover:border-blue-300'
    },
    green: {
      gradient: 'from-green-500 to-green-600',
      bg: 'from-green-50 to-green-100',
      text: 'text-green-600',
      border: 'border-green-200',
      hover: 'hover:border-green-300'
    },
    purple: {
      gradient: 'from-purple-500 to-purple-600',
      bg: 'from-purple-50 to-purple-100',
      text: 'text-purple-600',
      border: 'border-purple-200',
      hover: 'hover:border-purple-300'
    },
    orange: {
      gradient: 'from-orange-500 to-orange-600',
      bg: 'from-orange-50 to-orange-100',
      text: 'text-orange-600',
      border: 'border-orange-200',
      hover: 'hover:border-orange-300'
    },
    red: {
      gradient: 'from-red-500 to-red-600',
      bg: 'from-red-50 to-red-100',
      text: 'text-red-600',
      border: 'border-red-200',
      hover: 'hover:border-red-300'
    },
    relay: {
      gradient: 'bg-slate-600',
      bg: 'from-slate-50 to-slate-100',
      text: 'text-slate-600',
      border: 'border-slate-200',
      hover: 'hover:border-slate-300'
    },
    tunnel: {
      gradient: 'bg-stone-600',
      bg: 'from-stone-50 to-stone-100',
      text: 'text-stone-600',
      border: 'border-stone-200',
      hover: 'hover:border-stone-300'
    }
  }

  const colors = colorClasses[color]

  const getTrendIcon = () => {
    if (!trend) return null
    
    switch (trend.type) {
      case 'up':
        return <TrendingUp className="w-3 h-3" />
      case 'down':
        return <TrendingDown className="w-3 h-3" />
      case 'stable':
        return <Minus className="w-3 h-3" />
    }
  }

  const getTrendColor = () => {
    if (!trend) return ''
    
    switch (trend.type) {
      case 'up':
        return 'text-green-600 bg-green-50 border-green-200'
      case 'down':
        return 'text-red-600 bg-red-50 border-red-200'
      case 'stable':
        return 'text-gray-600 bg-gray-50 border-gray-200'
    }
  }

  return (
    <Card className={cn(
      'relative overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1 border-2',
      colors.border,
      colors.hover,
      className
    )}>
      {/* 背景装饰 */}
      <div className={cn(
        'absolute top-0 right-0 w-32 h-32 rounded-full -mr-16 -mt-16 blur-2xl opacity-5 transition-all duration-500 group-hover:scale-150',
        colors.gradient
      )} />
      
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardDescription className="text-sm font-medium">
            {title}
          </CardDescription>
          <div className={cn(
            'p-2 rounded-lg text-white shadow-sm',
            colors.gradient
          )}>
            {icon}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="relative z-10">
        <div className="space-y-3">
          <div className="text-3xl font-bold">{value}</div>
          
          {trend && (
            <div className="flex items-center gap-2">
              <Badge variant="outline" className={cn('text-xs', getTrendColor())}>
                <div className="flex items-center gap-1">
                  {getTrendIcon()}
                  <span>{Math.abs(trend.value)}%</span>
                </div>
              </Badge>
              <span className="text-xs text-muted-foreground">{trend.label}</span>
            </div>
          )}
          
          {description && (
            <p className="text-sm text-muted-foreground">{description}</p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
