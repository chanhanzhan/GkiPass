"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { 
  Settings, 
  Save, 
  RotateCcw,
  CheckCircle,
  AlertCircle
} from "lucide-react"

interface ConfigItem {
  key: string
  name: string
  description: string
  value: string | number | boolean
  type: 'string' | 'number' | 'boolean' | 'select'
  options?: string[]
  category: string
}

interface SystemConfigCardProps {
  title: string
  description: string
  icon: React.ReactNode
  configs: ConfigItem[]
  onSave: (configs: ConfigItem[]) => Promise<void>
}

export function SystemConfigCard({ 
  title, 
  description, 
  icon, 
  configs: initialConfigs, 
  onSave 
}: SystemConfigCardProps) {
  const [configs, setConfigs] = useState<ConfigItem[]>(initialConfigs)
  const [saving, setSaving] = useState(false)
  const [hasChanges, setHasChanges] = useState(false)

  const updateConfig = (key: string, value: string | number | boolean) => {
    const newConfigs = configs.map(config => 
      config.key === key ? { ...config, value } : config
    )
    setConfigs(newConfigs)
    setHasChanges(true)
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      await onSave(configs)
      setHasChanges(false)
    } catch (error) {
      // 错误处理
    } finally {
      setSaving(false)
    }
  }

  const handleReset = () => {
    setConfigs(initialConfigs)
    setHasChanges(false)
  }

  const renderConfigInput = (config: ConfigItem) => {
    switch (config.type) {
      case 'string':
        return (
          <Input
            value={config.value as string}
            onChange={(e) => updateConfig(config.key, e.target.value)}
            placeholder={`输入${config.name}`}
          />
        )
      
      case 'number':
        return (
          <Input
            type="number"
            value={config.value as number}
            onChange={(e) => updateConfig(config.key, parseFloat(e.target.value) || 0)}
            placeholder={`设置${config.name}`}
          />
        )
      
      case 'boolean':
        return (
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={config.value as boolean}
              onChange={(e) => updateConfig(config.key, e.target.checked)}
              className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
            />
            <span className="text-sm">
              {config.value ? '已启用' : '已禁用'}
            </span>
          </div>
        )
      
      case 'select':
        return (
          <Select 
            value={config.value as string} 
            onValueChange={(value) => updateConfig(config.key, value)}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {config.options?.map((option) => (
                <SelectItem key={option} value={option}>
                  {option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )
      
      default:
        return null
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              {icon}
              {title}
            </CardTitle>
            <CardDescription>{description}</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            {hasChanges && (
              <Badge variant="warning" className="text-xs">
                <AlertCircle className="w-3 h-3 mr-1" />
                有未保存的更改
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          {configs.map((config) => (
            <div key={config.key} className="space-y-2">
              <Label htmlFor={config.key}>{config.name}</Label>
              {renderConfigInput(config)}
              {config.description && (
                <p className="text-xs text-muted-foreground">
                  {config.description}
                </p>
              )}
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between pt-4 border-t">
          <Button 
            variant="outline" 
            onClick={handleReset}
            disabled={!hasChanges}
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            重置
          </Button>
          <Button 
            onClick={handleSave} 
            disabled={!hasChanges || saving}
            variant="admin"
          >
            {saving ? (
              <>
                <Settings className="w-4 h-4 mr-2 animate-spin" />
                保存中...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                保存配置
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
