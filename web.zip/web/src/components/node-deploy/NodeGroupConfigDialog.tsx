/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { useToast } from '@/components/ui/Toast';

interface NodeGroupConfigDialogProps {
  open: boolean;
  onClose: () => void;
  groupId: string;
  groupName?: string;
}

const PROTOCOL_OPTIONS = [
  { value: 'tcp', label: 'TCP', icon: '🔌' },
  { value: 'udp', label: 'UDP', icon: '📡' },
  { value: 'http', label: 'HTTP', icon: '🌐' },
  { value: 'https', label: 'HTTPS', icon: '🔒' },
  { value: 'ws', label: 'WebSocket', icon: '💬' },
  { value: 'wss', label: 'WebSocket Secure', icon: '🔐' },
];

export function NodeGroupConfigDialog({ open, onClose, groupId, groupName }: NodeGroupConfigDialogProps) {
  const { showToast } = useToast();
  const [loading, setLoading] = useState(false);
  const [loadingData, setLoadingData] = useState(true);
  
  const [allowedProtocols, setAllowedProtocols] = useState<string[]>(['tcp', 'udp']);
  const [portRangeStart, setPortRangeStart] = useState(10000);
  const [portRangeEnd, setPortRangeEnd] = useState(60000);
  const [trafficMultiplier, setTrafficMultiplier] = useState(1.0);

  useEffect(() => {
    if (open && groupId) {
      loadConfig();
    }
  }, [open, groupId]);

  async function loadConfig() {
    try {
      setLoadingData(true);
      const config = await api.nodeGroups.getConfig(groupId);
      setAllowedProtocols(config.allowed_protocols || ['tcp', 'udp']);
      setPortRangeStart(config.port_range_start || 10000);
      setPortRangeEnd(config.port_range_end || 60000);
      setTrafficMultiplier(config.traffic_multiplier || 1.0);
    } catch (error: any) {
      console.error('Failed to load config:', error);
      showToast('error', '加载配置失败');
    } finally {
      setLoadingData(false);
    }
  }

  const toggleProtocol = (protocol: string) => {
    if (allowedProtocols.includes(protocol)) {
      setAllowedProtocols(allowedProtocols.filter(p => p !== protocol));
    } else {
      setAllowedProtocols([...allowedProtocols, protocol]);
    }
  };

  const handleSave = async () => {
    // 验证
    if (allowedProtocols.length === 0) {
      showToast('error', '至少选择一个协议');
      return;
    }
    if (portRangeStart <= 0 || portRangeEnd <= 0) {
      showToast('error', '端口范围必须大于0');
      return;
    }
    if (portRangeStart >= portRangeEnd) {
      showToast('error', '起始端口必须小于结束端口');
      return;
    }
    if (trafficMultiplier <= 0) {
      showToast('error', '流量倍率必须大于0');
      return;
    }

    try {
      setLoading(true);
      await api.nodeGroups.updateConfig(groupId, {
        allowed_protocols: allowedProtocols,
        port_range_start: portRangeStart,
        port_range_end: portRangeEnd,
        traffic_multiplier: trafficMultiplier,
      });
      showToast('success', '配置已保存');
      onClose();
    } catch (error: any) {
      showToast('error', error.data?.error || '保存失败');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async () => {
    if (!confirm('确定要重置为默认配置吗？')) return;

    try {
      setLoading(true);
      await api.nodeGroups.resetConfig(groupId);
      showToast('success', '已重置为默认配置');
      await loadConfig();
    } catch (error: any) {
      showToast('error', error.data?.error || '重置失败');
    } finally {
      setLoading(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* 标题 */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">节点组配置</h2>
            {groupName && <p className="text-sm text-gray-500 mt-1">{groupName}</p>}
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* 内容 */}
        {loadingData ? (
          <div className="p-12 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">加载中...</p>
          </div>
        ) : (
          <div className="p-6 space-y-6">
            {/* 允许的协议 */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                允许的协议
              </label>
              <div className="grid grid-cols-2 gap-3">
                {PROTOCOL_OPTIONS.map(option => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => toggleProtocol(option.value)}
                    className={`p-4 rounded-xl border-2 transition-all text-left ${
                      allowedProtocols.includes(option.value)
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{option.icon}</span>
                      <div>
                        <div className="font-bold text-gray-900">{option.label}</div>
                        <div className="text-xs text-gray-500">{option.value.toUpperCase()}</div>
                      </div>
                      {allowedProtocols.includes(option.value) && (
                        <svg className="w-5 h-5 text-blue-600 ml-auto" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* 端口范围 */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                端口范围
              </label>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-gray-500 mb-2">起始端口</label>
                  <input
                    type="number"
                    value={portRangeStart}
                    onChange={(e) => setPortRangeStart(parseInt(e.target.value) || 0)}
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
                    min="1"
                    max="65535"
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-500 mb-2">结束端口</label>
                  <input
                    type="number"
                    value={portRangeEnd}
                    onChange={(e) => setPortRangeEnd(parseInt(e.target.value) || 0)}
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
                    min="1"
                    max="65535"
                  />
                </div>
              </div>
              <p className="mt-2 text-xs text-gray-500">
                💡 节点将使用此范围内的端口进行通信
              </p>
            </div>

            {/* 流量倍率 */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                流量倍率
              </label>
              <div className="flex items-center gap-4">
                <input
                  type="range"
                  value={trafficMultiplier}
                  onChange={(e) => setTrafficMultiplier(parseFloat(e.target.value))}
                  className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                  min="0.1"
                  max="10"
                  step="0.1"
                />
                <div className="px-4 py-2 bg-blue-100 text-blue-700 font-bold rounded-lg min-w-[80px] text-center">
                  {trafficMultiplier.toFixed(1)}x
                </div>
              </div>
              <p className="mt-2 text-xs text-gray-500">
                💡 流量倍率会影响流量统计和计费，如 1.5x 表示每1GB实际流量计为1.5GB
              </p>
            </div>

            {/* 预览 */}
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-4 border-2 border-blue-100">
              <h4 className="text-sm font-bold text-gray-900 mb-2">📋 配置预览</h4>
              <div className="space-y-1 text-sm text-gray-700">
                <div><span className="font-semibold">协议:</span> {allowedProtocols.join(', ') || '无'}</div>
                <div><span className="font-semibold">端口:</span> {portRangeStart} - {portRangeEnd} ({portRangeEnd - portRangeStart + 1} 个端口)</div>
                <div><span className="font-semibold">倍率:</span> {trafficMultiplier.toFixed(1)}x</div>
              </div>
            </div>
          </div>
        )}

        {/* 底部按钮 */}
        <div className="flex justify-between p-6 border-t border-gray-200">
          <button
            onClick={handleReset}
            disabled={loading || loadingData}
            className="px-5 py-3 bg-red-100 hover:bg-red-200 text-red-700 rounded-xl font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            🔄 重置为默认
          </button>
          
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="px-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-900 rounded-xl font-semibold transition-colors"
            >
              取消
            </button>
            <button
              onClick={handleSave}
              disabled={loading || loadingData}
              className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-xl font-semibold transition-all shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? '保存中...' : '💾 保存配置'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

