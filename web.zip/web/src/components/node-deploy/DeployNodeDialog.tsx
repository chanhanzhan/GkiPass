/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useState } from 'react';
import { api } from '@/lib/api';
import { useToast } from '@/components/ui/Toast';

interface DeployNodeDialogProps {
  open: boolean;
  onClose: () => void;
  groupId: string;
  onSuccess?: () => void;
}

export function DeployNodeDialog({ open, onClose, groupId, onSuccess }: DeployNodeDialogProps) {
  const { showToast } = useToast();
  const [loading, setLoading] = useState(false);
  const [serverName, setServerName] = useState('');
  const [connectionIp, setConnectionIp] = useState('');
  const [exitNetwork, setExitNetwork] = useState('');
  const [debugMode, setDebugMode] = useState(false);
  const [nodeData, setNodeData] = useState<any>(null);
  const [copied, setCopied] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const data = await api.nodeGroups.createNode(groupId, {
        name: serverName,
        connection_ip: connectionIp,
        exit_network: exitNetwork,
        debug_mode: debugMode,
      });
      setNodeData(data);
      showToast('success', '部署命令已生成！');
      if (onSuccess) onSuccess();
    } catch (error: any) {
      showToast('error', error.data?.error || '生成失败');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (nodeData?.install_command) {
      navigator.clipboard.writeText(nodeData.install_command);
      setCopied(true);
      showToast('success', '命令已复制到剪贴板');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleClose = () => {
    setServerName('');
    setConnectionIp('');
    setExitNetwork('');
    setDebugMode(false);
    setNodeData(null);
    setCopied(false);
    onClose();
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        {/* 标题 */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">部署节点</h2>
            <p className="text-sm text-gray-500 mt-1">请配置节点部署参数</p>
          </div>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* 内容 */}
        <div className="p-6 space-y-5">
          {/* 服务器名 */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              服务器名
            </label>
            <input
              type="text"
              value={serverName}
              onChange={(e) => setServerName(e.target.value)}
              className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
              placeholder="可选，同一台机器部署多个节点请使用不同名称"
              disabled={!!nodeData}
            />
          </div>

          {/* 节点ID */}
          {nodeData && (
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                节点 ID
              </label>
              <input
                type="text"
                value={nodeData.id}
                readOnly
                className="w-full px-4 py-3 bg-gray-50 border-2 border-gray-200 rounded-xl text-gray-600 font-mono text-sm"
              />
            </div>
          )}

          {/* 连接IP或域名 */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              连接 IP 或域名
            </label>
            <input
              type="text"
              value={connectionIp}
              onChange={(e) => setConnectionIp(e.target.value)}
              className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
              placeholder="可选，默认自动获取公网 IP"
              disabled={!!nodeData}
            />
            {!nodeData && (
              <button
                type="button"
                onClick={() => {
                  // 可以实现添加多个IP的功能
                  showToast('info', '暂不支持多IP配置');
                }}
                className="mt-2 text-sm text-blue-600 hover:text-blue-700 font-medium"
              >
                ➕ 添加连接 IP 或域名
              </button>
            )}
          </div>

          {/* 出口网络 */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              出口网络
            </label>
            <input
              type="text"
              value={exitNetwork}
              onChange={(e) => setExitNetwork(e.target.value)}
              className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
              placeholder="可选，适用于多 IP 机器，可填写网络接口或 IP 地址"
              disabled={!!nodeData}
            />
          </div>

          {/* 调试模式 */}
          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              id="debug-mode"
              checked={debugMode}
              onChange={(e) => setDebugMode(e.target.checked)}
              disabled={!!nodeData}
              className="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
            />
            <label htmlFor="debug-mode" className="text-sm font-semibold text-gray-700">
              启用调试模式
            </label>
          </div>

          {/* 安装命令 */}
          {nodeData && (
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                安装命令
              </label>
              <div className="relative bg-gray-900 rounded-xl p-4 overflow-x-auto">
                <pre className="text-sm text-gray-100 font-mono whitespace-pre-wrap break-all">
                  {nodeData.install_command}
                </pre>
                <button
                  onClick={handleCopy}
                  className="absolute top-3 right-3 p-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
                  title="复制命令"
                >
                  {copied ? (
                    <svg className="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  ) : (
                    <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    </svg>
                  )}
                </button>
              </div>
              <p className="mt-2 text-xs text-gray-500">
                💡 在服务器上执行此命令以部署节点
              </p>
            </div>
          )}
        </div>

        {/* 底部按钮 */}
        <div className="flex justify-end space-x-3 p-6 border-t border-gray-200">
          <button
            onClick={handleClose}
            className="px-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-900 rounded-xl font-semibold transition-colors"
          >
            {nodeData ? '关闭' : '取消'}
          </button>
          {!nodeData ? (
            <button
              onClick={handleGenerate}
              disabled={loading}
              className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-xl font-semibold transition-all shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? '生成中...' : '生成命令'}
            </button>
          ) : (
            <button
              onClick={handleCopy}
              className="px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white rounded-xl font-semibold transition-all shadow-lg hover:shadow-xl"
            >
              {copied ? '✓ 已复制' : '📋 复制命令'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

