import { ReactNode } from 'react';

interface SettingSectionProps {
  title: string;
  description?: string;
  icon?: string;
  children: ReactNode;
}

export function SettingSection({ title, description, icon, children }: SettingSectionProps) {
  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-blue-500">
      <div className="flex items-center gap-3 mb-4">
        {icon && <span className="text-3xl">{icon}</span>}
        <div>
          <h2 className="text-xl font-bold text-gray-900">{title}</h2>
          {description && <p className="text-sm text-gray-500 mt-1">{description}</p>}
        </div>
      </div>
      <div className="space-y-4">{children}</div>
    </div>
  );
}

