import { ReactNode } from 'react';

interface SettingItemProps {
  label: string;
  description?: string;
  children: ReactNode;
  error?: string;
}

export function SettingItem({ label, description, children, error }: SettingItemProps) {
  return (
    <div className="space-y-2">
      <div>
        <label className="block text-sm font-semibold text-gray-700">{label}</label>
        {description && <p className="text-xs text-gray-500 mt-0.5">{description}</p>}
      </div>
      <div>{children}</div>
      {error && <p className="text-xs text-red-600 mt-1">{error}</p>}
    </div>
  );
}

