'use client';

import { useRouter } from 'next/navigation';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Breadcrumb } from '@/components/layout/Breadcrumb';
import { MobileSidebar } from '@/components/layout/MobileSidebar';
import { 
  User, 
  Settings, 
  LogOut, 
  Crown,
  Bell,
  Search
} from 'lucide-react';
import { ThemeToggle } from '@/components/theme/ThemeToggle';
import Link from 'next/link';

export function Navbar() {
  const router = useRouter();
  const { user, logout } = useAuth();

  const handleLogout = async () => {
    await logout();
    router.push('/login');
  };

  return (
    <header className="h-16 bg-slate-800 border-b border-slate-700 flex items-center justify-between px-4 md:px-6">
      {/* 移动端侧边栏触发器和面包屑 */}
      <div className="flex items-center gap-4">
        <MobileSidebar isAdmin={user?.is_admin} />
        <div className="hidden md:block">
          <Breadcrumb />
        </div>
      </div>
      
      {/* 用户操作区域 */}
      <div className="flex items-center space-x-2 md:space-x-4">
        {/* 通知按钮 */}
        <Button variant="ghost" size="sm" className="hidden sm:flex">
          <Bell className="w-4 h-4" />
        </Button>

        {/* 搜索按钮 */}
        <Button variant="ghost" size="sm" className="hidden sm:flex">
          <Search className="w-4 h-4" />
        </Button>

        {/* 主题切换 */}
        <ThemeToggle />

        {/* 用户菜单 */}
        {user && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-2 md:gap-3 px-2 md:px-3">
                <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-semibold text-sm">
                  {user.username?.[0]?.toUpperCase() || 'U'}
                </div>
                <div className="text-left hidden sm:block">
                  <div className="text-sm font-medium">{user.username}</div>
                  <div className="flex items-center gap-1">
                    {user.is_admin && <Crown className="w-3 h-3" />}
                    <Badge variant={user.is_admin ? "destructive" : "relay"} className="text-xs">
                      {user.is_admin ? '管理员' : '用户'}
                    </Badge>
                  </div>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end">
              <DropdownMenuLabel>我的账户</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/profile" className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  个人设置
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/notifications" className="flex items-center gap-2">
                  <Bell className="w-4 h-4" />
                  通知中心
                </Link>
              </DropdownMenuItem>
              {user.is_admin && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/admin/dashboard" className="flex items-center gap-2">
                      <Crown className="w-4 h-4" />
                      管理后台
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/admin/settings" className="flex items-center gap-2">
                      <Settings className="w-4 h-4" />
                      系统设置
                    </Link>
                  </DropdownMenuItem>
                </>
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive">
                <LogOut className="w-4 h-4 mr-2" />
                退出登录
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>
    </header>
  );
}






