"use client"

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { Logo } from '@/components/ui/logo'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import { Menu, X } from 'lucide-react'

// 普通用户导航菜单
const userNavigation = [
  { name: '仪表板', href: '/dashboard', icon: '📊' },
  { name: '隧道管理', href: '/tunnels', icon: '🔗' },
  { name: '节点管理', href: '/nodes', icon: '🖥️' },
  { name: '节点组', href: '/node-groups', icon: '📁' },
  { name: '我的订阅', href: '/subscription', icon: '💳' },
  { name: '套餐选择', href: '/plans', icon: '📦' },
  { name: '我的钱包', href: '/wallet', icon: '💰' },
  { name: '通知中心', href: '/notifications', icon: '🔔' },
  { name: '系统公告', href: '/announcements', icon: '📢' },
  { name: '个人信息', href: '/profile', icon: '👤' },
];

// 管理员导航菜单
const adminNavigation = [
  { name: '管理总览', href: '/admin/dashboard', icon: '👑' },
  { name: '用户管理', href: '/admin/users', icon: '👥' },
  { name: '节点管理', href: '/admin/nodes', icon: '🖥️' },
  { name: '节点组管理', href: '/admin/node-groups', icon: '📁' },
  { name: '套餐管理', href: '/admin/plans', icon: '📦' },
  { name: '策略管理', href: '/admin/policies', icon: '🛡️' },
  { name: '公告管理', href: '/admin/announcements', icon: '📢' },
  { name: '系统统计', href: '/admin/statistics', icon: '📈' },
  { name: '系统设置', href: '/admin/settings', icon: '⚙️' },
];

interface MobileSidebarProps {
  isAdmin?: boolean
}

export function MobileSidebar({ isAdmin = false }: MobileSidebarProps) {
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)
  
  const navigation = isAdmin ? adminNavigation : userNavigation

  const activeClass = isAdmin 
    ? 'bg-slate-700 text-white'
    : 'bg-slate-600 text-white'

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="sm" className="md:hidden">
          <Menu className="w-5 h-5" />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-64 p-0">
        <div className="flex flex-col h-full">
          {/* Logo */}
          <SheetHeader className={`p-4 ${isAdmin ? 'bg-gradient-to-r from-purple-600 to-pink-600' : 'bg-white'}`}>
            <SheetTitle className="flex items-center gap-3">
              {isAdmin ? (
                <>
                  <div className="bg-white/20 backdrop-blur-sm rounded-lg p-1">
                    <span className="text-xl">👑</span>
                  </div>
                  <Logo variant="light" size="sm" />
                </>
              ) : (
                <Logo variant="gradient" size="sm" />
              )}
            </SheetTitle>
          </SheetHeader>

          {/* Navigation */}
          <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
            {navigation.map((item) => {
              const isActive = pathname === item.href || pathname?.startsWith(item.href + '/');
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  onClick={() => setIsOpen(false)}
                  className={cn(
                    'flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                    isActive
                      ? activeClass
                      : 'text-gray-700 hover:bg-gray-100'
                  )}
                >
                  <span className="mr-3 text-lg">{item.icon}</span>
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </nav>

          {/* Footer */}
          <div className="p-4 border-t">
            {isAdmin && (
              <div className="mb-3 p-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg text-center">
                <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                  👑 管理员模式
                </Badge>
              </div>
            )}
            <p className="text-xs text-gray-500 text-center">
              © 2025 RelayX v2.1.0
            </p>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
