"use client"

import { usePathname } from 'next/navigation'
import Link from 'next/link'
import { cn } from '@/lib/utils'
import { ChevronRight, Home } from 'lucide-react'

interface BreadcrumbItem {
  label: string
  href?: string
}

export function Breadcrumb({ className }: { className?: string }) {
  const pathname = usePathname()
  
  // 生成面包屑路径
  const generateBreadcrumbs = (): BreadcrumbItem[] => {
    const paths = pathname.split('/').filter(Boolean)
    const breadcrumbs: BreadcrumbItem[] = [
      { label: '首页', href: '/dashboard' }
    ]

    let currentPath = ''
    paths.forEach((path, index) => {
      currentPath += `/${path}`
      
      // 路径名称映射
      const pathLabels: Record<string, string> = {
        'dashboard': '仪表板',
        'admin': '管理后台',
        'tunnels': '隧道管理',
        'nodes': '节点管理',
        'users': '用户管理',
        'plans': '套餐管理',
        'announcements': '公告管理',
        'settings': '系统设置',
        'profile': '个人中心',
        'wallet': '我的钱包',
        'notifications': '通知中心',
        'node-groups': '节点组',
        'traffic-stats': '流量统计',
        'subscription': '我的订阅',
        'create': '创建',
        'edit': '编辑'
      }

      const label = pathLabels[path] || path
      const isLast = index === paths.length - 1
      
      breadcrumbs.push({
        label,
        href: isLast ? undefined : currentPath
      })
    })

    return breadcrumbs
  }

  const breadcrumbs = generateBreadcrumbs()

  return (
    <nav className={cn("flex items-center space-x-1 text-sm text-muted-foreground", className)}>
      <Home className="w-4 h-4" />
      {breadcrumbs.map((item, index) => (
        <div key={index} className="flex items-center space-x-1">
          {index > 0 && <ChevronRight className="w-4 h-4" />}
          {item.href ? (
            <Link 
              href={item.href}
              className="hover:text-foreground transition-colors"
            >
              {item.label}
            </Link>
          ) : (
            <span className="font-medium text-foreground">{item.label}</span>
          )}
        </div>
      ))}
    </nav>
  )
}
