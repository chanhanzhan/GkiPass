'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { Logo } from '@/components/ui/logo';

// 普通用户导航菜单
const userNavigation = [
  { name: '仪表板', href: '/dashboard', icon: '📊' },
  { name: '隧道管理', href: '/tunnels', icon: '🔗' },
  { name: '节点管理', href: '/nodes', icon: '🖥️' },
  { name: '节点组', href: '/node-groups', icon: '📁' },
  { name: '我的订阅', href: '/subscription', icon: '💳' },
  { name: '套餐选择', href: '/plans', icon: '📦' },
  { name: '我的钱包', href: '/wallet', icon: '💰' },
  { name: '通知中心', href: '/notifications', icon: '🔔' },
  { name: '系统公告', href: '/announcements', icon: '📢' },
  { name: '个人信息', href: '/profile', icon: '👤' },
];

// 管理员导航菜单（完全不同）
const adminNavigation = [
  { name: '管理总览', href: '/admin/dashboard', icon: '👑' },
  { name: '用户管理', href: '/admin/users', icon: '👥' },
  { name: '节点管理', href: '/admin/nodes', icon: '🖥️' },
  { name: '节点组管理', href: '/admin/node-groups', icon: '📁' },
  { name: '套餐管理', href: '/admin/plans', icon: '📦' },
  { name: '策略管理', href: '/admin/policies', icon: '🛡️' },
  { name: '公告管理', href: '/admin/announcements', icon: '📢' },
  { name: '系统统计', href: '/admin/statistics', icon: '📈' },
  { name: '系统设置', href: '/admin/settings', icon: '⚙️' },
];

interface SidebarProps {
  isAdmin?: boolean;
}

export function Sidebar({ isAdmin = false }: SidebarProps) {
  const pathname = usePathname();
  
  // 根据角色选择完全不同的菜单
  const navigation = isAdmin ? adminNavigation : userNavigation;
  
  // RelayX 统一配色 - 深色主题
  const activeClass = 'bg-blue-600 text-white';
  const hoverClass = 'hover:bg-slate-700 hover:text-slate-100';

  return (
    <aside className="w-64 flex flex-col h-full bg-slate-800 border-r border-slate-700">
      {/* Logo */}
      <div className="h-16 flex items-center px-6 border-b border-slate-700 bg-slate-800">
        {isAdmin ? (
          <div className="flex items-center gap-3">
            <div className="bg-muted rounded-lg p-1.5">
              <span className="text-2xl">👑</span>
            </div>
            <Logo variant="light" size="md" />
          </div>
        ) : (
          <Logo variant="light" size="md" />
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navigation.map((item) => {
          const isActive = pathname === item.href || pathname?.startsWith(item.href + '/');
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                'group flex items-center px-4 py-3 text-sm font-semibold rounded-xl transition-all duration-200',
                isActive
                  ? activeClass
                  : `text-gray-700 ${hoverClass}`
              )}
            >
              <span className={cn(
                "mr-3 text-xl transition-transform duration-200",
                isActive ? "scale-110" : "group-hover:scale-110"
              )}>{item.icon}</span>
              <span className="flex-1">{item.name}</span>
              {isActive && (
                <div className={cn(
                  "w-1.5 h-1.5 rounded-full",
                  isAdmin ? "bg-white" : "bg-white"
                )}></div>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-slate-700">
        {isAdmin && (
            <div className="mb-3 px-4 py-2.5 bg-blue-600 rounded-lg text-center">
              <p className="text-xs font-medium text-white flex items-center justify-center gap-2">
              <span>👑</span>
              <span>管理员模式</span>
            </p>
          </div>
        )}
        <p className="text-xs text-muted-foreground text-center font-medium">
          © 2025 RelayX v2.1.0
        </p>
      </div>
    </aside>
  );
}

