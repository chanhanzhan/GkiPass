"use client"

import { useRef } from 'react'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js'
import { Bar } from 'react-chartjs-2'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Users } from 'lucide-react'

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
)

interface UserGrowthData {
  month: string
  newUsers: number
  activeUsers: number
  totalUsers: number
}

interface UserGrowthChartProps {
  data: UserGrowthData[]
  className?: string
}

export function UserGrowthChart({ data, className }: UserGrowthChartProps) {
  const chartRef = useRef<ChartJS>(null)

  const labels = data.map(item => item.month)

  const chartData = {
    labels,
    datasets: [
      {
        label: '新增用户',
        data: data.map(item => item.newUsers),
        backgroundColor: 'rgba(59, 130, 246, 0.8)',
        borderColor: 'rgba(59, 130, 246, 1)',
        borderWidth: 1,
      },
      {
        label: '活跃用户',
        data: data.map(item => item.activeUsers),
        backgroundColor: 'rgba(34, 197, 94, 0.8)',
        borderColor: 'rgba(34, 197, 94, 1)',
        borderWidth: 1,
      },
      {
        label: '总用户数',
        data: data.map(item => item.totalUsers),
        backgroundColor: 'rgba(168, 85, 247, 0.8)',
        borderColor: 'rgba(168, 85, 247, 1)',
        borderWidth: 1,
      },
    ],
  }

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      tooltip: {
        callbacks: {
          label: function(context: { dataset: { label?: string }, parsed: { y: number } }) {
            return `${context.dataset.label || ''}: ${context.parsed.y} 用户`
          }
        }
      }
    },
    scales: {
      x: {
        display: true,
        title: {
          display: true,
          text: '月份'
        },
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
        }
      },
      y: {
        display: true,
        title: {
          display: true,
          text: '用户数量'
        },
        beginAtZero: true,
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
        }
      },
    },
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="w-5 h-5" />
          用户增长趋势
        </CardTitle>
        <CardDescription>
          平台用户注册和活跃度统计分析
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <Bar data={chartData} options={options} />
        </div>
      </CardContent>
    </Card>
  )
}
