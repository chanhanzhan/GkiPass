"use client"

import { useRef } from 'react'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js'
import { Line } from 'react-chartjs-2'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { DollarSign, TrendingUp } from 'lucide-react'

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
)

interface RevenueData {
  date: string
  revenue: number
  orders: number
  averageOrderValue: number
}

interface RevenueChartProps {
  data: RevenueData[]
  className?: string
}

export function RevenueChart({ data, className }: RevenueChartProps) {
  const chartRef = useRef<ChartJS>(null)

  const labels = data.map(item => {
    const date = new Date(item.date)
    return date.toLocaleDateString('zh-CN', { 
      month: 'short', 
      day: 'numeric' 
    })
  })

  const totalRevenue = data.reduce((sum, item) => sum + item.revenue, 0)
  const totalOrders = data.reduce((sum, item) => sum + item.orders, 0)
  const averageGrowth = data.length > 1 
    ? ((data[data.length - 1].revenue - data[0].revenue) / data[0].revenue * 100)
    : 0

  const chartData = {
    labels,
    datasets: [
      {
        label: '每日收入 (¥)',
        data: data.map(item => item.revenue),
        borderColor: 'rgb(34, 197, 94)',
        backgroundColor: 'rgba(34, 197, 94, 0.1)',
        fill: true,
        tension: 0.4,
        yAxisID: 'y',
      },
      {
        label: '订单数量',
        data: data.map(item => item.orders),
        borderColor: 'rgb(168, 85, 247)',
        backgroundColor: 'rgba(168, 85, 247, 0.1)',
        fill: true,
        tension: 0.4,
        yAxisID: 'y1',
      },
    ],
  }

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: {
      mode: 'index' as const,
      intersect: false,
    },
    plugins: {
      legend: {
        position: 'top' as const,
      },
      tooltip: {
        callbacks: {
          label: function(context: { datasetIndex: number, parsed: { y: number } }) {
            if (context.datasetIndex === 0) {
              return `收入: ¥${context.parsed.y.toFixed(2)}`
            }
            return `订单: ${context.parsed.y} 笔`
          }
        }
      }
    },
    scales: {
      x: {
        display: true,
        title: {
          display: true,
          text: '日期'
        },
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
        }
      },
      y: {
        type: 'linear' as const,
        display: true,
        position: 'left' as const,
        title: {
          display: true,
          text: '收入 (¥)'
        },
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
        }
      },
      y1: {
        type: 'linear' as const,
        display: true,
        position: 'right' as const,
        title: {
          display: true,
          text: '订单数'
        },
        min: 0,
        grid: {
          drawOnChartArea: false,
        },
      },
    },
  }

  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5" />
              收入统计
            </CardTitle>
            <CardDescription>财务收入和订单趋势分析</CardDescription>
          </div>
          <div className="text-right">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-sm text-muted-foreground">总收入:</span>
              <Badge variant="success" className="text-sm">
                ¥{totalRevenue.toFixed(2)}
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">增长率:</span>
              <Badge 
                variant={averageGrowth >= 0 ? 'success' : 'error'} 
                className="text-sm"
              >
                <TrendingUp className="w-3 h-3 mr-1" />
                {averageGrowth >= 0 ? '+' : ''}{averageGrowth.toFixed(1)}%
              </Badge>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <Line data={chartData} options={options} />
        </div>
      </CardContent>
    </Card>
  )
}
