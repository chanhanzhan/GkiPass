"use client"

import { useEffect, useRef } from 'react'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js'
import { Line, Bar } from 'react-chartjs-2'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { formatBytes } from '@/lib/utils'
import { TrendingUp, BarChart3 } from 'lucide-react'

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler
)

interface TrafficData {
  date: string
  upload: number
  download: number
  total: number
}

interface TrafficChartProps {
  data: TrafficData[]
  type?: 'line' | 'bar'
  title?: string
  description?: string
  className?: string
}

export function TrafficChart({ 
  data, 
  type = 'line', 
  title = '流量统计',
  description = '网络流量使用趋势',
  className 
}: TrafficChartProps) {
  const chartRef = useRef<ChartJS>(null)

  // 准备图表数据
  const labels = data.map(item => {
    const date = new Date(item.date)
    return date.toLocaleDateString('zh-CN', { 
      month: 'short', 
      day: 'numeric' 
    })
  })

  const chartData = {
    labels,
    datasets: [
      {
        label: '上传流量',
        data: data.map(item => item.upload),
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: type === 'bar' 
          ? 'rgba(59, 130, 246, 0.8)'
          : 'rgba(59, 130, 246, 0.1)',
        fill: type === 'line',
        tension: 0.4,
      },
      {
        label: '下载流量',
        data: data.map(item => item.download),
        borderColor: 'rgb(168, 85, 247)',
        backgroundColor: type === 'bar'
          ? 'rgba(168, 85, 247, 0.8)'
          : 'rgba(168, 85, 247, 0.1)',
        fill: type === 'line',
        tension: 0.4,
      },
    ],
  }

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: {
      mode: 'index' as const,
      intersect: false,
    },
    plugins: {
      legend: {
        position: 'top' as const,
      },
      tooltip: {
        callbacks: {
          label: function(context: { dataset: { label?: string }, parsed: { y: number } }) {
            return `${context.dataset.label || ''}: ${formatBytes(context.parsed.y)}`
          }
        }
      }
    },
    scales: {
      x: {
        display: true,
        title: {
          display: true,
          text: '日期'
        },
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
        }
      },
      y: {
        display: true,
        title: {
          display: true,
          text: '流量 (字节)'
        },
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
        },
        ticks: {
          callback: function(value: number | string) {
            return formatBytes(Number(value))
          }
        }
      },
    },
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {type === 'line' ? <TrendingUp className="w-5 h-5" /> : <BarChart3 className="w-5 h-5" />}
          {title}
        </CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          {type === 'line' ? (
            <Line data={chartData} options={options} />
          ) : (
            <Bar data={chartData} options={options} />
          )}
        </div>
      </CardContent>
    </Card>
  )
}
