"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { 
  Bell, 
  Mail, 
  MessageSquare, 
  Smartphone,
  Save,
  Check
} from "lucide-react"

interface NotificationSetting {
  id: string
  name: string
  description: string
  enabled: boolean
  channels: {
    email: boolean
    telegram: boolean
    webhook: boolean
  }
}

export function NotificationSettings() {
  const [settings, setSettings] = useState<NotificationSetting[]>([
    {
      id: "tunnel_status",
      name: "隧道状态变化",
      description: "当隧道上线、离线或出现错误时通知",
      enabled: true,
      channels: { email: true, telegram: false, webhook: false }
    },
    {
      id: "node_status", 
      name: "节点状态变化",
      description: "当节点上线、离线或出现故障时通知",
      enabled: true,
      channels: { email: true, telegram: true, webhook: false }
    },
    {
      id: "quota_alert",
      name: "配额预警",
      description: "当流量、连接数等接近限额时通知",
      enabled: true,
      channels: { email: true, telegram: false, webhook: false }
    },
    {
      id: "subscription_expiry",
      name: "订阅到期提醒",
      description: "在套餐到期前通知您续费",
      enabled: true,
      channels: { email: true, telegram: true, webhook: false }
    },
    {
      id: "security_alerts",
      name: "安全警报",
      description: "异常登录、API访问等安全事件通知",
      enabled: true,
      channels: { email: true, telegram: false, webhook: true }
    }
  ])
  
  const [telegramId, setTelegramId] = useState("@your_telegram")
  const [webhookUrl, setWebhookUrl] = useState("")
  const [saving, setSaving] = useState(false)

  const toggleSetting = (id: string) => {
    setSettings(prev => prev.map(setting => 
      setting.id === id 
        ? { ...setting, enabled: !setting.enabled }
        : setting
    ))
  }

  const toggleChannel = (settingId: string, channel: keyof NotificationSetting['channels']) => {
    setSettings(prev => prev.map(setting => 
      setting.id === settingId 
        ? { 
            ...setting, 
            channels: { 
              ...setting.channels, 
              [channel]: !setting.channels[channel] 
            } 
          }
        : setting
    ))
  }

  const handleSave = async () => {
    setSaving(true)
    // 模拟API调用
    setTimeout(() => {
      setSaving(false)
    }, 1000)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="w-5 h-5" />
          通知设置
        </CardTitle>
        <CardDescription>
          管理您希望接收的通知类型和通知渠道
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* 通知渠道配置 */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium">通知渠道</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="telegram">Telegram ID</Label>
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-muted-foreground" />
                <Input
                  id="telegram"
                  value={telegramId}
                  onChange={(e) => setTelegramId(e.target.value)}
                  placeholder="@your_telegram_username"
                />
              </div>
              <p className="text-xs text-muted-foreground">
                添加 @relayX_group 机器人并发送 /start 获取您的ID
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="webhook">Webhook URL</Label>
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-muted-foreground" />
                <Input
                  id="webhook"
                  value={webhookUrl}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                  placeholder="https://your-app.com/webhook"
                />
              </div>
              <p className="text-xs text-muted-foreground">
                用于第三方应用集成的webhook地址
              </p>
            </div>
          </div>
        </div>

        {/* 通知设置列表 */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium">通知类型</h3>
          
          <div className="space-y-4">
            {settings.map((setting) => (
              <div key={setting.id} className="border rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1">
                      <h4 className="font-medium">{setting.name}</h4>
                      <Badge variant={setting.enabled ? "success" : "secondary"}>
                        {setting.enabled ? "已启用" : "已禁用"}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{setting.description}</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => toggleSetting(setting.id)}
                  >
                    {setting.enabled ? "禁用" : "启用"}
                  </Button>
                </div>
                
                {setting.enabled && (
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">通知渠道：</p>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        variant={setting.channels.email ? "relay" : "outline"}
                        size="sm"
                        onClick={() => toggleChannel(setting.id, 'email')}
                        className="text-xs"
                      >
                        <Mail className="w-3 h-3 mr-1" />
                        邮件
                        {setting.channels.email && <Check className="w-3 h-3 ml-1" />}
                      </Button>
                      
                      <Button
                        variant={setting.channels.telegram ? "relay" : "outline"}
                        size="sm"
                        onClick={() => toggleChannel(setting.id, 'telegram')}
                        className="text-xs"
                      >
                        <MessageSquare className="w-3 h-3 mr-1" />
                        Telegram
                        {setting.channels.telegram && <Check className="w-3 h-3 ml-1" />}
                      </Button>
                      
                      <Button
                        variant={setting.channels.webhook ? "relay" : "outline"}
                        size="sm"
                        onClick={() => toggleChannel(setting.id, 'webhook')}
                        className="text-xs"
                      >
                        <Smartphone className="w-3 h-3 mr-1" />
                        Webhook
                        {setting.channels.webhook && <Check className="w-3 h-3 ml-1" />}
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-end pt-4 border-t">
          <Button onClick={handleSave} disabled={saving} variant="relay">
            <Save className="w-4 h-4 mr-2" />
            {saving ? "保存中..." : "保存设置"}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
