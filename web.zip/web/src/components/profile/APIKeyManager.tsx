"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { 
  Key, 
  Plus, 
  Copy, 
  Trash2, 
  Eye, 
  EyeOff,
  Calendar,
  Shield
} from "lucide-react"
import { formatDate } from "@/lib/utils"

interface APIKey {
  id: string
  name: string
  key: string
  created_at: string
  last_used?: string
  permissions: string[]
}

export function APIKeyManager() {
  const [apiKeys, setApiKeys] = useState<APIKey[]>([
    {
      id: "1",
      name: "默认API密钥",
      key: "a80c764e-5ccf-4e4d-bdf7-6c3c5da99f08",
      created_at: new Date().toISOString(),
      last_used: new Date().toISOString(),
      permissions: ["read", "write"]
    }
  ])
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({})
  const [newKeyName, setNewKeyName] = useState("")
  const [isCreating, setIsCreating] = useState(false)

  const handleCreateKey = async () => {
    if (!newKeyName.trim()) return
    
    setIsCreating(true)
    // 模拟API调用
    setTimeout(() => {
      const newKey: APIKey = {
        id: Date.now().toString(),
        name: newKeyName,
        key: `rk_${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`,
        created_at: new Date().toISOString(),
        permissions: ["read", "write"]
      }
      setApiKeys([...apiKeys, newKey])
      setNewKeyName("")
      setIsCreating(false)
    }, 1000)
  }

  const handleDeleteKey = (id: string) => {
    if (confirm("确定要删除这个API密钥吗？删除后无法恢复。")) {
      setApiKeys(apiKeys.filter(key => key.id !== id))
    }
  }

  const handleCopyKey = (key: string) => {
    navigator.clipboard.writeText(key)
    // 这里可以添加toast提示
  }

  const toggleKeyVisibility = (id: string) => {
    setShowKeys(prev => ({
      ...prev,
      [id]: !prev[id]
    }))
  }

  const maskKey = (key: string) => {
    if (key.length <= 8) return key
    return key.slice(0, 4) + '•'.repeat(key.length - 8) + key.slice(-4)
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Key className="w-5 h-5" />
              API 密钥管理
            </CardTitle>
            <CardDescription>
              管理您的API密钥，用于程序化访问RelayX服务
            </CardDescription>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="relay">
                <Plus className="w-4 h-4 mr-2" />
                创建密钥
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>创建新的API密钥</DialogTitle>
                <DialogDescription>
                  为您的应用程序创建一个新的API密钥。请妥善保管，密钥只会显示一次。
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="keyName">密钥名称</Label>
                  <Input
                    id="keyName"
                    value={newKeyName}
                    onChange={(e) => setNewKeyName(e.target.value)}
                    placeholder="例如：我的应用API密钥"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setNewKeyName("")}>
                  取消
                </Button>
                <Button 
                  onClick={handleCreateKey} 
                  disabled={!newKeyName.trim() || isCreating}
                  variant="relay"
                >
                  {isCreating ? "创建中..." : "创建密钥"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {apiKeys.length === 0 ? (
          <div className="text-center py-8">
            <Key className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">还没有API密钥</h3>
            <p className="text-muted-foreground mb-4">
              创建您的第一个API密钥来开始使用程序化访问
            </p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>名称</TableHead>
                <TableHead>密钥</TableHead>
                <TableHead>权限</TableHead>
                <TableHead>最后使用</TableHead>
                <TableHead>创建时间</TableHead>
                <TableHead className="text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {apiKeys.map((apiKey) => (
                <TableRow key={apiKey.id}>
                  <TableCell className="font-medium">{apiKey.name}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <code className="text-sm font-mono bg-muted px-2 py-1 rounded">
                        {showKeys[apiKey.id] ? apiKey.key : maskKey(apiKey.key)}
                      </code>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleKeyVisibility(apiKey.id)}
                      >
                        {showKeys[apiKey.id] ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleCopyKey(apiKey.key)}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      {apiKey.permissions.map((permission) => (
                        <Badge key={permission} variant="outline" className="text-xs">
                          {permission}
                        </Badge>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>
                    {apiKey.last_used ? (
                      <div className="flex items-center gap-1 text-sm">
                        <Calendar className="w-3 h-3" />
                        {formatDate(apiKey.last_used, false)}
                      </div>
                    ) : (
                      <span className="text-muted-foreground text-sm">从未使用</span>
                    )}
                  </TableCell>
                  <TableCell className="text-sm">
                    {formatDate(apiKey.created_at, false)}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteKey(apiKey.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
        
        <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-blue-900 mb-1">安全提示</p>
              <ul className="text-blue-800 space-y-1">
                <li>• API密钥具有与您账户相同的权限，请妥善保管</li>
                <li>• 不要在客户端代码中暴露API密钥</li>
                <li>• 如果密钥泄露，请立即删除并重新创建</li>
                <li>• 建议定期轮换您的API密钥</li>
              </ul>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
