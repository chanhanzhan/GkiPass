"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { StatCard } from "@/components/dashboard/StatCard"
import { 
  Server, 
  Activity, 
  Wifi, 
  AlertTriangle,
  TrendingUp
} from "lucide-react"
import type { Node } from "@/types"

interface NodeStatsOverviewProps {
  nodes: Node[]
}

export function NodeStatsOverview({ nodes }: NodeStatsOverviewProps) {
  const totalNodes = nodes.length
  const onlineNodes = nodes.filter(node => node.status === 'online').length
  const offlineNodes = totalNodes - onlineNodes
  const entryNodes = nodes.filter(node => node.type === 'entry').length
  const exitNodes = nodes.filter(node => node.type === 'exit').length
  
  const onlinePercentage = totalNodes > 0 ? Math.round((onlineNodes / totalNodes) * 100) : 0

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <StatCard
        title="节点总数"
        value={totalNodes}
        description={`${entryNodes} 入口 • ${exitNodes} 出口`}
        icon={<Server className="w-5 h-5" />}
        color="relay"
      />
      
      <StatCard
        title="在线节点"
        value={onlineNodes}
        description={`在线率 ${onlinePercentage}%`}
        icon={<Wifi className="w-5 h-5" />}
        color="green"
        change={{
          value: onlinePercentage,
          type: onlinePercentage >= 90 ? 'increase' : onlinePercentage >= 70 ? 'neutral' : 'decrease'
        }}
      />
      
      <StatCard
        title="离线节点"
        value={offlineNodes}
        description={offlineNodes > 0 ? "需要检查" : "运行稳定"}
        icon={<AlertTriangle className="w-5 h-5" />}
        color={offlineNodes > 0 ? "red" : "green"}
      />
      
      <StatCard
        title="节点性能"
        value="优秀"
        description="平均响应时间 < 50ms"
        icon={<TrendingUp className="w-5 h-5" />}
        color="tunnel"
      />
    </div>
  )
}
