"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { cn, formatDate, getNodeTypeText } from "@/lib/utils"
import { 
  Server, 
  Activity, 
  Wifi, 
  WifiOff, 
  Eye,
  MapPin,
  Calendar,
  Hash
} from "lucide-react"
import Link from "next/link"
import type { Node } from "@/types"

interface NodeStatusCardProps {
  node: Node
  className?: string
}

export function NodeStatusCard({ node, className }: NodeStatusCardProps) {
  const isOnline = node.status === 'online'
  
  return (
    <Card className={cn("hover:shadow-lg transition-all duration-200", className)}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={cn(
              "p-2 rounded-lg",
              isOnline 
                ? "bg-green-100 text-green-600" 
                : "bg-gray-100 text-gray-600"
            )}>
              <Server className="w-5 h-5" />
            </div>
            <div>
              <CardTitle className="text-lg">{node.name}</CardTitle>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant={node.type === 'entry' ? 'relay' : 'tunnel'}>
                  {getNodeTypeText(node.type)}
                </Badge>
                <Badge variant={isOnline ? 'success' : 'secondary'}>
                  {isOnline ? (
                    <div className="flex items-center gap-1">
                      <Wifi className="w-3 h-3" />
                      在线
                    </div>
                  ) : (
                    <div className="flex items-center gap-1">
                      <WifiOff className="w-3 h-3" />
                      离线
                    </div>
                  )}
                </Badge>
              </div>
            </div>
          </div>
          <Button variant="outline" size="sm" asChild>
            <Link href={`/nodes/${node.id}`}>
              <Eye className="w-4 h-4" />
            </Link>
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-muted-foreground" />
            <span className="font-mono">{node.ip}:{node.port}</span>
          </div>
          <div className="flex items-center gap-2">
            <Hash className="w-4 h-4 text-muted-foreground" />
            <span className="font-mono text-xs">{node.id.substring(0, 8)}...</span>
          </div>
        </div>
        
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Calendar className="w-3 h-3" />
          <span>创建于 {formatDate(node.created_at, false)}</span>
        </div>

        {/* 在线状态指示器 */}
        <div className="flex items-center justify-between pt-2 border-t">
          <div className="flex items-center gap-2">
            <div className={cn(
              "w-2 h-2 rounded-full",
              isOnline ? "bg-green-500 animate-pulse" : "bg-gray-400"
            )} />
            <span className="text-xs text-muted-foreground">
              {isOnline ? "实时在线" : "连接中断"}
            </span>
          </div>
          {isOnline && (
            <div className="flex items-center gap-1 text-xs text-green-600">
              <Activity className="w-3 h-3" />
              <span>正常运行</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
