"use client"
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck

import React from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { cn, formatBytes } from "@/lib/utils"
import { 
  Cpu, 
  MemoryStick, 
  HardDrive, 
  Wifi,
  Activity,
  Zap,
  Clock,
  TrendingUp
} from "lucide-react"

interface NodeMetricsCardProps {
  status: any
  isConnected: boolean
  className?: string
}

export function NodeMetricsCard({ status, isConnected, className }: NodeMetricsCardProps) {
  if (!status) {
    return (
      <Card className={cn("", className)}>
        <CardContent className="p-6 text-center">
          <div className="text-muted-foreground">
            <Activity className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>无法获取节点状态信息</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  const isOnline = status.online
  const cpuUsage = Number(status.cpu_usage) || 0
  const memoryUsage = Number(status.memory_usage) || 0
  const diskUsage = Number(status.disk_usage) || 0
  const connections = Number(status.connections) || 0

  const getCpuColor = (usage: number) => {
    if (usage < 30) return "text-green-600 bg-green-50"
    if (usage < 70) return "text-yellow-600 bg-yellow-50"
    return "text-red-600 bg-red-50"
  }

  const getMemoryColor = (usage: number) => {
    if (usage < 1024 * 1024 * 1024) return "text-green-600 bg-green-50" // < 1GB
    if (usage < 2 * 1024 * 1024 * 1024) return "text-yellow-600 bg-yellow-50" // < 2GB
    return "text-red-600 bg-red-50"
  }

  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5" />
            实时状态
          </CardTitle>
          <div className="flex items-center gap-2">
            {isConnected && (
              <Badge variant="success" className="text-xs">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-1 animate-pulse" />
                实时连接
              </Badge>
            )}
            <Badge variant={isOnline ? "success" : "secondary"}>
              {isOnline ? "在线" : "离线"}
            </Badge>
          </div>
        </div>
        <CardDescription>
          节点系统资源使用情况和连接状态
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* CPU 使用率 */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={cn("p-2 rounded-lg", getCpuColor(cpuUsage))}>
                <Cpu className="w-4 h-4" />
              </div>
              <span className="font-medium">CPU 使用率</span>
            </div>
            <span className="text-2xl font-bold">{cpuUsage.toFixed(1)}%</span>
          </div>
          <div className="w-full bg-muted rounded-full h-3">
            <div
              className={cn(
                "h-3 rounded-full transition-all duration-500",
                cpuUsage < 30 ? "bg-green-500" : 
                cpuUsage < 70 ? "bg-yellow-500" : "bg-red-500"
              )}
              style={{ width: `${Math.min(cpuUsage, 100)}%` }}
            />
          </div>
        </div>

        {/* 内存使用 */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={cn("p-2 rounded-lg", getMemoryColor(memoryUsage))}>
                <MemoryStick className="w-4 h-4" />
              </div>
              <span className="font-medium">内存使用</span>
            </div>
            <span className="text-lg font-bold">{formatBytes(memoryUsage)}</span>
          </div>
        </div>

        {/* 磁盘使用 */}
        {typeof diskUsage === "number" && diskUsage > 0 && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
                  <HardDrive className="w-4 h-4" />
                </div>
                <span className="font-medium">磁盘使用</span>
              </div>
              <span className="text-lg font-bold">{formatBytes(diskUsage)}</span>
            </div>
          </div>
        )}

        {/* 网络连接 */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-purple-50 text-purple-600">
                <Wifi className="w-4 h-4" />
              </div>
              <span className="font-medium text-sm">活跃连接</span>
            </div>
            <p className="text-2xl font-bold">{connections}</p>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-orange-50 text-orange-600">
                <Zap className="w-4 h-4" />
              </div>
              <span className="font-medium text-sm">性能等级</span>
            </div>
            <p className="text-lg font-bold">
              {cpuUsage < 30 ? "优秀" : cpuUsage < 70 ? "良好" : "繁忙"}
            </p>
          </div>
        </div>

        {/* 最后心跳 */}
        {status.last_heartbeat && (
          <div className="pt-4 border-t">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span>最后心跳：{new Date(String(status.last_heartbeat)).toLocaleString()}</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
