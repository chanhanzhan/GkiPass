/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import { useToast } from '@/components/ui/Toast';

interface PaymentDialogProps {
  open: boolean;
  onClose: () => void;
  amount: number;
  type: 'recharge' | 'purchase';
  onSuccess?: () => void;
}

const PAYMENT_METHODS = [
  {
    id: 'alipay',
    name: '支付宝',
    icon: '💳',
    color: 'from-blue-500 to-cyan-500',
    enabled: true,
  },
  {
    id: 'wechat',
    name: '微信支付',
    icon: '💚',
    color: 'from-green-500 to-emerald-500',
    enabled: true,
  },
  {
    id: 'usdt',
    name: 'USDT (TRC20)',
    icon: '₮',
    color: 'from-emerald-500 to-teal-500',
    enabled: true,
  },
];

export function PaymentDialog({ open, onClose, amount, type, onSuccess }: PaymentDialogProps) {
  const { showToast } = useToast();
  const [selectedMethod, setSelectedMethod] = useState('alipay');
  const [loading, setLoading] = useState(false);
  const [orderData, setOrderData] = useState<any>(null);
  const [countdown, setCountdown] = useState(900); // 15分钟
  const [polling, setPolling] = useState(false);

  // 创建订单
  const handleCreateOrder = async () => {
    if (!selectedMethod) {
      showToast('error', '请选择支付方式');
      return;
    }

    try {
      setLoading(true);
      const data = await api.wallet.recharge(amount, selectedMethod);
      setOrderData(data);
      
      // 开始轮询订单状态
      setPolling(true);
      showToast('success', '订单创建成功，请扫码支付');
    } catch (error: any) {
      showToast('error', error?.message || '创建订单失败');
    } finally {
      setLoading(false);
    }
  };

  // 轮询订单状态
  useEffect(() => {
    if (!polling || !orderData?.order_id) return;

    const interval = setInterval(async () => {
      try {
        const status = await api.payment.queryOrder(orderData.order_id);
        if (status.status === 'completed') {
          setPolling(false);
          showToast('success', '支付成功！');
          if (onSuccess) onSuccess();
          setTimeout(() => onClose(), 1500);
        } else if (status.status === 'failed' || status.status === 'cancelled') {
          setPolling(false);
          showToast('error', '支付失败或已取消');
        }
      } catch (error) {
        console.error('Failed to query order status:', error);
      }
    }, 3000); // 每3秒查询一次

    return () => clearInterval(interval);
  }, [polling, orderData]);

  // 倒计时
  useEffect(() => {
    if (!orderData) return;

    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          setPolling(false);
          showToast('warning', '订单已超时，请重新下单');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [orderData]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const handleClose = () => {
    setPolling(false);
    setOrderData(null);
    setCountdown(900);
    onClose();
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        {/* 标题 */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">
              {type === 'recharge' ? '充值' : '购买套餐'}
            </h2>
            <p className="text-sm text-gray-500 mt-1">请选择支付方式完成支付</p>
          </div>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* 内容 */}
        <div className="p-6">
          {!orderData ? (
            <>
              {/* 支付金额 */}
              <div className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl p-6 text-white mb-6">
                <p className="text-sm opacity-90 mb-1">支付金额</p>
                <p className="text-4xl font-black">¥ {amount.toFixed(2)}</p>
              </div>

              {/* 支付方式选择 */}
              <div className="space-y-3 mb-6">
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  选择支付方式
                </label>
                {PAYMENT_METHODS.map(method => (
                  <button
                    key={method.id}
                    onClick={() => method.enabled && setSelectedMethod(method.id)}
                    disabled={!method.enabled}
                    className={`w-full p-4 rounded-xl border-2 transition-all text-left ${
                      selectedMethod === method.id
                        ? 'border-purple-500 bg-purple-50'
                        : method.enabled
                        ? 'border-gray-200 hover:border-gray-300'
                        : 'border-gray-200 opacity-50 cursor-not-allowed'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{method.icon}</span>
                      <div className="flex-1">
                        <div className="font-bold text-gray-900">{method.name}</div>
                        {!method.enabled && (
                          <div className="text-xs text-gray-500">暂未开通</div>
                        )}
                      </div>
                      {selectedMethod === method.id && (
                        <svg className="w-6 h-6 text-purple-600" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </>
          ) : (
            <>
              {/* 支付二维码 */}
              <div className="bg-gray-50 rounded-xl p-6 mb-6">
                <div className="text-center mb-4">
                  <div className="inline-block p-6 bg-white rounded-xl shadow-lg mb-4">
                    {/* 模拟二维码 - 实际应该使用 qrcode.react 生成 */}
                    <div className="w-48 h-48 bg-gradient-to-br from-gray-800 to-gray-600 rounded-lg flex items-center justify-center">
                      <div className="text-white text-center">
                        <div className="text-4xl mb-2">📱</div>
                        <div className="text-xs">扫码支付</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <p className="text-lg font-bold text-gray-900">
                      请使用{PAYMENT_METHODS.find(m => m.id === selectedMethod)?.name}扫码支付
                    </p>
                    <p className="text-2xl font-black text-purple-600">
                      ¥ {amount.toFixed(2)}
                    </p>
                    
                    {/* 倒计时 */}
                    <div className="flex items-center justify-center gap-2 text-sm text-gray-600">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <span>有效期：{formatTime(countdown)}</span>
                    </div>
                  </div>
                </div>

                {/* USDT地址（如果是加密货币支付） */}
                {selectedMethod === 'usdt' && orderData.payment_data?.address && (
                  <div className="mt-4 p-4 bg-yellow-50 border-2 border-yellow-200 rounded-lg">
                    <p className="text-sm font-semibold text-gray-700 mb-2">
                      USDT-TRC20 转账地址
                    </p>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={orderData.payment_data.address}
                        readOnly
                        className="flex-1 px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm font-mono"
                      />
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(orderData.payment_data.address);
                          showToast('success', '地址已复制');
                        }}
                        className="px-4 py-2 bg-yellow-500 hover:bg-yellow-600 text-white rounded-lg font-bold transition-colors"
                      >
                        复制
                      </button>
                    </div>
                    <p className="text-xs text-gray-600 mt-2">
                      转账金额：{orderData.payment_data.usdt_amount} USDT
                    </p>
                  </div>
                )}

                {/* 支付状态 */}
                {polling && (
                  <div className="mt-4 flex items-center justify-center gap-2 text-blue-600">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
                    <span className="text-sm font-medium">等待支付...</span>
                  </div>
                )}
              </div>

              {/* 支付说明 */}
              <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4">
                <h4 className="text-sm font-bold text-gray-900 mb-2">💡 支付说明</h4>
                <ul className="text-xs text-gray-600 space-y-1">
                  <li>• 请在{formatTime(countdown)}内完成支付</li>
                  <li>• 支付完成后将自动到账，无需刷新页面</li>
                  <li>• 如遇问题请联系客服</li>
                </ul>
              </div>
            </>
          )}
        </div>

        {/* 底部按钮 */}
        <div className="flex justify-end gap-3 p-6 border-t border-gray-200">
          <button
            onClick={handleClose}
            className="px-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-900 rounded-xl font-semibold transition-colors"
          >
            {orderData ? '关闭' : '取消'}
          </button>
          {!orderData && (
            <button
              onClick={handleCreateOrder}
              disabled={loading || !selectedMethod}
              className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-xl font-semibold transition-all shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? '创建中...' : '确认支付'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

