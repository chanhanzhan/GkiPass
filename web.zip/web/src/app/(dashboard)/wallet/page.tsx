/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import { formatDate } from '@/lib/utils';
import { useToast } from '@/components/ui/Toast';
import { PaymentDialog } from '@/components/payment/PaymentDialog';
import { JSX } from 'react/jsx-runtime';

export default function WalletPage() {
  const [balance, setBalance] = useState(0);
  const [frozen, setFrozen] = useState(0);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showRecharge, setShowRecharge] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [rechargeAmount, setRechargeAmount] = useState('100');
  const [selectedAmount, setSelectedAmount] = useState(0);
  const { showToast } = useToast();

  useEffect(() => {
    loadWalletData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadWalletData() {
    try {
      const [balanceData, txData] = await Promise.all([
        api.wallet.getBalance(),
        api.wallet.getTransactions(),
      ]);
      setBalance(balanceData.balance || 0);
      setFrozen(balanceData.frozen || 0);
      const txList = txData.data || txData || [];
      setTransactions(Array.isArray(txList) ? txList : []);
    } catch (error) {
      console.error('Failed to load wallet data:', error);
      showToast('error', '加载钱包数据失败');
    } finally {
      setLoading(false);
    }
  }

  async function handleCreateRecharge() {
    const amount = parseFloat(rechargeAmount);
    if (isNaN(amount) || amount < 10) {
      showToast('error', '充值金额最低为10元');
      return;
    }

    setSelectedAmount(amount);
    setShowRecharge(false);
    setShowPayment(true);
  }

  const getTransactionTypeText = (type: string) => {
    const types: Record<string, string> = {
      recharge: '充值',
      purchase: '购买套餐',
      refund: '退款',
      deduction: '扣款',
    };
    return types[type] || type;
  };

  const getTransactionStatusBadge = (status: string) => {
    const badges: Record<string, JSX.Element> = {
      completed: <span className="px-2 py-1 text-xs font-bold bg-green-100 text-green-700 rounded-full">✓ 已完成</span>,
      pending: <span className="px-2 py-1 text-xs font-bold bg-yellow-100 text-yellow-700 rounded-full">⏳ 处理中</span>,
      failed: <span className="px-2 py-1 text-xs font-bold bg-red-100 text-red-700 rounded-full">✗ 失败</span>,
    };
    return badges[status] || <span className="px-2 py-1 text-xs font-bold bg-gray-100 text-gray-700 rounded-full">{status}</span>;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 rounded-2xl p-6 text-white shadow-xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-black mb-2">我的钱包</h1>
            <p className="text-green-100">管理您的账户余额和交易记录</p>
          </div>
          <div className="text-6xl">💰</div>
        </div>
      </div>

      {/* 余额卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl p-8 text-white shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <span className="text-blue-100 text-lg">可用余额</span>
            <span className="text-4xl">💵</span>
          </div>
          <div className="text-5xl font-black mb-2">¥{balance.toFixed(2)}</div>
          <button
            onClick={() => setShowRecharge(true)}
            className="mt-4 w-full bg-white/20 hover:bg-white/30 backdrop-blur-xl py-3 rounded-xl font-bold transition-all duration-300"
          >
            立即充值
          </button>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-red-600 rounded-2xl p-8 text-white shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <span className="text-orange-100 text-lg">冻结金额</span>
            <span className="text-4xl">🔒</span>
          </div>
          <div className="text-5xl font-black mb-2">¥{frozen.toFixed(2)}</div>
          <p className="text-orange-100 text-sm mt-4">
            冻结金额为待结算或争议金额
          </p>
        </div>
      </div>

      {/* 交易记录 */}
      <div className="bg-white rounded-2xl shadow-xl p-6">
        <h2 className="text-2xl font-black text-gray-900 mb-6">交易记录</h2>
        
        {transactions.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📝</div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">暂无交易记录</h3>
            <p className="text-gray-500">您的所有交易记录将显示在这里</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b-2 border-gray-200">
                  <th className="text-left py-3 px-4 font-bold text-gray-700">类型</th>
                  <th className="text-left py-3 px-4 font-bold text-gray-700">金额</th>
                  <th className="text-left py-3 px-4 font-bold text-gray-700">余额</th>
                  <th className="text-left py-3 px-4 font-bold text-gray-700">状态</th>
                  <th className="text-left py-3 px-4 font-bold text-gray-700">时间</th>
                  <th className="text-left py-3 px-4 font-bold text-gray-700">备注</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((tx, index) => (
                  <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4 px-4">
                      <span className="font-semibold text-gray-900">
                        {getTransactionTypeText(tx.type)}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <span className={`font-bold ${tx.amount >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {tx.amount >= 0 ? '+' : ''}{tx.amount.toFixed(2)}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-gray-700">¥{tx.balance?.toFixed(2) || '0.00'}</span>
                    </td>
                    <td className="py-4 px-4">
                      {getTransactionStatusBadge(tx.status)}
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-gray-600 text-sm">{formatDate(tx.created_at)}</span>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-gray-600 text-sm">{tx.description || '-'}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 充值弹窗 */}
      {showRecharge && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full mx-4 shadow-2xl">
            <h2 className="text-2xl font-black text-gray-900 mb-6">充值钱包</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  充值金额（最低10元）
                </label>
                <input
                  type="number"
                  value={rechargeAmount}
                  onChange={(e) => setRechargeAmount(e.target.value)}
                  min="10"
                  step="10"
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:outline-none text-lg font-bold"
                />
                <div className="flex gap-2 mt-2">
                  {[50, 100, 200, 500].map((amt) => (
                    <button
                      key={amt}
                      onClick={() => setRechargeAmount(String(amt))}
                      className="flex-1 px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg font-bold text-sm transition-colors"
                    >
                      ¥{amt}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowRecharge(false)}
                className="flex-1 px-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-900 rounded-xl font-bold transition-colors"
              >
                取消
              </button>
              <button
                onClick={handleCreateRecharge}
                disabled={loading}
                className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-xl font-bold transition-all shadow-lg hover:shadow-xl disabled:opacity-50"
              >
                {loading ? '处理中...' : '下一步'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 支付对话框 */}
      <PaymentDialog
        open={showPayment}
        onClose={() => {
          setShowPayment(false);
          setSelectedAmount(0);
        }}
        amount={selectedAmount}
        type="recharge"
        onSuccess={() => {
          loadWalletData();
        }}
      />
    </div>
  );
}
