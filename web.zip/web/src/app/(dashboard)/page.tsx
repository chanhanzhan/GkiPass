/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { api } from '@/lib/api';
import { formatBytes, formatDate } from '@/lib/utils';

export default function DashboardPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    balance: 0,
    traffic: { used: 0, total: 0 },
    tunnels: { active: 0, total: 0 },
    subscription: null as any,
  });
  const [recentTunnels, setRecentTunnels] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);

  useEffect(() => {
    loadDashboardData();
  }, []);

  async function loadDashboardData() {
    try {
      const [walletData, tunnelsData, subscriptionData, notificationData] = await Promise.all([
        api.wallet.getBalance().catch(() => ({ balance: 0, frozen: 0 })),
        api.tunnels.list().catch(() => ({ tunnels: [], total: 0 })),
        api.subscriptions.current().catch(() => null),
        api.notifications.list({ limit: 5 }).catch(() => ({ data: [] })),
      ]);

      // 统计数据
      const tunnelsList = tunnelsData.tunnels || tunnelsData.data || [];
      const activeTunnels = tunnelsList.filter((t: any) => t.status === 'active').length;

      setStats({
        balance: walletData.balance || 0,
        traffic: {
          used: subscriptionData?.used_traffic || 0,
          total: subscriptionData?.traffic || 0,
        },
        tunnels: {
          active: activeTunnels,
          total: tunnelsList.length,
        },
        subscription: subscriptionData,
      });

      setRecentTunnels(tunnelsList.slice(0, 5));
      setNotifications(notificationData.data || notificationData.notifications || []);
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  }

  const calculatePercentage = (used: number, total: number) => {
    if (total === 0) return 0;
    return Math.min(100, (used / total) * 100);
  };

  const getProgressColor = (percentage: number) => {
    if (percentage < 60) return 'bg-green-500';
    if (percentage < 80) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getStatusBadge = (status: string) => {
    const badges: Record<string, React.ReactElement> = {
      active: <span className="px-2 py-1 text-xs font-bold bg-green-100 text-green-700 rounded-full">🟢 运行中</span>,
      inactive: <span className="px-2 py-1 text-xs font-bold bg-gray-100 text-gray-700 rounded-full">⚫ 已停止</span>,
      error: <span className="px-2 py-1 text-xs font-bold bg-red-100 text-red-700 rounded-full">🔴 错误</span>,
    };
    return badges[status] || <span className="px-2 py-1 text-xs font-bold bg-gray-100 text-gray-700 rounded-full">{status}</span>;
  };

  if (loading) {
    return (
      <ProtectedRoute>
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">正在加载...</p>
          </div>
        </div>
      </ProtectedRoute>
    );
  }

  const trafficPercentage = calculatePercentage(stats.traffic.used, stats.traffic.total);

  return (
    <ProtectedRoute>
      <div className="space-y-6">
        {/* 欢迎横幅 */}
        <div className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-2xl p-6 text-white shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-black mb-2">欢迎回来！</h1>
              <p className="text-blue-100">查看您的服务概览和最新动态</p>
            </div>
            <div className="text-6xl">👋</div>
          </div>
        </div>

        {/* 核心统计卡片 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* 钱包余额 */}
          <div 
            onClick={() => router.push('/wallet')}
            className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl p-6 text-white shadow-lg hover:shadow-2xl transition-all cursor-pointer transform hover:-translate-y-1"
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm opacity-90">钱包余额</span>
              <span className="text-3xl">💰</span>
            </div>
            <div className="text-3xl font-black mb-1">¥{stats.balance.toFixed(2)}</div>
            <div className="text-xs opacity-75">点击查看详情 →</div>
          </div>

          {/* 流量使用 */}
          <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-gray-100 hover:shadow-2xl transition-all">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-semibold text-gray-600">流量使用</span>
              <span className="text-3xl">📊</span>
            </div>
            <div className="mb-2">
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-black text-gray-900">
                  {formatBytes(stats.traffic.used)}
                </span>
                <span className="text-sm text-gray-500">
                  / {formatBytes(stats.traffic.total)}
                </span>
              </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
              <div 
                className={`h-full rounded-full transition-all ${getProgressColor(trafficPercentage)}`}
                style={{ width: `${trafficPercentage}%` }}
              />
            </div>
          </div>

          {/* 隧道统计 */}
          <div 
            onClick={() => router.push('/tunnels')}
            className="bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl p-6 text-white shadow-lg hover:shadow-2xl transition-all cursor-pointer transform hover:-translate-y-1"
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm opacity-90">隧道数量</span>
              <span className="text-3xl">🔌</span>
            </div>
            <div className="flex items-baseline gap-2 mb-1">
              <span className="text-3xl font-black">{stats.tunnels.active}</span>
              <span className="text-lg opacity-75">/ {stats.tunnels.total}</span>
            </div>
            <div className="text-xs opacity-75">活跃 / 总数</div>
          </div>

          {/* 订阅状态 */}
          <div className="bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl p-6 text-white shadow-lg hover:shadow-2xl transition-all">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm opacity-90">订阅状态</span>
              <span className="text-3xl">⭐</span>
            </div>
            {stats.subscription ? (
              <>
                <div className="text-2xl font-black mb-1">
                  {stats.subscription.plan_name || '已订阅'}
                </div>
                <div className="text-xs opacity-75">
                  到期：{formatDate(stats.subscription.expires_at, false)}
                </div>
              </>
            ) : (
              <>
                <div className="text-2xl font-black mb-1">未订阅</div>
                <button 
                  onClick={() => router.push('/plans')}
                  className="text-xs bg-white/20 hover:bg-white/30 px-3 py-1 rounded-lg mt-2 transition-colors"
                >
                  立即购买 →
                </button>
              </>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* 最近隧道 */}
          <div className="bg-white rounded-2xl shadow-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-black text-gray-900">最近隧道</h2>
              <button 
                onClick={() => router.push('/tunnels')}
                className="text-sm text-blue-600 hover:text-blue-700 font-semibold"
              >
                查看全部 →
              </button>
            </div>

            {recentTunnels.length === 0 ? (
              <div className="text-center py-8">
                <div className="text-4xl mb-2">🔌</div>
                <p className="text-gray-500 mb-4">还没有隧道</p>
                <button
                  onClick={() => router.push('/tunnels/create')}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold"
                >
                  创建隧道
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {recentTunnels.map((tunnel) => (
                  <div 
                    key={tunnel.id}
                    onClick={() => router.push(`/tunnels/${tunnel.id}`)}
                    className="border-2 border-gray-200 rounded-xl p-4 hover:border-blue-300 hover:shadow-md transition-all cursor-pointer"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-bold text-gray-900">{tunnel.name}</h4>
                      {getStatusBadge(tunnel.status)}
                    </div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <div>协议：{tunnel.protocol.toUpperCase()}</div>
                      <div>端口：{tunnel.port}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 系统通知 */}
          <div className="bg-white rounded-2xl shadow-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-black text-gray-900">系统通知</h2>
              <button 
                onClick={() => router.push('/notifications')}
                className="text-sm text-blue-600 hover:text-blue-700 font-semibold"
              >
                查看全部 →
              </button>
            </div>

            {notifications.length === 0 ? (
              <div className="text-center py-8">
                <div className="text-4xl mb-2">🔔</div>
                <p className="text-gray-500">暂无通知</p>
              </div>
            ) : (
              <div className="space-y-3">
                {notifications.map((notification) => (
                  <div 
                    key={notification.id}
                    className={`border-l-4 ${notification.is_read ? 'border-gray-300' : 'border-blue-500'} bg-gray-50 rounded-lg p-4`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className={`font-bold mb-1 ${notification.is_read ? 'text-gray-600' : 'text-gray-900'}`}>
                          {notification.title}
                        </h4>
                        <p className="text-sm text-gray-600 line-clamp-2">
                          {notification.content}
                        </p>
                        <p className="text-xs text-gray-500 mt-2">
                          {formatDate(notification.created_at)}
                        </p>
                      </div>
                      {!notification.is_read && (
                        <span className="ml-2 w-2 h-2 bg-blue-500 rounded-full"></span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* 快速操作 */}
        <div className="bg-gradient-to-r from-gray-800 to-gray-900 rounded-2xl p-6 text-white shadow-xl">
          <h2 className="text-2xl font-black mb-4">快速操作</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <button
              onClick={() => router.push('/tunnels/create')}
              className="bg-white/10 hover:bg-white/20 backdrop-blur-xl p-4 rounded-xl transition-all text-center"
            >
              <div className="text-3xl mb-2">➕</div>
              <div className="font-bold">创建隧道</div>
            </button>
            <button
              onClick={() => router.push('/wallet')}
              className="bg-white/10 hover:bg-white/20 backdrop-blur-xl p-4 rounded-xl transition-all text-center"
            >
              <div className="text-3xl mb-2">💳</div>
              <div className="font-bold">充值余额</div>
            </button>
            <button
              onClick={() => router.push('/plans')}
              className="bg-white/10 hover:bg-white/20 backdrop-blur-xl p-4 rounded-xl transition-all text-center"
            >
              <div className="text-3xl mb-2">📦</div>
              <div className="font-bold">购买套餐</div>
            </button>
            <button
              onClick={() => router.push('/admin/node-groups')}
              className="bg-white/10 hover:bg-white/20 backdrop-blur-xl p-4 rounded-xl transition-all text-center"
            >
              <div className="text-3xl mb-2">🖥️</div>
              <div className="font-bold">节点管理</div>
            </button>
          </div>
        </div>
      </div>
    </ProtectedRoute>
  );
}

