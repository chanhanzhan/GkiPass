/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { formatBytes, formatDate } from '@/lib/utils';

interface TrafficStat {
  id: string;
  tunnel_id: string;
  tunnel_name: string;
  entry_group_id: string;
  entry_group_name: string;
  exit_group_id: string;
  exit_group_name: string;
  traffic_in: number;
  traffic_out: number;
  billed_traffic_in: number;
  billed_traffic_out: number;
  date: string;
  created_at: string;
}

export default function TrafficStatsPage() {
  const [stats, setStats] = useState<TrafficStat[]>([]);
  const [loading, setLoading] = useState(true);
  const [tunnelFilter, setTunnelFilter] = useState('');
  const [tunnels, setTunnels] = useState<any[]>([]);

  useEffect(() => {
    loadData();
  }, [tunnelFilter]);

  async function loadData() {
    try {
      const [statsData, tunnelsData] = await Promise.all([
        api.trafficStats.list({ tunnel_id: tunnelFilter }),
        api.tunnels.list(),
      ]);
      
      setStats(statsData.data || []);
      setTunnels(tunnelsData.data || tunnelsData || []);
    } catch (error) {
      console.error('Failed to load traffic stats:', error);
    } finally {
      setLoading(false);
    }
  }

  // 计算汇总数据
  const summary = {
    totalTrafficIn: stats.reduce((sum, s) => sum + s.traffic_in, 0),
    totalTrafficOut: stats.reduce((sum, s) => sum + s.traffic_out, 0),
    totalBilledIn: stats.reduce((sum, s) => sum + s.billed_traffic_in, 0),
    totalBilledOut: stats.reduce((sum, s) => sum + s.billed_traffic_out, 0),
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="bg-gradient-to-r from-green-500 via-teal-500 to-blue-500 rounded-2xl p-6 text-white shadow-xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-black mb-2">隧道流量统计</h1>
            <p className="text-green-100">查看您的隧道流量使用情况</p>
          </div>
          <div className="text-6xl">📊</div>
        </div>
      </div>

      {/* 汇总卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-500 font-medium">实际入站流量</p>
            <span className="text-3xl">📥</span>
          </div>
          <p className="text-2xl font-black text-green-600">{formatBytes(summary.totalTrafficIn)}</p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-500 font-medium">实际出站流量</p>
            <span className="text-3xl">📤</span>
          </div>
          <p className="text-2xl font-black text-blue-600">{formatBytes(summary.totalTrafficOut)}</p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-orange-500">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-500 font-medium">计费入站流量</p>
            <span className="text-3xl">💵</span>
          </div>
          <p className="text-2xl font-black text-orange-600">{formatBytes(summary.totalBilledIn)}</p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-500 font-medium">计费出站流量</p>
            <span className="text-3xl">💳</span>
          </div>
          <p className="text-2xl font-black text-purple-600">{formatBytes(summary.totalBilledOut)}</p>
        </div>
      </div>

      {/* 筛选器 */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center gap-4">
          <label className="text-sm font-semibold text-gray-700">筛选隧道:</label>
          <select
            value={tunnelFilter}
            onChange={(e) => setTunnelFilter(e.target.value)}
            className="flex-1 max-w-md px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
          >
            <option value="">全部隧道</option>
            {tunnels.map((tunnel) => (
              <option key={tunnel.id} value={tunnel.id}>
                {tunnel.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* 流量统计列表 */}
      {stats.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-lg p-16 text-center">
          <div className="text-6xl mb-4">📊</div>
          <h3 className="text-2xl font-bold text-gray-900 mb-2">暂无流量记录</h3>
          <p className="text-gray-500">当您的隧道有流量使用时，记录将显示在这里</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gradient-to-r from-gray-50 to-gray-100">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">隧道名称</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">入口节点组</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">出口节点组</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">实际流量</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">计费流量</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">记录日期</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {stats.map((stat) => (
                <tr key={stat.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-bold text-gray-900">{stat.tunnel_name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-3 py-1 text-xs font-bold bg-green-100 text-green-700 rounded-full">
                      {stat.entry_group_name}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-3 py-1 text-xs font-bold bg-purple-100 text-purple-700 rounded-full">
                      {stat.exit_group_name}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm">
                      <div className="font-bold text-green-600">↓ {formatBytes(stat.traffic_in)}</div>
                      <div className="font-bold text-blue-600">↑ {formatBytes(stat.traffic_out)}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm">
                      <div className="font-bold text-orange-600">↓ {formatBytes(stat.billed_traffic_in)}</div>
                      <div className="font-bold text-purple-600">↑ {formatBytes(stat.billed_traffic_out)}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(stat.date, false)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

