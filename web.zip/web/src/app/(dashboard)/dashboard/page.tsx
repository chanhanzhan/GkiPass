'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import { useAuth } from '@/hooks/useAuth';
import { formatBytes } from '@/lib/utils';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { StatCard } from '@/components/dashboard/StatCard';
import { QuotaCard } from '@/components/dashboard/QuotaCard';
import { 
  Activity, 
  Zap,
  CreditCard,
  Plus,
  Wallet,
  Settings,
  Database,
  Wifi
} from 'lucide-react';
import type { Subscription, StatisticsOverview } from '@/types';

export default function DashboardPage() {
  const router = useRouter();
  const { user } = useAuth();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [statistics, setStatistics] = useState<StatisticsOverview | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // 管理员重定向到管理员Dashboard
    if (user?.is_admin) {
      router.push('/dashboard/admin');
      return;
    }
    
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  async function loadData() {
    try {
      const [subData, statsData] = await Promise.all([
        api.plans.getMySubscription().catch(() => null),
        api.statistics.overview().catch(() => null),
      ]);
      setSubscription(subData);
      setStatistics(statsData);
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  return (
    <ProtectedRoute requireUser>
      <div className="space-y-6">
        {/* RelayX 用户欢迎区域 */}
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-8">
            <div className="flex items-center gap-6">
              <div className="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center text-3xl text-white">
                ⚡
          </div>
              <div className="flex-1">
                <h1 className="text-3xl font-bold text-slate-100 mb-2">欢迎回来，{user?.username}！</h1>
                <p className="text-slate-400 text-lg">RelayX 隧道管理平台 - 查看您的使用情况</p>
          </div>
              <div className="text-right">
                <Badge variant="outline">
                  用户面板
                </Badge>
        </div>
      </div>
          </CardContent>
        </Card>

      {/* 配额卡片 */}
      {subscription && subscription.plan ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          <QuotaCard
            title="隧道规则"
            used={subscription.used_rules || 0}
            max={subscription.plan.max_rules || 0}
              icon={<Activity className="w-5 h-5" />}
              color="relay"
          />
          <QuotaCard
            title="流量使用"
            used={subscription.used_traffic || 0}
            max={subscription.plan.max_traffic || 0}
            formatter={formatBytes}
              icon={<Database className="w-5 h-5" />}
              color="tunnel"
          />
          <QuotaCard
              title="带宽限制"
            used={subscription.used_bandwidth || 0}
            max={subscription.plan.max_bandwidth || 0}
            formatter={formatBytes}
            unit="/s"
              icon={<Zap className="w-5 h-5" />}
              color="purple"
          />
          <QuotaCard
            title="连接数"
            used={subscription.used_connections || 0}
            max={subscription.plan.max_connections || 0}
              icon={<Wifi className="w-5 h-5" />}
              color="green"
          />
        </div>
      ) : (
          <Card className="border-dashed border-2 border-muted bg-slate-800">
            <CardContent className="p-8 text-center">
          <div className="text-6xl mb-4">📦</div>
              <CardTitle className="text-slate-100 mb-2">暂无套餐订阅</CardTitle>
              <CardDescription className="mb-6">
                订阅套餐以使用 RelayX 隧道功能
              </CardDescription>
              <Button asChild variant="default" size="lg">
                <a href="/plans">
                  <Plus className="w-4 h-4 mr-2" />
                  查看套餐
                </a>
              </Button>
            </CardContent>
          </Card>
        )}

        {/* RelayX 风格统计卡片 */}
      {statistics && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="bg-slate-800 p-6 text-center">
              <div className="text-3xl font-bold text-slate-100">{statistics.total_tunnels || 0}</div>
              <div className="text-sm text-slate-400">隧道总数</div>
              <div className="text-xs text-green-400 mt-1">{statistics.active_tunnels || 0} 个活跃</div>
            </Card>
            
            <Card className="bg-slate-800 p-6 text-center">
              <div className="text-3xl font-bold text-slate-100">{statistics.total_nodes || 0}</div>
              <div className="text-sm text-slate-400">节点总数</div>
              <div className="text-xs text-green-400 mt-1">{statistics.online_nodes || 0} 个在线</div>
            </Card>
            
            <Card className="bg-slate-800 p-6 text-center">
              <div className="text-3xl font-bold text-slate-100">{formatBytes(statistics.total_traffic || 0)}</div>
              <div className="text-sm text-slate-400">总流量</div>
              <div className="text-xs text-slate-400 mt-1">今日 {formatBytes(statistics.traffic_today || 0)}</div>
            </Card>
            
            <Card className="bg-slate-800 p-6 text-center">
              <div className="text-2xl font-bold text-slate-100">{subscription?.plan?.name || '无套餐'}</div>
              <div className="text-sm text-slate-400">套餐状态</div>
              <div className={`text-xs mt-1 ${subscription?.status === 'active' ? 'text-green-400' : 'text-red-400'}`}>
                {subscription?.status === 'active' ? '运行正常' : '未订阅'}
              </div>
            </Card>
        </div>
      )}

        {/* 快速操作 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
                <div className="p-2 bg-slate-600 rounded-lg text-white">
                <Zap className="w-5 h-5" />
              </div>
              快速开始
            </CardTitle>
            <CardDescription>
              常用功能快速访问，提升您的使用效率
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
              <Button 
                asChild 
                variant={subscription ? "relay" : "outline"} 
                size="lg" 
                className="h-auto p-4 md:p-6 flex flex-col items-start space-y-2"
              >
                <a href={subscription ? "/tunnels/create" : "/plans"}>
                  <div className="flex items-center gap-2">
                    {subscription ? <Plus className="w-5 h-5" /> : <CreditCard className="w-5 h-5" />}
                    <span className="font-semibold">
                      {subscription ? "创建隧道" : "订阅套餐"}
                    </span>
                  </div>
                  <span className="text-sm text-slate-400">
                    {subscription ? "创建新的隧道规则" : "订阅后即可创建隧道"}
                  </span>
                </a>
              </Button>
              
              <Button 
                asChild 
                variant="outline" 
                size="lg" 
                className="h-auto p-6 flex flex-col items-start space-y-2"
              >
                <a href="/wallet">
                  <div className="flex items-center gap-2">
                    <Wallet className="w-5 h-5" />
                    <span className="font-semibold">钱包充值</span>
                  </div>
                  <span className="text-sm text-slate-400">管理您的账户余额</span>
                </a>
              </Button>
              
              <Button 
                asChild 
                variant="outline" 
                size="lg" 
                className="h-auto p-6 flex flex-col items-start space-y-2"
              >
                <a href="/profile">
                  <div className="flex items-center gap-2">
                    <Settings className="w-5 h-5" />
                    <span className="font-semibold">个人设置</span>
        </div>
                  <span className="text-sm text-slate-400">管理账号和安全设置</span>
                </a>
              </Button>
      </div>
          </CardContent>
        </Card>
    </div>
    </ProtectedRoute>
  );
}







