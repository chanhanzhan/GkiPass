'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { getNodeTypeText, formatDate } from '@/lib/utils';
import type { NodeGroup } from '@/types';

export default function NodeGroupsPage() {
  const [nodeGroups, setNodeGroups] = useState<NodeGroup[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadNodeGroups();
  }, []);

  async function loadNodeGroups() {
    try {
      const data = await api.nodeGroups.list();
      const groups = data.data || data || [];
      setNodeGroups(Array.isArray(groups) ? groups : []);
    } catch (error) {
      console.error('Failed to load node groups:', error);
      setNodeGroups([]);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">节点组管理</h1>
        <p className="mt-1 text-sm text-gray-500">
          查看节点组信息
        </p>
      </div>

      {/* 节点组列表 */}
      {nodeGroups.length === 0 ? (
        <div className="bg-white rounded-lg shadow p-12 text-center">
          <div className="text-6xl mb-4">📁</div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            还没有节点组
          </h3>
          <p className="text-gray-500">
            请联系管理员创建节点组
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {nodeGroups.map((group) => (
            <div key={group.id} className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">
                    {group.name}
                  </h3>
                  <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-gray-100 text-gray-800 rounded">
                    {getNodeTypeText(group.type)}
                  </span>
                </div>
                <div className="text-3xl">
                  {group.type === 'entry' ? '📥' : '📤'}
                </div>
              </div>

              {group.description && (
                <p className="text-sm text-gray-600 mb-4">{group.description}</p>
              )}

              <div className="pt-4 border-t border-gray-200">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">节点数量</span>
                  <span className="font-medium text-gray-900">{group.node_count} 个</span>
                </div>
                <div className="flex items-center justify-between text-sm mt-2">
                  <span className="text-gray-500">创建时间</span>
                  <span className="text-gray-600">{formatDate(group.created_at, false)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}






