/* eslint-disable react-hooks/exhaustive-deps */
'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { api } from '@/lib/api';
import { formatBytes, formatDate, getProtocolText, cn } from '@/lib/utils';
import type { Tunnel } from '@/types';

export default function TunnelDetailPage() {
  const params = useParams();
  const router = useRouter();
  const tunnelId = params.id as string;
  
  const [tunnel, setTunnel] = useState<Tunnel | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadTunnel();
  }, []);

  async function loadTunnel() {
    try {
      const data = await api.tunnels.get(tunnelId);
      setTunnel(data);
    } catch (error) {
      console.error('Failed to load tunnel:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleToggle() {
    if (!tunnel) return;
    try {
      await api.tunnels.toggle(tunnelId);
      await loadTunnel();
    } catch (error) {
      console.error('Failed to toggle tunnel:', error);
      alert('操作失败');
    }
  }

  async function handleDelete() {
    if (!tunnel) return;
    if (!confirm(`确定要删除隧道 "${tunnel.name}" 吗？`)) {
      return;
    }

    try {
      await api.tunnels.delete(tunnelId);
      router.push('/tunnels');
    } catch (error) {
      console.error('Failed to delete tunnel:', error);
      alert('删除失败');
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  if (!tunnel) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">隧道不存在</p>
        <Link href="/tunnels" className="text-blue-600 hover:text-blue-700 mt-4 inline-block">
          返回列表
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* 页面标题和操作 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{tunnel.name}</h1>
          <p className="mt-1 text-sm text-gray-500">隧道详细信息</p>
        </div>
        <div className="flex items-center space-x-3">
          <Link
            href="/tunnels"
            className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
          >
            返回
          </Link>
          <button
            onClick={handleToggle}
            className={cn(
              'px-4 py-2 rounded-md transition-colors font-medium',
              tunnel.enabled
                ? 'bg-gray-600 hover:bg-gray-700 text-white'
                : 'bg-green-600 hover:bg-green-700 text-white'
            )}
          >
            {tunnel.enabled ? '禁用' : '启用'}
          </button>
          <Link
            href={`/tunnels/${tunnelId}/edit`}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            编辑
          </Link>
          <button
            onClick={handleDelete}
            className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
          >
            删除
          </button>
        </div>
      </div>

      {/* 状态卡片 */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">状态信息</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div>
            <p className="text-sm text-gray-500">当前状态</p>
            <p className="text-lg font-medium mt-1">
              <span
                className={cn(
                  'px-3 py-1 text-sm rounded',
                  tunnel.enabled
                    ? 'bg-green-100 text-green-800'
                    : 'bg-gray-100 text-gray-800'
                )}
              >
                {tunnel.enabled ? '已启用' : '已禁用'}
              </span>
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-500">活跃连接</p>
            <p className="text-2xl font-bold text-gray-900 mt-1">{tunnel.connections}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">总流量</p>
            <p className="text-2xl font-bold text-gray-900 mt-1">
              {formatBytes(tunnel.traffic_used)}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-500">协议</p>
            <p className="text-lg font-medium text-gray-900 mt-1">
              {getProtocolText(tunnel.protocol)}
            </p>
          </div>
        </div>
      </div>

      {/* 基本信息 */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">基本信息</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-500">隧道名称</p>
            <p className="text-gray-900 mt-1">{tunnel.name}</p>
          </div>
          {tunnel.description && (
            <div>
              <p className="text-sm text-gray-500">描述</p>
              <p className="text-gray-900 mt-1">{tunnel.description}</p>
            </div>
          )}
          <div>
            <p className="text-sm text-gray-500">监听端口</p>
            <p className="text-gray-900 mt-1">{tunnel.local_port}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">最大带宽</p>
            <p className="text-gray-900 mt-1">
              {tunnel.max_bandwidth ? formatBytes(tunnel.max_bandwidth) + '/s' : '不限制'}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-500">创建时间</p>
            <p className="text-gray-900 mt-1">{formatDate(tunnel.created_at)}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">更新时间</p>
            <p className="text-gray-900 mt-1">{formatDate(tunnel.updated_at)}</p>
          </div>
        </div>
      </div>

      {/* 目标服务器 */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">目标服务器</h2>
        <div className="space-y-3">
          {tunnel.targets.map((target, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center space-x-4">
                <span className="text-2xl">🎯</span>
                <div>
                  <p className="font-medium text-gray-900">
                    {target.host}:{target.port}
                  </p>
                  <p className="text-sm text-gray-500">
                    权重: {target.weight}
                  </p>
                </div>
              </div>
              <span className="px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded">
                目标 {index + 1}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}






