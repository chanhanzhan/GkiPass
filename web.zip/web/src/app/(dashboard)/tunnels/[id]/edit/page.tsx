/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react-hooks/exhaustive-deps */
'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Link from 'next/link';
import { api } from '@/lib/api';
import type { NodeGroup, TunnelTarget } from '@/types';

export default function EditTunnelPage() {
  const router = useRouter();
  const params = useParams();
  const tunnelId = params.id as string;
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [nodeGroups, setNodeGroups] = useState<NodeGroup[]>([]);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    protocol: 'tcp',
    entry_group_id: '',
    exit_group_id: '',
    local_port: '',
    max_bandwidth: '',
  });
  const [targets, setTargets] = useState<TunnelTarget[]>([
    { host: '', port: 80, weight: 1 },
  ]);
  const [error, setError] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      const [tunnelData, groupsData] = await Promise.all([
        api.tunnels.get(tunnelId),
        api.nodeGroups.list(),
      ]);
      
      setFormData({
        name: tunnelData.name,
        description: tunnelData.description || '',
        protocol: tunnelData.protocol,
        entry_group_id: tunnelData.entry_group_id,
        exit_group_id: tunnelData.exit_group_id,
        local_port: tunnelData.local_port.toString(),
        max_bandwidth: tunnelData.max_bandwidth?.toString() || '',
      });
      setTargets(tunnelData.targets || [{ host: '', port: 80, weight: 1 }]);
      setNodeGroups(groupsData.data || groupsData);
    } catch (error) {
      console.error('Failed to load data:', error);
      setError('加载数据失败');
    } finally {
      setLoading(false);
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSaving(true);

    try {
      await api.tunnels.update(tunnelId, {
        ...formData,
        local_port: parseInt(formData.local_port),
        max_bandwidth: formData.max_bandwidth
          ? parseInt(formData.max_bandwidth)
          : undefined,
        targets: targets.filter((t) => t.host && t.port),
      });
      router.push('/tunnels');
    } catch (err: any) {
      setError(err.data?.error || '保存失败');
    } finally {
      setSaving(false);
    }
  };

  const addTarget = () => {
    setTargets([...targets, { host: '', port: 80, weight: 1 }]);
  };

  const removeTarget = (index: number) => {
    if (targets.length > 1) {
      setTargets(targets.filter((_, i) => i !== index));
    }
  };

  const updateTarget = (index: number, field: keyof TunnelTarget, value: string | number) => {
    const newTargets = [...targets];
    newTargets[index] = { ...newTargets[index], [field]: value };
    setTargets(newTargets);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  const entryGroups = nodeGroups.filter((g) => g.type === 'entry');
  const exitGroups = nodeGroups.filter((g) => g.type === 'exit');

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">编辑隧道</h1>
          <p className="mt-1 text-sm text-gray-500">修改隧道配置</p>
        </div>
        <Link
          href="/tunnels"
          className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
        >
          返回
        </Link>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md">
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* 基本信息 */}
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-gray-900">基本信息</h2>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                隧道名称 *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                描述
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  协议 *
                </label>
                <select
                  required
                  value={formData.protocol}
                  onChange={(e) => setFormData({ ...formData, protocol: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="tcp">TCP</option>
                  <option value="udp">UDP</option>
                  <option value="http">HTTP</option>
                  <option value="https">HTTPS</option>
                  <option value="socks">SOCKS5</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  监听端口 *
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  max="65535"
                  value={formData.local_port}
                  onChange={(e) => setFormData({ ...formData, local_port: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          {/* 节点配置 */}
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-gray-900">节点配置</h2>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  入口节点组 *
                </label>
                <select
                  required
                  value={formData.entry_group_id}
                  onChange={(e) => setFormData({ ...formData, entry_group_id: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">请选择...</option>
                  {entryGroups.map((group) => (
                    <option key={group.id} value={group.id}>
                      {group.name} ({group.node_count} 个节点)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  出口节点组 *
                </label>
                <select
                  required
                  value={formData.exit_group_id}
                  onChange={(e) => setFormData({ ...formData, exit_group_id: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">请选择...</option>
                  {exitGroups.map((group) => (
                    <option key={group.id} value={group.id}>
                      {group.name} ({group.node_count} 个节点)
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* 目标配置 */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">目标服务器</h2>
              <button
                type="button"
                onClick={addTarget}
                className="px-3 py-1 text-sm text-blue-600 hover:text-blue-700 font-medium"
              >
                ➕ 添加目标
              </button>
            </div>

            {targets.map((target, index) => (
              <div key={index} className="flex gap-3 items-start">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    主机地址
                  </label>
                  <input
                    type="text"
                    required
                    value={target.host}
                    onChange={(e) => updateTarget(index, 'host', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="w-32">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    端口
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    max="65535"
                    value={target.port}
                    onChange={(e) => updateTarget(index, 'port', parseInt(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="w-24">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    权重
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={target.weight}
                    onChange={(e) => updateTarget(index, 'weight', parseInt(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                {targets.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeTarget(index)}
                    className="mt-7 px-3 py-2 text-red-600 hover:text-red-700"
                  >
                    🗑️
                  </button>
                )}
              </div>
            ))}
          </div>

          {/* 高级选项 */}
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-gray-900">高级选项</h2>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                最大带宽 (字节/秒)
              </label>
              <input
                type="number"
                min="0"
                value={formData.max_bandwidth}
                onChange={(e) => setFormData({ ...formData, max_bandwidth: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="留空表示不限制"
              />
            </div>
          </div>

          {/* 提交按钮 */}
          <div className="flex justify-end space-x-3 pt-6 border-t">
            <Link
              href="/tunnels"
              className="px-6 py-2 text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
            >
              取消
            </Link>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:bg-blue-400 disabled:cursor-not-allowed"
            >
              {saving ? '保存中...' : '保存更改'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}






