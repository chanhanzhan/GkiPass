/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import { useToast } from '@/components/ui/Toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  Activity, 
  Network, 
  Target, 
  Settings,
  Plus,
  Trash2,
  ArrowLeft,
  Info,
  Globe
} from 'lucide-react';

interface TunnelTarget {
  host: string;
  port: number;
  weight: number;
}

export default function CreateTunnelPage() {
  const router = useRouter();
  const { showToast } = useToast();
  const [loading, setLoading] = useState(false);
  const [nodeGroups, setNodeGroups] = useState<any[]>([]);
  const [formData, setFormData] = useState({
    name: '',
    protocol: 'tcp',
    entry_group_id: '',
    exit_group_id: '',
    local_port: 9301,
    enabled: true,
    description: '',
  });
  const [targets, setTargets] = useState<TunnelTarget[]>([
    { host: '127.0.0.1', port: 9301, weight: 1 },
  ]);

  useEffect(() => {
    loadNodeGroups();
  }, []);

  async function loadNodeGroups() {
    try {
      const data = await api.nodeGroups.list();
      setNodeGroups(data.data || data || []);
    } catch (error) {
      console.error('Failed to load node groups:', error);
      showToast('error', '加载节点组失败');
    }
  }

  const addTarget = () => {
    setTargets([...targets, { host: '127.0.0.1', port: 9301, weight: 1 }]);
  };

  const removeTarget = (index: number) => {
    if (targets.length > 1) {
      setTargets(targets.filter((_, i) => i !== index));
    }
  };

  const updateTarget = (index: number, field: keyof TunnelTarget, value: string | number) => {
    const newTargets = [...targets];
    newTargets[index] = { ...newTargets[index], [field]: value };
    setTargets(newTargets);
  };

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (!formData.name || !formData.entry_group_id || !formData.exit_group_id) {
      showToast('error', '请填写完整信息');
      return;
    }

    // 验证所有转发地址
    for (const target of targets) {
      if (!target.host || !target.port || target.weight < 1) {
        showToast('error', '请填写有效的转发地址');
        return;
      }
    }

    setLoading(true);
    try {
      await api.tunnels.create({
        ...formData,
        targets,
      });
      showToast('success', '隧道创建成功！');
      router.push('/tunnels');
    } catch (error: any) {
      showToast('error', error.data?.error || '创建失败');
    } finally {
      setLoading(false);
    }
  }

  const entryGroups = nodeGroups.filter(g => g.type === 'entry');
  const exitGroups = nodeGroups.filter(g => g.type === 'exit');

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* RelayX 创建隧道标题 */}
      <Card className="bg-card border-border">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-muted rounded-lg">
                <Activity className="w-6 h-6 text-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">创建隧道</h1>
                <p className="text-muted-foreground">配置您的 RelayX 隧道转发规则</p>
              </div>
            </div>
            <Button variant="outline" onClick={() => router.back()}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              返回
            </Button>
          </div>
        </CardContent>
      </Card>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* 基本信息 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              基本信息
            </CardTitle>
            <CardDescription>
              设置隧道的基本属性和转发协议
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">隧道名称 *</Label>
                <Input
                  id="name"
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="例如：腾讯云集群"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="protocol">隧道协议 *</Label>
                <Select 
                  value={formData.protocol} 
                  onValueChange={(value) => setFormData({ ...formData, protocol: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="选择协议" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tcp">TCP</SelectItem>
                    <SelectItem value="udp">UDP</SelectItem>
                    <SelectItem value="http">HTTP</SelectItem>
                    <SelectItem value="https">HTTPS</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">描述（可选）</Label>
              <Input
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="隧道的用途描述..."
              />
            </div>
          </CardContent>
        </Card>

        {/* 节点组配置 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Network className="w-5 h-5" />
              节点组配置
            </CardTitle>
            <CardDescription>
              选择入口和出口节点组，配置监听端口
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="entry_group">入口节点组 *</Label>
                <Select 
                  value={formData.entry_group_id} 
                  onValueChange={(value) => setFormData({ ...formData, entry_group_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="请选择入口节点组" />
                  </SelectTrigger>
                  <SelectContent>
                    {entryGroups.map((group) => (
                      <SelectItem key={group.id} value={group.id}>
                        <div className="flex items-center justify-between w-full">
                          <span>{group.name}</span>
                          <Badge variant="outline" className="ml-2">
                            {group.node_count} 节点
                          </Badge>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="exit_group">出口节点组 *</Label>
                <Select 
                  value={formData.exit_group_id} 
                  onValueChange={(value) => setFormData({ ...formData, exit_group_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="请选择出口节点组" />
                  </SelectTrigger>
                  <SelectContent>
                    {exitGroups.map((group) => (
                      <SelectItem key={group.id} value={group.id}>
                        <div className="flex items-center justify-between w-full">
                          <span>{group.name}</span>
                          <Badge variant="outline" className="ml-2">
                            {group.node_count} 节点
                          </Badge>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="local_port">入口监听端口 *</Label>
              <Input
                id="local_port"
                type="number"
                required
                min="1024"
                max="65535"
                value={formData.local_port}
                onChange={(e) => setFormData({ ...formData, local_port: parseInt(e.target.value) })}
                className="font-mono"
              />
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Info className="w-4 h-4" />
                <span>端口范围：1024-65535</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 转发地址配置 */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5" />
                  转发地址配置
                </CardTitle>
                <CardDescription>
                  配置多个转发目标实现负载均衡
                </CardDescription>
              </div>
              <Button type="button" onClick={addTarget} variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                添加地址
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {targets.map((target, index) => (
              <Card key={index} className="bg-muted/50">
                <CardContent className="p-4">
                  <div className="flex gap-3 items-start">
                    <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div className="space-y-2">
                        <Label>目标地址</Label>
                        <Input
                          type="text"
                          required
                          value={target.host}
                          onChange={(e) => updateTarget(index, 'host', e.target.value)}
                          placeholder="IP或域名"
                          className="font-mono"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>目标端口</Label>
                        <Input
                          type="number"
                          required
                          min="1"
                          max="65535"
                          value={target.port}
                          onChange={(e) => updateTarget(index, 'port', parseInt(e.target.value))}
                          className="font-mono"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>权重</Label>
                        <Input
                          type="number"
                          required
                          min="1"
                          max="100"
                          value={target.weight}
                          onChange={(e) => updateTarget(index, 'weight', parseInt(e.target.value))}
                        />
                      </div>
                    </div>
                    {targets.length > 1 && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => removeTarget(index)}
                        className="mt-8 text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
            
            <div className="flex items-start gap-2 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <Info className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-blue-800">
                <strong>提示：</strong>您可以配置多个转发地址实现负载均衡。权重越高，接收的流量越多。
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 其他设置 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              其他设置
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="enabled"
                checked={formData.enabled}
                onChange={(e) => setFormData({ ...formData, enabled: e.target.checked })}
                className="w-4 h-4 text-relay-600 rounded focus:ring-relay-500"
              />
              <Label htmlFor="enabled">创建后立即启用隧道</Label>
            </div>
          </CardContent>
        </Card>

        {/* 提交按钮 */}
        <div className="flex gap-4">
          <Button 
            type="button" 
            variant="outline" 
            size="lg" 
            onClick={() => router.back()}
            className="flex-1"
          >
            取消
          </Button>
          <Button
            type="submit"
            variant="relay"
            size="lg"
            disabled={loading}
            className="flex-1"
          >
            {loading ? '创建中...' : '创建隧道'}
          </Button>
        </div>
      </form>
    </div>
  );
}
