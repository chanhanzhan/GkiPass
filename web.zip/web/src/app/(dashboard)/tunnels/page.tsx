'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { api } from '@/lib/api';
import { formatBytes, getProtocolText, cn } from '@/lib/utils';
import { useToast } from '@/components/ui/Toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Activity, 
  Plus
} from 'lucide-react';
import type { Tunnel } from '@/types';

export default function TunnelsPage() {
  const [tunnels, setTunnels] = useState<Tunnel[]>([]);
  const [loading, setLoading] = useState(true);
  const { showToast } = useToast();

  useEffect(() => {
    loadTunnels();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadTunnels() {
    try {
      const data = await api.tunnels.list();
      const tunnelList = data.data || data || [];
      setTunnels(Array.isArray(tunnelList) ? tunnelList : []);
    } catch (error) {
      console.error('Failed to load tunnels:', error);
      showToast('error', '加载隧道列表失败');
      setTunnels([]);
    } finally {
      setLoading(false);
    }
  }

  async function handleToggle(id: string, currentStatus: boolean) {
    try {
      await api.tunnels.toggle(id);
      await loadTunnels();
      showToast('success', currentStatus ? '隧道已禁用' : '隧道已启用');
    } catch (error) {
      console.error('Failed to toggle tunnel:', error);
      showToast('error', '操作失败');
    }
  }

  async function handleDelete(id: string, name: string) {
    if (!confirm(`确定要删除隧道 "${name}" 吗？`)) {
      return;
    }

    try {
      await api.tunnels.delete(id);
      await loadTunnels();
      showToast('success', '隧道已删除');
    } catch (error) {
      console.error('Failed to delete tunnel:', error);
      showToast('error', '删除失败');
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* RelayX 隧道管理标题 */}
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-muted rounded-lg">
                <Activity className="w-6 h-6 text-slate-100" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-100">隧道管理</h1>
                <p className="text-slate-400">
                  RelayX 隧道转发规则 · 共 {tunnels.length} 个隧道
                </p>
              </div>
            </div>
            <Button asChild variant="default" size="default">
              <Link href="/tunnels/create">
                <Plus className="w-4 h-4 mr-2" />
                创建隧道
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* 隧道列表 */}
      {tunnels.length === 0 ? (
        <Card className="border-dashed border-2 border-muted bg-slate-800">
          <CardContent className="p-16 text-center">
            <div className="text-6xl mb-4">🔗</div>
            <CardTitle className="text-slate-100 mb-2">还没有隧道</CardTitle>
            <CardDescription className="mb-8">
              创建您的第一个 RelayX 隧道来开始使用
            </CardDescription>
            <Button asChild variant="default" size="lg">
              <Link href="/tunnels/create">
                <Plus className="w-4 h-4 mr-2" />
                创建隧道
              </Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-slate-100">
              <Activity className="w-5 h-5" />
              隧道列表
            </CardTitle>
            <CardDescription>
              管理您的所有隧道转发规则
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-border">
              {tunnels.map((tunnel) => (
                <div key={tunnel.id} className="p-4 hover:bg-muted/50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`w-3 h-3 rounded-full ${
                        tunnel.enabled ? 'bg-green-400' : 'bg-red-400'
                      }`} />
                      <div>
                        <h3 className="font-medium text-slate-100">{tunnel.name}</h3>
                        <div className="flex items-center gap-2 text-sm text-slate-400 mt-1">
                          <Badge variant="outline">{getProtocolText(tunnel.protocol)}</Badge>
                          <span className="font-mono">{tunnel.local_port}</span>
                          <span>{tunnel.targets?.length || 0} 个目标</span>
                          <span>{formatBytes(tunnel.traffic_used || 0)}</span>
                        </div>
                        {tunnel.description && (
                          <p className="text-sm text-slate-400 mt-1">
                            {tunnel.description}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleToggle(tunnel.id, tunnel.enabled)}
                      >
                        {tunnel.enabled ? '禁用' : '启用'}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        asChild
                      >
                        <Link href={`/tunnels/${tunnel.id}/edit`}>
                          编辑
                        </Link>
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(tunnel.id, tunnel.name)}
                        className="text-destructive hover:text-destructive"
                      >
                        删除
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}






