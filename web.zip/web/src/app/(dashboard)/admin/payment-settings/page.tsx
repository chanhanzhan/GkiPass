/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import { useToast } from '@/components/ui/Toast';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';

export default function PaymentSettingsPage() {
  const [configs, setConfigs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<string | null>(null);
  const [formData, setFormData] = useState<any>({});
  const { showToast } = useToast();

  useEffect(() => {
    loadConfigs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadConfigs() {
    try {
      const data = await api.payment.getConfigs();
      const list = data.data || data || [];
      setConfigs(Array.isArray(list) ? list : []);
    } catch (error: unknown) {
      console.error('Failed to load payment configs:', error);
      showToast('error', '加载支付配置失败');
    } finally {
      setLoading(false);
    }
  }

  function handleEdit(config: any) {
    setEditing(config.id);
    try {
      const parsedConfig = JSON.parse(config.config);
      setFormData({
        enabled: config.enabled,
        ...parsedConfig,
      });
    } catch (error) {
      showToast('error', '解析配置失败');
    }
  }

  async function handleSave(id: string, paymentType: string) {
    try {
      setLoading(true);
      const enabled = formData.enabled;
      const configData: any = {};

      if (paymentType === 'epay') {
        configData.api_url = formData.api_url || '';
        configData.merchant_id = formData.merchant_id || '';
        configData.merchant_key = formData.merchant_key || '';
        configData.notify_url = formData.notify_url || '';
        configData.return_url = formData.return_url || '';
      } else if (paymentType === 'crypto') {
        configData.network = formData.network || 'TRC20';
        configData.address = formData.address || '';
        configData.api_key = formData.api_key || '';
        configData.check_interval = formData.check_interval || 30;
      }

      await api.payment.updateConfig(id, { enabled, ...configData });
      showToast('success', '配置保存成功');
      setEditing(null);
      await loadConfigs();
    } catch (error: any) {
      showToast('error', error.message || '保存失败');
    } finally {
      setLoading(false);
    }
  }

  async function handleToggle(id: string) {
    try {
      await api.payment.toggleConfig(id);
      showToast('success', '状态切换成功');
      await loadConfigs();
    } catch (error: any) {
      showToast('error', error.message || '切换失败');
    }
  }

  if (loading && configs.length === 0) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  return (
    <ProtectedRoute requireAdmin>
      <div className="space-y-6">
        {/* 页面标题 */}
        <div className="bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 rounded-2xl p-6 text-white shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-black mb-2">支付配置</h1>
              <p className="text-pink-100">管理易支付和加密货币支付渠道</p>
            </div>
            <div className="text-6xl">⚙️</div>
          </div>
        </div>

        {/* 配置列表 */}
        <div className="grid grid-cols-1 gap-6">
          {configs.map((config) => {
            const isEditing = editing === config.id;
            const parsedConfig = (() => {
              try {
                return JSON.parse(config.config);
              } catch {
                return {};
              }
            })();

            return (
              <div
                key={config.id}
                className="bg-white rounded-2xl shadow-xl p-6 border-2 border-gray-100"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <div className="text-4xl">
                      {config.payment_type === 'epay' ? '💳' : '🪙'}
                    </div>
                    <div>
                      <h3 className="text-xl font-black text-gray-900">
                        {config.payment_type === 'epay' ? '易支付' : '加密货币支付'}
                      </h3>
                      <p className="text-sm text-gray-500">
                        {config.payment_type === 'epay'
                          ? '支持支付宝/微信支付'
                          : 'USDT-TRC20 自动监听'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => handleToggle(config.id)}
                      disabled={loading}
                      className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
                        config.enabled
                          ? 'bg-green-100 text-green-700 hover:bg-green-200'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {config.enabled ? '✓ 已启用' : '✗ 已禁用'}
                    </button>
                    {!isEditing ? (
                      <button
                        onClick={() => handleEdit(config)}
                        className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-semibold transition-colors"
                      >
                        编辑配置
                      </button>
                    ) : (
                      <button
                        onClick={() => setEditing(null)}
                        className="px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-lg font-semibold transition-colors"
                      >
                        取消
                      </button>
                    )}
                  </div>
                </div>

                {isEditing ? (
                  <div className="space-y-4 bg-gray-50 rounded-xl p-6">
                    {config.payment_type === 'epay' ? (
                      <>
                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">
                            API地址
                          </label>
                          <input
                            type="text"
                            value={formData.api_url || ''}
                            onChange={(e) =>
                              setFormData({ ...formData, api_url: e.target.value })
                            }
                            placeholder="https://pay.example.com"
                            className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-2">
                              商户ID
                            </label>
                            <input
                              type="text"
                              value={formData.merchant_id || ''}
                              onChange={(e) =>
                                setFormData({ ...formData, merchant_id: e.target.value })
                              }
                              placeholder="100001"
                              className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-2">
                              商户密钥
                            </label>
                            <input
                              type="password"
                              value={formData.merchant_key || ''}
                              onChange={(e) =>
                                setFormData({ ...formData, merchant_key: e.target.value })
                              }
                              placeholder="your_secret_key"
                              className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">
                            回调地址
                          </label>
                          <input
                            type="text"
                            value={formData.notify_url || ''}
                            onChange={(e) =>
                              setFormData({ ...formData, notify_url: e.target.value })
                            }
                            placeholder="https://your-domain.com/api/v1/payment/callback"
                            className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                          />
                        </div>
                      </>
                    ) : (
                      <>
                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">
                            钱包地址 (TRC20)
                          </label>
                          <input
                            type="text"
                            value={formData.address || ''}
                            onChange={(e) =>
                              setFormData({ ...formData, address: e.target.value })
                            }
                            placeholder="TYourWalletAddress..."
                            className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none font-mono text-sm"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">
                            TronGrid API Key
                          </label>
                          <input
                            type="password"
                            value={formData.api_key || ''}
                            onChange={(e) =>
                              setFormData({ ...formData, api_key: e.target.value })
                            }
                            placeholder="your_trongrid_api_key"
                            className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                          />
                          <p className="text-xs text-gray-500 mt-1">
                            获取地址: https://www.trongrid.io/
                          </p>
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">
                            检查间隔（秒）
                          </label>
                          <input
                            type="number"
                            value={formData.check_interval || 30}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                check_interval: parseInt(e.target.value),
                              })
                            }
                            min="10"
                            max="300"
                            className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                          />
                        </div>
                      </>
                    )}

                    <div className="flex gap-3 pt-4">
                      <button
                        onClick={() => handleSave(config.id, config.payment_type)}
                        disabled={loading}
                        className="flex-1 py-3 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white rounded-xl font-bold transition-all disabled:opacity-50"
                      >
                        {loading ? '保存中...' : '保存配置'}
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2 bg-gray-50 rounded-xl p-4">
                    {config.payment_type === 'epay' ? (
                      <>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">API地址:</span>
                          <span className="font-mono text-gray-900">
                            {parsedConfig.api_url || '未设置'}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">商户ID:</span>
                          <span className="font-mono text-gray-900">
                            {parsedConfig.merchant_id || '未设置'}
                          </span>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">钱包地址:</span>
                          <span className="font-mono text-xs text-gray-900">
                            {parsedConfig.address || '未设置'}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">检查间隔:</span>
                          <span className="text-gray-900">
                            {parsedConfig.check_interval || 30} 秒
                          </span>
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* 使用说明 */}
        <div className="bg-blue-50 border-2 border-blue-300 rounded-2xl p-6">
          <h3 className="text-lg font-black text-gray-900 mb-3 flex items-center gap-2">
            <span>ℹ️</span>
            使用说明
          </h3>
          <div className="space-y-2 text-sm text-gray-700">
            <p>
              <strong>易支付:</strong> 填写易支付平台提供的商户信息，启用后用户可使用支付宝/微信支付充值
            </p>
            <p>
              <strong>加密货币:</strong> 填写TRC20钱包地址，系统将自动监听USDT转账并自动到账
            </p>
            <p>
              <strong>安全提示:</strong> 商户密钥和API密钥请妥善保管，定期更换
            </p>
          </div>
        </div>
      </div>
    </ProtectedRoute>
  );
}


