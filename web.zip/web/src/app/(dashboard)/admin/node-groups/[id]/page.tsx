/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { api } from '@/lib/api';
import { formatDate, getNodeTypeText } from '@/lib/utils';
import { DeployNodeDialog } from '@/components/node-deploy/DeployNodeDialog';
import { NodeGroupConfigDialog } from '@/components/node-deploy/NodeGroupConfigDialog';

export default function NodeGroupDetailPage() {
  const params = useParams();
  const router = useRouter();
  const groupId = params.id as string;

  const [group, setGroup] = useState<any>(null);
  const [nodes, setNodes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDeploy, setShowDeploy] = useState(false);
  const [showConfig, setShowConfig] = useState(false);

  useEffect(() => {
    loadData();
  }, [groupId]);

  async function loadData() {
    try {
      const [groupData, nodesData] = await Promise.all([
        api.nodeGroups.list(), // 获取节点组信息
        api.nodeGroups.listNodes(groupId),
      ]);
      
      // 从列表中找到当前节点组
      const groups = groupData.groups || groupData.data || groupData || [];
      const currentGroup = groups.find((g: any) => g.id === groupId);
      setGroup(currentGroup);
      
      setNodes(nodesData.data || []);
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setLoading(false);
    }
  }

  const getStatusBadge = (status: string, lastSeen: string) => {
    const isOnline = status === 'online' && new Date(lastSeen) > new Date(Date.now() - 5 * 60 * 1000);
    
    if (status === 'pending') {
      return <span className="px-3 py-1 text-xs font-bold bg-yellow-100 text-yellow-700 rounded-full">⏳ 待部署</span>;
    }
    if (isOnline) {
      return <span className="px-3 py-1 text-xs font-bold bg-green-100 text-green-700 rounded-full animate-pulse">🟢 在线</span>;
    }
    return <span className="px-3 py-1 text-xs font-bold bg-gray-100 text-gray-700 rounded-full">⚫ 离线</span>;
  };

  const stats = {
    total: nodes.length,
    pending: nodes.filter(n => n.status === 'pending').length,
    online: nodes.filter(n => n.status === 'online' && new Date(n.last_seen) > new Date(Date.now() - 5 * 60 * 1000)).length,
    offline: nodes.filter(n => n.status !== 'online' && n.status !== 'pending').length,
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  if (!group) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="text-6xl mb-4">❌</div>
          <h3 className="text-2xl font-bold text-gray-900 mb-2">节点组不存在</h3>
          <button
            onClick={() => router.push('/admin/node-groups')}
            className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            返回列表
          </button>
        </div>
      </div>
    );
  }

  return (
    <ProtectedRoute requireAdmin>
      <div className="space-y-6">
        {/* 页面标题 */}
        <div className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-2xl p-6 text-white shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <h1 className="text-3xl font-black mb-2">{group.name}</h1>
              <p className="text-blue-100">
                {getNodeTypeText(group.type)} | {group.description || '暂无描述'}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setShowConfig(true)}
                className="px-6 py-3 bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white rounded-xl font-bold transition-all shadow-lg hover:shadow-xl"
              >
                ⚙️ 配置
              </button>
              <div className="text-6xl">{group.type === 'entry' ? '📥' : '📤'}</div>
            </div>
          </div>
        </div>

        {/* 统计卡片 */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 font-medium">总节点</p>
                <p className="text-3xl font-black text-gray-900 mt-1">{stats.total}</p>
              </div>
              <span className="text-4xl">🖥️</span>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-yellow-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 font-medium">待部署</p>
                <p className="text-3xl font-black text-yellow-600 mt-1">{stats.pending}</p>
              </div>
              <span className="text-4xl">⏳</span>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 font-medium">在线</p>
                <p className="text-3xl font-black text-green-600 mt-1">{stats.online}</p>
              </div>
              <span className="text-4xl">✅</span>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-gray-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 font-medium">离线</p>
                <p className="text-3xl font-black text-gray-600 mt-1">{stats.offline}</p>
              </div>
              <span className="text-4xl">⭕</span>
            </div>
          </div>
        </div>

        {/* 节点列表 */}
        <div className="bg-white rounded-2xl shadow-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-black text-gray-900">节点列表</h2>
            <button
              onClick={() => setShowDeploy(true)}
              className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-xl font-bold shadow-lg hover:shadow-xl transition-all"
            >
              ➕ 部署节点
            </button>
          </div>

          {nodes.length === 0 ? (
              <div className="text-center py-16">
                <div className="text-6xl mb-4">📦</div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">还没有节点</h3>
                <p className="text-gray-500 mb-6">点击 &quot;部署节点&quot; 按钮开始部署</p>
              <button
                onClick={() => setShowDeploy(true)}
                className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl font-bold shadow-lg hover:shadow-xl transition-all"
              >
                ➕ 部署节点
              </button>
            </div>
          ) : (
            <div className="grid gap-4">
              {nodes.map((node) => (
                <div key={node.id} className="border-2 border-gray-200 rounded-xl p-5 hover:border-blue-300 hover:shadow-lg transition-all">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="text-lg font-bold text-gray-900">
                          {node.name || '未命名节点'}
                        </h4>
                        {getStatusBadge(node.status, node.last_seen)}
                      </div>
                      
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <span className="text-gray-500">节点ID:</span>
                          <span className="ml-2 font-mono text-gray-700">{node.id.substring(0, 8)}...</span>
                        </div>
                        <div>
                          <span className="text-gray-500">IP地址:</span>
                          <span className="ml-2 text-gray-900">{node.ip || '未知'}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">端口:</span>
                          <span className="ml-2 text-gray-900">{node.port}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">创建时间:</span>
                          <span className="ml-2 text-gray-900">{formatDate(node.created_at, false)}</span>
                        </div>
                        {node.last_seen && node.status === 'online' && (
                          <div className="col-span-2">
                            <span className="text-gray-500">最后心跳:</span>
                            <span className="ml-2 text-gray-900">{formatDate(node.last_seen)}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex flex-col gap-2">
                      {node.status === 'pending' && (
                        <span className="text-xs text-yellow-600 font-medium">⚠️ 等待部署</span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* 部署对话框 */}
      <DeployNodeDialog
        open={showDeploy}
        onClose={() => setShowDeploy(false)}
        groupId={groupId}
        onSuccess={() => {
          loadData();
        }}
      />

      {/* 配置对话框 */}
      <NodeGroupConfigDialog
        open={showConfig}
        onClose={() => setShowConfig(false)}
        groupId={groupId}
        groupName={group?.name}
      />
    </ProtectedRoute>
  );
}

