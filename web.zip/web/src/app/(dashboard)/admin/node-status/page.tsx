'use client';

import { useEffect, useState } from 'react';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { api } from '@/lib/api';
import { formatBytes, formatDate } from '@/lib/utils';

interface NodeStatusDetail {
  id: string;
  name: string;
  type: string;
  group_name: string;
  ip: string;
  port: number;
  status: string;
  is_online: boolean;
  last_seen: string;
  current_load: number;
  current_connections: number;
  traffic_in: number;
  traffic_out: number;
  traffic_total: number;
}

export default function NodeStatusPage() {
  const [nodes, setNodes] = useState<NodeStatusDetail[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'entry' | 'exit'>('all');

  useEffect(() => {
    loadNodeStatus();
    // 每30秒刷新一次
    const interval = setInterval(loadNodeStatus, 30000);
    return () => clearInterval(interval);
  }, [filter]);

  async function loadNodeStatus() {
    try {
      const data = await api.nodes.listStatus(filter === 'all' ? undefined : filter);
      setNodes(data.nodes || []);
    } catch (error) {
      console.error('Failed to load node status:', error);
    } finally {
      setLoading(false);
    }
  }

  const stats = {
    total: nodes.length,
    online: nodes.filter(n => n.is_online).length,
    offline: nodes.filter(n => !n.is_online).length,
    totalTraffic: nodes.reduce((sum, n) => sum + n.traffic_total, 0),
    avgLoad: nodes.length > 0 ? nodes.reduce((sum, n) => sum + n.current_load, 0) / nodes.length : 0,
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  return (
    <ProtectedRoute requireAdmin>
      <div className="space-y-6">
        {/* 页面标题 */}
        <div className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-2xl p-6 text-white shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-black mb-2">节点状态监控</h1>
              <p className="text-blue-100">实时监控所有节点的运行状态</p>
            </div>
            <div className="text-6xl">📊</div>
          </div>
        </div>

        {/* 统计卡片 */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 font-medium">总节点</p>
                <p className="text-3xl font-black text-gray-900 mt-1">{stats.total}</p>
              </div>
              <span className="text-4xl">🖥️</span>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 font-medium">在线</p>
                <p className="text-3xl font-black text-green-600 mt-1">{stats.online}</p>
              </div>
              <span className="text-4xl">✅</span>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-red-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 font-medium">离线</p>
                <p className="text-3xl font-black text-red-600 mt-1">{stats.offline}</p>
              </div>
              <span className="text-4xl">❌</span>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 font-medium">总流量</p>
                <p className="text-2xl font-black text-purple-600 mt-1">{formatBytes(stats.totalTraffic)}</p>
              </div>
              <span className="text-4xl">📈</span>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-orange-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 font-medium">平均负载</p>
                <p className="text-3xl font-black text-orange-600 mt-1">{stats.avgLoad.toFixed(1)}%</p>
              </div>
              <span className="text-4xl">⚡</span>
            </div>
          </div>
        </div>

        {/* 筛选器 */}
        <div className="flex gap-3">
          <button
            onClick={() => setFilter('all')}
            className={`px-6 py-2 rounded-lg font-semibold transition-all ${
              filter === 'all'
                ? 'bg-blue-600 text-white shadow-lg'
                : 'bg-white text-gray-600 hover:bg-gray-100'
            }`}
          >
            全部节点
          </button>
          <button
            onClick={() => setFilter('entry')}
            className={`px-6 py-2 rounded-lg font-semibold transition-all ${
              filter === 'entry'
                ? 'bg-green-600 text-white shadow-lg'
                : 'bg-white text-gray-600 hover:bg-gray-100'
            }`}
          >
            入口节点
          </button>
          <button
            onClick={() => setFilter('exit')}
            className={`px-6 py-2 rounded-lg font-semibold transition-all ${
              filter === 'exit'
                ? 'bg-purple-600 text-white shadow-lg'
                : 'bg-white text-gray-600 hover:bg-gray-100'
            }`}
          >
            出口节点
          </button>
        </div>

        {/* 节点列表 */}
        {nodes.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg p-16 text-center">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">没有找到节点</h3>
            <p className="text-gray-500">请先创建节点</p>
          </div>
        ) : (
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gradient-to-r from-gray-50 to-gray-100">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">节点信息</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">类型</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">地址</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">状态</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">负载</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">连接数</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">流量</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">最后在线</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {nodes.map((node) => (
                  <tr key={node.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-bold text-gray-900">{node.name}</div>
                        <div className="text-xs text-gray-500">{node.group_name}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-3 py-1 text-xs font-bold rounded-full ${
                        node.type === 'entry' 
                          ? 'bg-green-100 text-green-700' 
                          : 'bg-purple-100 text-purple-700'
                      }`}>
                        {node.type === 'entry' ? '📥 入口' : '📤 出口'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-mono text-gray-900">{node.ip}:{node.port}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-3 py-1 text-xs font-bold rounded-full ${
                        node.is_online
                          ? 'bg-green-100 text-green-700 animate-pulse'
                          : 'bg-gray-100 text-gray-700'
                      }`}>
                        {node.is_online ? '🟢 在线' : '⚫ 离线'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-1">
                          <div className="text-sm font-bold text-gray-900">{node.current_load.toFixed(1)}%</div>
                          <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                            <div
                              className={`h-2 rounded-full transition-all ${
                                node.current_load > 80
                                  ? 'bg-red-500'
                                  : node.current_load > 50
                                  ? 'bg-yellow-500'
                                  : 'bg-green-500'
                              }`}
                              style={{ width: `${Math.min(node.current_load, 100)}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-bold text-gray-900">{node.current_connections}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        <div className="font-bold text-green-600">↓ {formatBytes(node.traffic_in)}</div>
                        <div className="font-bold text-blue-600">↑ {formatBytes(node.traffic_out)}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-xs text-gray-500">
                      {formatDate(node.last_seen)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
}

