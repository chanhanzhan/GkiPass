/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useEffect, useState } from 'react';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { api } from '@/lib/api';
import { formatBytes, formatDate } from '@/lib/utils';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { CreatePlanDialog } from '@/components/admin/CreatePlanDialog';
import { SystemStatsCard } from '@/components/admin/SystemStatsCard';
import { useToast } from '@/components/ui/Toast';
import { 
  Package,
  DollarSign,
  Users,
  Activity,
  Database,
  Zap,
  Edit,
  Trash2,
  ToggleLeft,
  ToggleRight,
  Crown
} from 'lucide-react';
import type { Plan } from '@/types';

export default function AdminPlansPage() {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);
  const { showToast } = useToast();

  useEffect(() => {
    loadPlans();
  }, []);

  async function loadPlans() {
    try {
      const data = await api.plans.list();
      setPlans(data.data || data);
    } catch (error) {
      console.error('Failed to load plans:', error);
    } finally {
      setLoading(false);
    }
  }

  const togglePlanStatus = async (id: string, currentStatus: boolean) => {
    try {
      await api.plans.toggle(id);
      await loadPlans();
      showToast('success', currentStatus ? '套餐已禁用' : '套餐已启用');
    } catch (error: any) {
      showToast('error', error.data?.error || '操作失败');
    }
  };

  const deletePlan = async (id: string, name: string) => {
    if (!confirm(`确定要删除套餐 "${name}" 吗？此操作不可逆！`)) {
      return;
    }
    try {
      await api.plans.delete(id);
      await loadPlans();
      showToast('success', `套餐 ${name} 已删除`);
    } catch (error: any) {
      showToast('error', error.data?.error || '删除失败');
    }
  };

  const stats = {
    total: plans.length,
    enabled: plans.filter(p => p.enabled).length,
    disabled: plans.filter(p => !p.enabled).length,
    avgPrice: plans.length > 0 ? (plans.reduce((sum, p) => sum + p.price, 0) / plans.length) : 0
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
          <p className="mt-4 text-muted-foreground">正在加载套餐数据...</p>
        </div>
      </div>
    );
  }

  return (
    <ProtectedRoute requireAdmin>
      <div className="space-y-6">
        {/* RelayX 套餐管理标题 */}
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-2 bg-muted rounded-lg">
                  <Package className="w-6 h-6 text-foreground" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-foreground">套餐管理</h1>
                  <p className="text-muted-foreground">
                    RelayX 订阅套餐和定价策略 · 共 {plans.length} 个套餐
                  </p>
                </div>
              </div>
              <CreatePlanDialog onPlanCreated={loadPlans} />
            </div>
          </CardContent>
        </Card>

        {/* RelayX 套餐统计 */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-card p-6 text-center">
            <div className="text-3xl font-bold text-foreground">{stats.total}</div>
            <div className="text-sm text-muted-foreground">套餐总数</div>
            <div className="text-xs text-muted-foreground mt-1">已创建的套餐</div>
          </Card>
          
          <Card className="bg-card p-6 text-center">
            <div className="text-3xl font-bold text-green-400">{stats.enabled}</div>
            <div className="text-sm text-muted-foreground">启用套餐</div>
            <div className="text-xs text-green-400 mt-1">可供订阅</div>
          </Card>
          
          <Card className="bg-card p-6 text-center">
            <div className="text-3xl font-bold text-red-400">{stats.disabled}</div>
            <div className="text-sm text-muted-foreground">禁用套餐</div>
            <div className="text-xs text-red-400 mt-1">暂停销售</div>
          </Card>
          
          <Card className="bg-card p-6 text-center">
            <div className="text-2xl font-bold text-primary">¥{stats.avgPrice.toFixed(2)}</div>
            <div className="text-sm text-muted-foreground">平均价格</div>
            <div className="text-xs text-muted-foreground mt-1">套餐定价</div>
          </Card>
        </div>


        {/* RelayX 套餐列表 */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-foreground">
              <Package className="w-5 h-5" />
              套餐列表
            </CardTitle>
            <CardDescription>
              管理所有订阅套餐的配置和定价策略
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            {plans.length === 0 ? (
              <div className="text-center py-12">
                <Package className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <CardTitle className="mb-2">还没有套餐</CardTitle>
                <CardDescription className="mb-6">
                  创建第一个 RelayX 订阅套餐
                </CardDescription>
                <CreatePlanDialog onPlanCreated={loadPlans} />
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>套餐信息</TableHead>
                    <TableHead>价格</TableHead>
                    <TableHead>配额限制</TableHead>
                    <TableHead>状态</TableHead>
                    <TableHead>创建时间</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {plans.map((plan) => (
                    <TableRow key={plan.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium flex items-center gap-2">
                            {plan.name}
                            {plan.is_default && (
                              <Badge variant="success" className="text-xs">
                                <Crown className="w-3 h-3 mr-1" />
                                默认
                              </Badge>
                            )}
                          </div>
                          {plan.description && (
                            <div className="text-sm text-muted-foreground">
                              {plan.description}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium text-lg">¥{plan.price}</div>
                          <Badge variant="outline" className="text-xs">
                            {plan.billing_cycle === 'monthly'
                              ? '月付'
                              : plan.billing_cycle === 'yearly'
                              ? '年付'
                              : '永久'}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center gap-1 text-sm">
                            <Activity className="w-3 h-3 text-muted-foreground" />
                            {plan.max_rules === -1 ? '无限' : plan.max_rules} 隧道
                          </div>
                          <div className="flex items-center gap-1 text-sm">
                            <Database className="w-3 h-3 text-muted-foreground" />
                            {plan.max_traffic === -1 ? '无限' : formatBytes(plan.max_traffic)} 流量
                          </div>
                          <div className="flex items-center gap-1 text-sm">
                            <Zap className="w-3 h-3 text-muted-foreground" />
                            {plan.max_bandwidth === -1 ? '无限' : formatBytes(plan.max_bandwidth)}/s 带宽
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={plan.enabled ? 'success' : 'secondary'}>
                          {plan.enabled ? '销售中' : '已停售'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">
                        {formatDate(plan.created_at, false)}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => togglePlanStatus(plan.id, plan.enabled)}
                          >
                            {plan.enabled ? (
                              <ToggleRight className="w-4 h-4" />
                            ) : (
                              <ToggleLeft className="w-4 h-4" />
                            )}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => deletePlan(plan.id, plan.name)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </ProtectedRoute>
  );
}

