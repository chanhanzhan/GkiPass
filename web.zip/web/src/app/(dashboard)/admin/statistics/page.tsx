'use client';

import { useEffect, useState } from 'react';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { api } from '@/lib/api';
import { formatBytes } from '@/lib/utils';
import type { StatisticsOverview } from '@/types';

export default function AdminStatisticsPage() {
  const [statistics, setStatistics] = useState<StatisticsOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | 'all'>('7d');

  useEffect(() => {
    loadStatistics();
  }, [timeRange]);

  async function loadStatistics() {
    try {
      const data = await api.statistics.overview();
      setStatistics(data);
    } catch (error) {
      console.error('Failed to load statistics:', error);
    } finally {
      setLoading(false);
    }
  }

  const handleExportData = () => {
    if (!statistics) return;
    
    const data = {
      export_time: new Date().toISOString(),
      time_range: timeRange,
      statistics: {
        total_tunnels: statistics.total_tunnels,
        active_tunnels: statistics.active_tunnels,
        total_nodes: statistics.total_nodes,
        online_nodes: statistics.online_nodes,
        total_traffic: statistics.total_traffic,
        traffic_today: statistics.traffic_today,
      },
      traffic_history: statistics.traffic_history,
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `statistics-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  if (!statistics) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">无法加载统计数据</p>
      </div>
    );
  }

  return (
    <ProtectedRoute requireAdmin>
      <div className="space-y-6">
      {/* 页面标题 */}
      <div className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-2xl p-6 text-white shadow-xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-black mb-2">系统统计</h1>
            <p className="text-blue-100">查看系统整体运行情况和详细数据分析</p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={handleExportData}
              className="px-4 py-2 bg-white text-blue-600 rounded-lg hover:bg-blue-50 transition-colors font-semibold shadow-lg"
            >
              📊 导出数据
            </button>
          </div>
        </div>
      </div>

      {/* 时间范围选择 */}
      <div className="flex gap-3">
        <button
          onClick={() => setTimeRange('7d')}
          className={`px-6 py-2 rounded-lg font-semibold transition-all ${
            timeRange === '7d'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'bg-white text-gray-600 hover:bg-gray-100'
          }`}
        >
          最近7天
        </button>
        <button
          onClick={() => setTimeRange('30d')}
          className={`px-6 py-2 rounded-lg font-semibold transition-all ${
            timeRange === '30d'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'bg-white text-gray-600 hover:bg-gray-100'
          }`}
        >
          最近30天
        </button>
        <button
          onClick={() => setTimeRange('90d')}
          className={`px-6 py-2 rounded-lg font-semibold transition-all ${
            timeRange === '90d'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'bg-white text-gray-600 hover:bg-gray-100'
          }`}
        >
          最近90天
        </button>
        <button
          onClick={() => setTimeRange('all')}
          className={`px-6 py-2 rounded-lg font-semibold transition-all ${
            timeRange === 'all'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'bg-white text-gray-600 hover:bg-gray-100'
          }`}
        >
          全部时间
        </button>
      </div>

      {/* 核心指标 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl shadow-xl p-6 text-white hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm font-semibold">总隧道数</p>
              <p className="text-4xl font-black mt-2">{statistics.total_tunnels}</p>
              <p className="text-blue-200 text-xs mt-3">
                活跃: <span className="font-bold">{statistics.active_tunnels}</span> | 
                活跃率: <span className="font-bold">
                  {statistics.total_tunnels > 0 
                    ? ((statistics.active_tunnels / statistics.total_tunnels) * 100).toFixed(1) 
                    : 0}%
                </span>
              </p>
            </div>
            <span className="text-5xl opacity-80">🔗</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl shadow-xl p-6 text-white hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm font-semibold">总节点数</p>
              <p className="text-4xl font-black mt-2">{statistics.total_nodes}</p>
              <p className="text-green-200 text-xs mt-3">
                在线: <span className="font-bold">{statistics.online_nodes}</span> | 
                在线率: <span className="font-bold">
                  {statistics.total_nodes > 0 
                    ? ((statistics.online_nodes / statistics.total_nodes) * 100).toFixed(1) 
                    : 0}%
                </span>
              </p>
            </div>
            <span className="text-5xl opacity-80">🖥️</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl shadow-xl p-6 text-white hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm font-semibold">总流量</p>
              <p className="text-3xl font-black mt-2">{formatBytes(statistics.total_traffic)}</p>
              <p className="text-purple-200 text-xs mt-3">累计流量统计</p>
            </div>
            <span className="text-5xl opacity-80">📊</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl shadow-xl p-6 text-white hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-orange-100 text-sm font-semibold">今日流量</p>
              <p className="text-3xl font-black mt-2">{formatBytes(statistics.traffic_today)}</p>
              <p className="text-orange-200 text-xs mt-3">最近24小时</p>
            </div>
            <span className="text-5xl opacity-80">📈</span>
          </div>
        </div>
      </div>

      {/* 流量趋势 */}
      <div className="bg-white rounded-2xl shadow-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black text-gray-900">📈 流量趋势</h2>
          <span className="text-sm text-gray-500">显示最近数据</span>
        </div>
        {statistics.traffic_history && statistics.traffic_history.length > 0 ? (
          <div className="space-y-3">
            {statistics.traffic_history.slice(-7).map((item, index) => {
              const total = item.upload + item.download;
              const maxTotal = Math.max(...statistics.traffic_history!.slice(-7).map(h => h.upload + h.download));
              const percentage = maxTotal > 0 ? (total / maxTotal) * 100 : 0;
              
              return (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="font-bold text-gray-900">{item.date}</p>
                    <div className="flex items-center space-x-6 text-sm">
                      <div>
                        <span className="text-gray-500">↑ </span>
                        <span className="font-bold text-green-600">{formatBytes(item.upload)}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">↓ </span>
                        <span className="font-bold text-blue-600">{formatBytes(item.download)}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">总计: </span>
                        <span className="font-black text-gray-900">
                          {formatBytes(total)}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📊</div>
            <p className="text-gray-500">暂无流量数据</p>
          </div>
        )}
      </div>

      {/* 系统健康状态 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-blue-500">
          <h3 className="text-sm font-bold text-gray-500 mb-4 uppercase tracking-wider">隧道状态</h3>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-4xl font-black text-gray-900">
                {statistics.total_tunnels > 0
                  ? ((statistics.active_tunnels / statistics.total_tunnels) * 100).toFixed(1)
                  : 0}
                %
              </p>
              <p className="text-sm text-gray-500 mt-2">活跃率</p>
              <p className="text-xs text-gray-400 mt-1">
                {statistics.active_tunnels} / {statistics.total_tunnels} 隧道活跃
              </p>
            </div>
            <div className="w-20 h-20 rounded-full bg-blue-100 flex items-center justify-center">
              <span className="text-3xl">🔗</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-green-500">
          <h3 className="text-sm font-bold text-gray-500 mb-4 uppercase tracking-wider">节点状态</h3>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-4xl font-black text-gray-900">
                {statistics.total_nodes > 0
                  ? ((statistics.online_nodes / statistics.total_nodes) * 100).toFixed(1)
                  : 0}
                %
              </p>
              <p className="text-sm text-gray-500 mt-2">在线率</p>
              <p className="text-xs text-gray-400 mt-1">
                {statistics.online_nodes} / {statistics.total_nodes} 节点在线
              </p>
            </div>
            <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center">
              <span className="text-3xl">🖥️</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-green-500">
          <h3 className="text-sm font-bold text-gray-500 mb-4 uppercase tracking-wider">系统状态</h3>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-3xl font-black text-green-600">良好</p>
              <p className="text-sm text-gray-500 mt-2">运行正常</p>
              <p className="text-xs text-gray-400 mt-1">所有服务正常运行</p>
            </div>
            <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center animate-pulse">
              <span className="text-3xl">✅</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    </ProtectedRoute>
  );
}






