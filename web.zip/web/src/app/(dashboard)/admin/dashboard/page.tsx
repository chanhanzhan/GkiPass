'use client';

import { useEffect, useState } from 'react';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { api } from '@/lib/api';
import Link from 'next/link';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { SystemStatsCard } from '@/components/admin/SystemStatsCard';
import { SystemHealthCard } from '@/components/admin/SystemHealthCard';
import { TrafficChart } from '@/components/charts/TrafficChart';
import { SystemMetricsChart } from '@/components/charts/SystemMetricsChart';
import { UserGrowthChart } from '@/components/charts/UserGrowthChart';
import { RevenueChart } from '@/components/charts/RevenueChart';
import { 
  Crown,
  Settings,
  BarChart3,
  Bell,
  UserPlus,
  ServerIcon,
  Package,
  RefreshCw,
  Users,
  Server,
  Shield
} from 'lucide-react';

/* eslint-disable @typescript-eslint/no-explicit-any */

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadStats();
    // 设置自动刷新
    const interval = setInterval(loadStats, 30000); // 30秒刷新一次
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadStats() {
    setRefreshing(true);
    try {
      // 调用管理员统计API
      const data = await api.adminStats.overview();
      setStats(data);
    } catch (error) {
      console.error('Failed to load stats:', error);
      // 模拟数据用于演示
      setStats({
        total_users: 1245,
        total_nodes: 89,
        total_tunnels: 456,
        total_subscriptions: 234,
        online_users: 187,
        system_health: 'healthy'
      });
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  const systemServices = [
    { name: 'API 服务', status: 'healthy' as const, uptime: '99.9%', responseTime: '45ms' },
    { name: 'MySQL 数据库', status: 'healthy' as const, uptime: '99.8%', responseTime: '12ms' },
    { name: 'Redis 缓存', status: 'healthy' as const, uptime: '99.9%', responseTime: '3ms' },
    { name: 'WebSocket 服务', status: 'warning' as const, uptime: '98.5%', responseTime: '78ms' },
    { name: '文件存储', status: 'healthy' as const, uptime: '100%', responseTime: '25ms' }
  ];

  // 模拟图表数据
  const trafficData = [
    { date: '2025-01-01', upload: 1200000000, download: 2800000000, total: 4000000000 },
    { date: '2025-01-02', upload: 1500000000, download: 3200000000, total: 4700000000 },
    { date: '2025-01-03', upload: 1800000000, download: 4100000000, total: 5900000000 },
    { date: '2025-01-04', upload: 1600000000, download: 3500000000, total: 5100000000 },
    { date: '2025-01-05', upload: 2100000000, download: 4800000000, total: 6900000000 },
    { date: '2025-01-06', upload: 1900000000, download: 4300000000, total: 6200000000 },
    { date: '2025-01-07', upload: 2300000000, download: 5100000000, total: 7400000000 },
  ];

  const userGrowthData = [
    { month: '10月', newUsers: 45, activeUsers: 320, totalUsers: 1150 },
    { month: '11月', newUsers: 67, activeUsers: 387, totalUsers: 1217 },
    { month: '12月', newUsers: 89, activeUsers: 456, totalUsers: 1306 },
    { month: '1月', newUsers: 123, activeUsers: 512, totalUsers: 1429 },
  ];

  const revenueData = [
    { date: '2025-01-01', revenue: 1200.50, orders: 15, averageOrderValue: 80.03 },
    { date: '2025-01-02', revenue: 980.30, orders: 12, averageOrderValue: 81.69 },
    { date: '2025-01-03', revenue: 1450.80, orders: 18, averageOrderValue: 80.60 },
    { date: '2025-01-04', revenue: 1380.20, orders: 16, averageOrderValue: 86.26 },
    { date: '2025-01-05', revenue: 1680.90, orders: 21, averageOrderValue: 80.04 },
    { date: '2025-01-06', revenue: 1520.40, orders: 19, averageOrderValue: 80.02 },
    { date: '2025-01-07', revenue: 1780.60, orders: 22, averageOrderValue: 80.93 },
  ];

  const systemMetricsData = [
    { time: '2025-01-08T08:00:00Z', cpu: 25.5, memory: 68.2, connections: 245 },
    { time: '2025-01-08T08:15:00Z', cpu: 28.3, memory: 70.1, connections: 287 },
    { time: '2025-01-08T08:30:00Z', cpu: 32.1, memory: 69.5, connections: 312 },
    { time: '2025-01-08T08:45:00Z', cpu: 29.8, memory: 71.3, connections: 298 },
    { time: '2025-01-08T09:00:00Z', cpu: 26.4, memory: 67.9, connections: 265 },
  ];

  return (
    <ProtectedRoute requireAdmin>
      <div className="space-y-6">
        {/* RelayX 管理员控制台标题 */}
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-2 bg-muted rounded-lg">
                  <Crown className="w-8 h-8 text-foreground" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-foreground">RelayX 管理后台</h1>
                  <div className="flex items-center gap-3">
                    <p className="text-muted-foreground">系统管理与监控中心</p>
                    <Badge variant="outline">管理员专用</Badge>
                  </div>
                </div>
              </div>
              <div className="hidden lg:block text-right">
                <div className="text-sm text-muted-foreground mb-1">当前在线</div>
                <div className="text-2xl font-bold text-foreground">{stats?.online_users || 0} 人</div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mt-2"
                  onClick={loadStats}
                  disabled={refreshing}
                >
                  <RefreshCw className={`w-3 h-3 mr-1 ${refreshing ? 'animate-spin' : ''}`} />
                  刷新
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 系统核心指标 */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="text-center">
              <div className="animate-spin rounded-full h-16 w-16 border-4 border-purple-200 border-t-purple-600 mx-auto"></div>
              <p className="mt-6 text-muted-foreground font-medium">正在加载管理数据...</p>
            </div>
          </div>
        ) : (
          <>
            {/* RelayX 管理员统计卡片 */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card className="bg-card p-6 text-center">
                <div className="text-3xl font-bold text-foreground">{stats?.total_users || 0}</div>
                <div className="text-sm text-muted-foreground">注册用户</div>
                <div className="text-xs text-green-400 mt-1">{Math.floor((stats?.total_users || 0) * 0.7)} 活跃</div>
              </Card>
              
              <Card className="bg-card p-6 text-center">
                <div className="text-3xl font-bold text-foreground">{stats?.total_nodes || 0}</div>
                <div className="text-sm text-muted-foreground">节点总数</div>
                <div className="text-xs text-green-400 mt-1">{Math.floor((stats?.total_nodes || 0) * 0.85)} 在线</div>
              </Card>
              
              <Card className="bg-card p-6 text-center">
                <div className="text-3xl font-bold text-foreground">{stats?.total_tunnels || 0}</div>
                <div className="text-sm text-muted-foreground">隧道总数</div>
                <div className="text-xs text-green-400 mt-1">{Math.floor((stats?.total_tunnels || 0) * 0.9)} 启用</div>
              </Card>
              
              <Card className="bg-card p-6 text-center">
                <div className="text-3xl font-bold text-foreground">{stats?.total_subscriptions || 0}</div>
                <div className="text-sm text-muted-foreground">订阅总数</div>
                <div className="text-xs text-green-400 mt-1">{Math.floor((stats?.total_subscriptions || 0) * 0.6)} 付费</div>
              </Card>
            </div>

            {/* 系统监控面板 */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* 系统健康状态 */}
              <SystemHealthCard 
                services={systemServices}
                onRefresh={loadStats}
                refreshing={refreshing}
              />

              {/* 今日统计 */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" />
                    今日统计
                  </CardTitle>
                  <CardDescription>
                    当日关键指标和增长情况
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-700">新增用户</span>
                    <div className="flex items-center gap-2">
                      <Badge variant="info">+12</Badge>
                      <span className="text-xs text-green-600">↑ 20%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-700">新建隧道</span>
                    <div className="flex items-center gap-2">
                      <Badge variant="info">+28</Badge>
                      <span className="text-xs text-green-600">↑ 15%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-700">流量传输</span>
                    <div className="flex items-center gap-2">
                      <Badge variant="info">2.3 TB</Badge>
                      <span className="text-xs text-green-600">↑ 8%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-700">收入统计</span>
                    <div className="flex items-center gap-2">
                      <Badge variant="info">¥1,240</Badge>
                      <span className="text-xs text-green-600">↑ 25%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* 快速操作面板 */}
              <Card className="bg-gradient-to-br from-purple-500 to-pink-500 border-0 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    <Crown className="w-5 h-5" />
                    管理员快速操作
                  </CardTitle>
                  <CardDescription className="text-white/80">
                    常用管理功能快速入口
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button variant="secondary" size="lg" className="w-full justify-start" asChild>
                    <Link href="/admin/users">
                      <UserPlus className="w-4 h-4 mr-2" />
                      创建用户账号
                    </Link>
                  </Button>
                  <Button variant="secondary" size="lg" className="w-full justify-start" asChild>
                    <Link href="/admin/announcements">
                      <Bell className="w-4 h-4 mr-2" />
                      发布系统公告
                    </Link>
                  </Button>
                  <Button variant="secondary" size="lg" className="w-full justify-start" asChild>
                    <Link href="/admin/nodes">
                      <ServerIcon className="w-4 h-4 mr-2" />
                      添加新节点
                    </Link>
                  </Button>
                  <Button variant="secondary" size="lg" className="w-full justify-start" asChild>
                    <Link href="/admin/plans">
                      <Package className="w-4 h-4 mr-2" />
                      配置套餐
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* RelayX 管理工具导航 */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-foreground">
                  <Settings className="w-5 h-5" />
                  管理工具
                </CardTitle>
                <CardDescription>
                  RelayX 管理员功能中心 - 快速访问所有管理工具
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Button 
                    asChild 
                    variant="outline" 
                    size="lg"
                    className="h-auto p-6 flex flex-col items-start gap-3 hover:border-purple-300 hover:bg-purple-50"
                  >
                    <Link href="/admin/users">
                      <div className="flex items-center gap-2 w-full">
                        <div className="p-2 bg-purple-100 rounded-lg">
                          <Users className="w-5 h-5 text-purple-600" />
                  </div>
                        <span className="font-semibold">用户管理</span>
                </div>
                      <span className="text-sm text-muted-foreground">管理用户账号和权限设置</span>
                    </Link>
                  </Button>

                  <Button 
                    asChild 
                    variant="outline" 
                    size="lg"
                    className="h-auto p-6 flex flex-col items-start gap-3 hover:border-blue-300 hover:bg-blue-50"
                  >
                    <Link href="/admin/nodes">
                      <div className="flex items-center gap-2 w-full">
                        <div className="p-2 bg-blue-100 rounded-lg">
                          <Server className="w-5 h-5 text-blue-600" />
                  </div>
                        <span className="font-semibold">节点管理</span>
                  </div>
                      <span className="text-sm text-muted-foreground">配置和监控所有节点状态</span>
                    </Link>
                  </Button>

                  <Button 
                    asChild 
                    variant="outline" 
                    size="lg"
                    className="h-auto p-6 flex flex-col items-start gap-3 hover:border-green-300 hover:bg-green-50"
                  >
                    <Link href="/admin/plans">
                      <div className="flex items-center gap-2 w-full">
                        <div className="p-2 bg-green-100 rounded-lg">
                          <Package className="w-5 h-5 text-green-600" />
                  </div>
                        <span className="font-semibold">套餐管理</span>
                </div>
                      <span className="text-sm text-muted-foreground">管理订阅套餐和定价策略</span>
                    </Link>
                  </Button>

                  <Button 
                    asChild 
                    variant="outline" 
                    size="lg"
                    className="h-auto p-6 flex flex-col items-start gap-3 hover:border-orange-300 hover:bg-orange-50"
                  >
                    <Link href="/admin/announcements">
                      <div className="flex items-center gap-2 w-full">
                        <div className="p-2 bg-orange-100 rounded-lg">
                          <Bell className="w-5 h-5 text-orange-600" />
                  </div>
                        <span className="font-semibold">公告管理</span>
                </div>
                      <span className="text-sm text-muted-foreground">发布和管理系统公告通知</span>
                    </Link>
                  </Button>

                  <Button 
                    asChild 
                    variant="outline" 
                    size="lg"
                    className="h-auto p-6 flex flex-col items-start gap-3 hover:border-red-300 hover:bg-red-50"
                  >
                    <Link href="/admin/policies">
                      <div className="flex items-center gap-2 w-full">
                        <div className="p-2 bg-red-100 rounded-lg">
                          <Shield className="w-5 h-5 text-red-600" />
                  </div>
                        <span className="font-semibold">策略管理</span>
                  </div>
                      <span className="text-sm text-muted-foreground">配置访问控制和安全策略</span>
                    </Link>
                  </Button>

                  <Button 
                    asChild 
                    variant="outline" 
                    size="lg"
                    className="h-auto p-6 flex flex-col items-start gap-3 hover:border-indigo-300 hover:bg-indigo-50"
                  >
                    <Link href="/admin/statistics">
                      <div className="flex items-center gap-2 w-full">
                        <div className="p-2 bg-indigo-100 rounded-lg">
                          <BarChart3 className="w-5 h-5 text-indigo-600" />
                        </div>
                        <span className="font-semibold">系统统计</span>
                      </div>
                      <span className="text-sm text-muted-foreground">查看详细的统计数据报表</span>
                  </Link>
                  </Button>

                  <Button 
                    asChild 
                    variant="outline" 
                    size="lg"
                    className="h-auto p-6 flex flex-col items-start gap-3 hover:border-gray-300 hover:bg-gray-50"
                  >
                    <Link href="/admin/settings">
                      <div className="flex items-center gap-2 w-full">
                        <div className="p-2 bg-gray-100 rounded-lg">
                          <Settings className="w-5 h-5 text-gray-600" />
                        </div>
                        <span className="font-semibold">系统设置</span>
                      </div>
                      <span className="text-sm text-muted-foreground">配置系统参数和全局设置</span>
                  </Link>
                  </Button>

                  <Button 
                    asChild 
                    variant="outline" 
                    size="lg"
                    className="h-auto p-6 flex flex-col items-start gap-3 hover:border-teal-300 hover:bg-teal-50"
                  >
                    <Link href="/admin/node-groups">
                      <div className="flex items-center gap-2 w-full">
                        <div className="p-2 bg-teal-100 rounded-lg">
                          <ServerIcon className="w-5 h-5 text-teal-600" />
                        </div>
                        <span className="font-semibold">节点组管理</span>
                      </div>
                      <span className="text-sm text-muted-foreground">管理节点分组和配置策略</span>
                  </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* 数据可视化图表 */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* 流量统计图表 */}
              <TrafficChart 
                data={trafficData}
                type="line"
                title="7日流量趋势"
                description="最近7天的网络流量统计"
              />

              {/* 用户增长图表 */}
              <UserGrowthChart 
                data={userGrowthData}
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* 收入统计图表 */}
              <RevenueChart 
                data={revenueData}
              />

              {/* 系统性能监控图表 */}
              <SystemMetricsChart 
                data={systemMetricsData}
              />
            </div>
          </>
        )}
      </div>
    </ProtectedRoute>
  );
}
