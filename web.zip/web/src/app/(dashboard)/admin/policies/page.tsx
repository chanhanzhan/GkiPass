/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useEffect, useState } from 'react';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { api } from '@/lib/api';
import { formatDate } from '@/lib/utils';

interface Policy {
  id: string;
  name: string;
  description?: string;
  rules: unknown[];
  enabled: boolean;
  created_at: string;
}

export default function AdminPoliciesPage() {
  const [policies, setPolicies] = useState<Policy[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    rules: '',
  });

  useEffect(() => {
    loadPolicies();
  }, []);

  async function loadPolicies() {
    try {
      const data = await api.policies.list();
      setPolicies(Array.isArray(data?.data) ? data.data : Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Failed to load policies:', error);
      setPolicies([]);
    } finally {
      setLoading(false);
    }
  }

  const handleCreate = async () => {
    if (!formData.name) {
      alert('请填写策略名称');
      return;
    }

    try {
      let rules = [];
      if (formData.rules) {
        rules = JSON.parse(formData.rules);
      }

      await api.policies.create({
        name: formData.name,
        description: formData.description,
        rules: rules,
        enabled: true,
      });
      await loadPolicies();
      setFormData({ name: '', description: '', rules: '' });
      setShowCreate(false);
    } catch (error: any) {
      alert(error.data?.error || '创建失败');
    }
  };

  const deployPolicy = async (id: string, name: string) => {
    if (!confirm(`确定要部署策略 "${name}" 吗？`)) {
      return;
    }
    try {
      await api.policies.deploy(id);
      alert('策略已部署到所有节点');
    } catch (error: any) {
      alert(error.data?.error || '部署失败');
    }
  };

  const deletePolicy = async (id: string, name: string) => {
    if (!confirm(`确定要删除策略 "${name}" 吗？`)) {
      return;
    }
    try {
      await api.policies.delete(id);
      await loadPolicies();
    } catch (error: any) {
      alert(error.data?.error || '删除失败');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  return (
    <ProtectedRoute requireAdmin>
      <div className="space-y-6">
      {/* 页面标题和操作 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">策略管理</h1>
          <p className="mt-1 text-sm text-gray-500">
            管理系统访问控制策略和规则
          </p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors font-medium"
        >
          ➕ 创建策略
        </button>
      </div>

      {/* 创建策略弹窗 */}
      {showCreate && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">创建策略</h3>
              <button
                onClick={() => setShowCreate(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  策略名称 *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="例如：默认访问策略"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  策略描述
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={3}
                  placeholder="策略用途说明"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  策略规则 (JSON格式)
                </label>
                <textarea
                  value={formData.rules}
                  onChange={(e) => setFormData({ ...formData, rules: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-sm"
                  rows={8}
                  placeholder='[{"action": "allow", "source": "*", "destination": "*"}]'
                />
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  onClick={() => setShowCreate(false)}
                  className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
                >
                  取消
                </button>
                <button
                  onClick={handleCreate}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                >
                  创建
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 策略列表 */}
      {policies.length === 0 ? (
        <div className="bg-white rounded-lg shadow p-12 text-center">
          <div className="text-6xl mb-4">🛡️</div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            还没有策略
          </h3>
          <p className="text-gray-500 mb-6">
            创建第一个访问控制策略
          </p>
          <button
            onClick={() => setShowCreate(true)}
            className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            创建策略
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {policies.map((policy) => (
            <div key={policy.id} className="bg-white rounded-lg shadow hover:shadow-lg transition-shadow p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">
                    {policy.name}
                  </h3>
                  {policy.description && (
                    <p className="text-sm text-gray-600">{policy.description}</p>
                  )}
                </div>
                <span
                  className={`px-2 py-1 text-xs font-medium rounded ${
                    policy.enabled
                      ? 'bg-green-100 text-green-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}
                >
                  {policy.enabled ? '已启用' : '已禁用'}
                </span>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-gray-500">规则数</span>
                  <span className="font-medium">{policy.rules?.length || 0} 条</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-500">创建时间</span>
                  <span className="text-gray-600">{formatDate(policy.created_at, false)}</span>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t flex justify-between">
                <button
                  onClick={() => deployPolicy(policy.id, policy.name)}
                  className="text-sm text-blue-600 hover:text-blue-700 font-medium"
                >
                  🚀 部署
                </button>
                <div className="space-x-2">
                  <button className="text-sm text-gray-600 hover:text-gray-700">
                    编辑
                  </button>
                  <button
                    onClick={() => deletePolicy(policy.id, policy.name)}
                    className="text-sm text-red-600 hover:text-red-700"
                  >
                    删除
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
    </ProtectedRoute>
  );
}





