'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { formatDate } from '@/lib/utils';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { CreateAnnouncementDialog } from '@/components/admin/CreateAnnouncementDialog';
import { SystemStatsCard } from '@/components/admin/SystemStatsCard';
import { useToast } from '@/components/ui/Toast';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { 
  Bell,
  Plus, 
  Edit,
  Trash2,
  Calendar,
  Flag,
  AlertTriangle,
  CheckCircle,
  XCircle
} from 'lucide-react';

interface Announcement {
  id: string;
  title: string;
  content: string;
  type: 'notice' | 'maintenance' | 'update' | 'warning';
  priority: 'low' | 'normal' | 'high';
  enabled: boolean;
  start_time: string;
  end_time: string;
  created_at: string;
}

export default function AdminAnnouncementsPage() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);
  const { showToast } = useToast();

  useEffect(() => {
    loadAnnouncements();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadAnnouncements() {
    try {
      const data = await api.announcements.listAll();
      setAnnouncements(data.data || []);
    } catch (err) {
      console.error('Failed to load announcements:', err);
      showToast('error', '加载公告失败');
    } finally {
      setLoading(false);
    }
  }

  const handleCreate = () => {
    setEditingAnnouncement(null);
    setShowModal(true);
  };

  const handleEdit = (announcement: Announcement) => {
    setEditingAnnouncement(announcement);
    setShowModal(true);
  };

  const handleCloseModal = () => {
      setShowModal(false);
    setEditingAnnouncement(null);
  };

  const handleDelete = async (id: string, title: string) => {
    if (!confirm(`确定要删除公告 "${title}" 吗？此操作不可逆！`)) return;

    try {
      await api.announcements.delete(id);
      await loadAnnouncements();
      showToast('success', '公告已删除');
    } catch (err) {
      console.error('Failed to delete announcement:', err);
      showToast('error', '删除失败');
    }
  };

  const getTypeInfo = (type: string) => {
    const info: Record<string, { label: string; variant: 'info' | 'warning' | 'success' | 'error'; icon: string }> = {
      notice: { label: '通知', variant: 'info', icon: '📢' },
      maintenance: { label: '维护', variant: 'warning', icon: '🔧' },
      update: { label: '更新', variant: 'success', icon: '🚀' },
      warning: { label: '警告', variant: 'error', icon: '⚠️' },
    };
    return info[type] || info.notice;
  };

  const stats = {
    total: announcements.length,
    enabled: announcements.filter(a => a.enabled).length,
    disabled: announcements.filter(a => !a.enabled).length,
    high_priority: announcements.filter(a => a.priority === 'high').length,
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
          <p className="mt-4 text-muted-foreground">正在加载公告数据...</p>
        </div>
      </div>
    );
  }

  return (
    <ProtectedRoute requireAdmin>
    <div className="space-y-6">
        {/* RelayX 公告管理标题 */}
        <Card className="border-0 bg-slate-800 text-white">
          <CardContent className="p-6">
      <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-white/20 rounded-lg">
                  <Bell className="w-8 h-8" />
                </div>
        <div>
                  <h1 className="text-3xl font-bold">公告管理</h1>
                  <p className="text-white/90">
                    RelayX 系统公告和通知管理 · 共 {announcements.length} 条公告
                  </p>
                </div>
              </div>
              <Button variant="secondary" onClick={handleCreate}>
                <Plus className="w-4 h-4 mr-2" />
                创建公告
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* 公告统计概览 */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <SystemStatsCard
            title="公告总数"
            value={stats.total}
            icon={<Bell className="w-5 h-5" />}
            color="orange"
            description="系统公告总数量"
          />
          <SystemStatsCard
            title="启用中"
            value={stats.enabled}
            icon={<CheckCircle className="w-5 h-5" />}
            color="green"
            description="正在显示的公告"
          />
          <SystemStatsCard
            title="已禁用"
            value={stats.disabled}
            icon={<XCircle className="w-5 h-5" />}
            color="red"
            description="暂停显示的公告"
          />
          <SystemStatsCard
            title="高优先级"
            value={stats.high_priority}
            icon={<AlertTriangle className="w-5 h-5" />}
            color="purple"
            description="重要优先级公告"
          />
      </div>

      {/* 公告列表 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" />
              公告列表
            </CardTitle>
            <CardDescription>
              系统公告和通知信息管理
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
      {announcements.length === 0 ? (
              <div className="text-center py-12">
                <Bell className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <CardTitle className="mb-2">还没有公告</CardTitle>
                <CardDescription className="mb-6">
                  创建第一条 RelayX 系统公告
                </CardDescription>
                <Button onClick={handleCreate} variant="admin">
                  <Plus className="w-4 h-4 mr-2" />
                  创建公告
                </Button>
            </div>
      ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>公告信息</TableHead>
                    <TableHead>类型</TableHead>
                    <TableHead>优先级</TableHead>
                    <TableHead>状态</TableHead>
                    <TableHead>有效期</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                {announcements.map((announcement) => {
                  const typeInfo = getTypeInfo(announcement.type);
                  return (
                      <TableRow key={announcement.id}>
                        <TableCell>
                        <div>
                            <div className="font-medium mb-1">{announcement.title}</div>
                            <p className="text-sm text-muted-foreground line-clamp-2 max-w-md">
                              {announcement.content}
                            </p>
                        </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={typeInfo.variant}>
                            <span className="mr-1">{typeInfo.icon}</span>
                          {typeInfo.label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={
                            announcement.priority === 'high' ? 'error' : 
                            announcement.priority === 'low' ? 'secondary' : 'info'
                          }>
                            {announcement.priority === 'high' ? '⭐ 高' : 
                             announcement.priority === 'low' ? '普通' : '正常'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={announcement.enabled ? 'success' : 'secondary'}>
                            {announcement.enabled ? (
                              <div className="flex items-center gap-1">
                                <CheckCircle className="w-3 h-3" />
                                启用中
          </div>
                            ) : (
                              <div className="flex items-center gap-1">
                                <XCircle className="w-3 h-3" />
                                已禁用
        </div>
      )}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 text-sm">
                            <Calendar className="w-4 h-4 text-muted-foreground" />
              <div>
                              <div>{formatDate(announcement.start_time, false)}</div>
                              <div className="text-xs text-muted-foreground">
                                至 {formatDate(announcement.end_time, false)}
                </div>
                </div>
              </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEdit(announcement)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDelete(announcement.id, announcement.title)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
              </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* 创建/编辑公告对话框 */}
        <CreateAnnouncementDialog
          isOpen={showModal}
          onClose={handleCloseModal}
          onSuccess={loadAnnouncements}
          editingAnnouncement={editingAnnouncement}
        />
    </div>
    </ProtectedRoute>
  );
}









