/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useState, useEffect } from 'react';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { api } from '@/lib/api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { SystemConfigCard } from '@/components/admin/SystemConfigCard';
import { useToast } from '@/components/ui/Toast';
import { 
  Settings, 
  Database, 
  Shield, 
  Mail,
  Globe,
  Server,
  Bell,
  Lock
} from 'lucide-react';

interface ConfigItem {
  key: string
  name: string
  description: string
  value: string | number | boolean
  type: 'string' | 'number' | 'boolean' | 'select'
  options?: string[]
  category: string
}

export default function AdminSettingsPage() {
  const { showToast } = useToast();
  const [loading, setLoading] = useState(true);

  // 系统基本配置
  const [basicConfigs] = useState<ConfigItem[]>([
    {
      key: 'site_name',
      name: '站点名称',
      description: '显示在网站标题和页面中的名称',
      value: 'RelayX',
      type: 'string',
      category: 'basic'
    },
    {
      key: 'site_description', 
      name: '站点描述',
      description: '网站的描述信息',
      value: '功能强大的隧道管理面板',
      type: 'string',
      category: 'basic'
    },
    {
      key: 'allow_register',
      name: '允许用户注册',
      description: '是否允许新用户注册账号',
      value: true,
      type: 'boolean',
      category: 'basic'
    },
    {
      key: 'maintenance_mode',
      name: '维护模式',
      description: '开启后用户将无法访问系统',
      value: false,
      type: 'boolean',
      category: 'basic'
    }
  ]);

  // 安全配置
  const [securityConfigs] = useState<ConfigItem[]>([
    {
      key: 'max_login_attempts',
      name: '最大登录尝试次数',
      description: '超过此次数将锁定账号',
      value: 5,
      type: 'number',
      category: 'security'
    },
    {
      key: 'session_timeout',
      name: '会话超时时间 (小时)',
      description: '用户会话的有效时长',
      value: 24,
      type: 'number',
      category: 'security'
    },
    {
      key: 'password_min_length',
      name: '密码最小长度',
      description: '用户密码的最小长度要求',
      value: 8,
      type: 'number',
      category: 'security'
    },
    {
      key: 'enable_audit_log',
      name: '启用审计日志',
      description: '记录所有管理员操作',
      value: true,
      type: 'boolean',
      category: 'security'
    }
  ]);

  // 邮件配置
  const [emailConfigs] = useState<ConfigItem[]>([
    {
      key: 'smtp_host',
      name: 'SMTP 服务器',
      description: '邮件发送服务器地址',
      value: 'smtp.gmail.com',
      type: 'string',
      category: 'email'
    },
    {
      key: 'smtp_port',
      name: 'SMTP 端口',
      description: '邮件服务器端口号',
      value: 587,
      type: 'number',
      category: 'email'
    },
    {
      key: 'smtp_encryption',
      name: '加密方式',
      description: 'SMTP 连接加密方式',
      value: 'tls',
      type: 'select',
      options: ['none', 'tls', 'ssl'],
      category: 'email'
    },
    {
      key: 'from_email',
      name: '发件人邮箱',
      description: '系统邮件的发件人地址',
      value: 'noreply@relayx.cc',
      type: 'string',
      category: 'email'
    }
  ]);

  // 系统性能配置
  const [performanceConfigs] = useState<ConfigItem[]>([
    {
      key: 'max_connections_per_user',
      name: '用户最大连接数',
      description: '单个用户的最大同时连接数',
      value: 1000,
      type: 'number',
      category: 'performance'
    },
    {
      key: 'connection_timeout',
      name: '连接超时时间 (秒)',
      description: '网络连接的超时设置',
      value: 30,
      type: 'number',
      category: 'performance'
    },
    {
      key: 'enable_cache',
      name: '启用缓存',
      description: '开启Redis缓存提高性能',
      value: true,
      type: 'boolean',
      category: 'performance'
    },
    {
      key: 'log_level',
      name: '日志级别',
      description: '系统日志记录级别',
      value: 'info',
      type: 'select',
      options: ['debug', 'info', 'warn', 'error'],
      category: 'performance'
    }
  ]);

  useEffect(() => {
    // 模拟加载配置
    setTimeout(() => setLoading(false), 1000);
  }, []);

  const handleSaveConfigs = async (configs: ConfigItem[]) => {
    // 模拟保存API调用
    await new Promise(resolve => setTimeout(resolve, 1000));
    showToast('success', '配置已保存');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
          <p className="mt-4 text-muted-foreground">正在加载系统配置...</p>
        </div>
      </div>
    );
  }

  return (
    <ProtectedRoute requireAdmin>
      <div className="space-y-6">
        {/* RelayX 系统设置标题 */}
        <Card className="border-0 bg-slate-800 text-white">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/20 rounded-lg">
                <Settings className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-3xl font-bold">系统设置</h1>
                <p className="text-white/90">
                  RelayX 全局配置和系统参数管理
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* 基本设置 */}
          <SystemConfigCard
            title="基本设置"
            description="系统基础信息和核心配置"
            icon={<Globe className="w-5 h-5" />}
            configs={basicConfigs}
            onSave={handleSaveConfigs}
          />

          {/* 安全设置 */}
          <SystemConfigCard
            title="安全设置"
            description="账号安全和访问控制配置"
            icon={<Shield className="w-5 h-5" />}
            configs={securityConfigs}
            onSave={handleSaveConfigs}
          />

          {/* 邮件设置 */}
          <SystemConfigCard
            title="邮件配置"
            description="SMTP服务器和邮件发送设置"
            icon={<Mail className="w-5 h-5" />}
            configs={emailConfigs}
            onSave={handleSaveConfigs}
          />

          {/* 性能设置 */}
          <SystemConfigCard
            title="性能配置"
            description="系统性能优化和资源管理"
            icon={<Server className="w-5 h-5" />}
            configs={performanceConfigs}
            onSave={handleSaveConfigs}
          />
        </div>
      </div>
    </ProtectedRoute>
  );
}