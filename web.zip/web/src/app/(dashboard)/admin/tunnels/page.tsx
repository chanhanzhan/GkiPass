/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { api } from '@/lib/api';
import { formatBytes, getProtocolText } from '@/lib/utils';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { TunnelMonitorCard } from '@/components/admin/TunnelMonitorCard';
import { SystemStatsCard } from '@/components/admin/SystemStatsCard';
import { useToast } from '@/components/ui/Toast';
import { 
  Activity, 
  User, 
  Search,
  Filter,
  RefreshCw,
  TrendingUp,
  Database,
  Wifi,
  AlertCircle
} from 'lucide-react';

export default function AdminTunnelsPage() {
  const [tunnels, setTunnels] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [filteredTunnels, setFilteredTunnels] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [userFilter, setUserFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'enabled' | 'disabled'>('all');
  const [protocolFilter, setProtocolFilter] = useState<string>('all');
  const { showToast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  // 隧道过滤逻辑
  useEffect(() => {
    let filtered = tunnels;

    // 按用户过滤
    if (userFilter) {
      filtered = filtered.filter(tunnel => tunnel.user_id === userFilter);
    }

    // 按状态过滤
    if (statusFilter !== 'all') {
      filtered = filtered.filter(tunnel => 
        statusFilter === 'enabled' ? tunnel.enabled : !tunnel.enabled
      );
    }

    // 按协议过滤
    if (protocolFilter !== 'all') {
      filtered = filtered.filter(tunnel => tunnel.protocol === protocolFilter);
    }

    // 按搜索词过滤
    if (searchTerm) {
      filtered = filtered.filter(tunnel => 
        tunnel.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tunnel.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tunnel.id.includes(searchTerm)
      );
    }

    setFilteredTunnels(filtered);
  }, [tunnels, userFilter, statusFilter, protocolFilter, searchTerm]);

  async function loadData() {
    setRefreshing(true);
    try {
      const [tunnelsData, usersData] = await Promise.all([
        api.tunnels.list(),
        api.users.list(),
      ]);

      setTunnels(tunnelsData.data || tunnelsData || []);
      setUsers(usersData.data || usersData || []);
    } catch (error) {
      console.error('Failed to load data:', error);
      showToast('error', '加载隧道数据失败');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  const handleToggleTunnel = async (tunnelId: string, currentStatus: boolean) => {
    try {
      await api.tunnels.toggle(tunnelId);
      await loadData();
      showToast('success', currentStatus ? '隧道已禁用' : '隧道已启用');
    } catch (error: any) {
      showToast('error', error.data?.error || '操作失败');
    }
  };

  const stats = {
    total: tunnels.length,
    enabled: tunnels.filter(t => t.enabled).length,
    disabled: tunnels.filter(t => !t.enabled).length,
    totalTraffic: tunnels.reduce((sum, t) => sum + (t.traffic_in || 0) + (t.traffic_out || 0), 0),
  };

  // 获取协议统计
  const protocolStats = tunnels.reduce((acc: Record<string, number>, tunnel) => {
    acc[tunnel.protocol] = (acc[tunnel.protocol] || 0) + 1;
    return acc;
  }, {});

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
          <p className="mt-4 text-muted-foreground">正在加载隧道监控数据...</p>
        </div>
      </div>
    );
  }

  return (
    <ProtectedRoute requireAdmin>
      <div className="space-y-6">
        {/* RelayX 隧道监控中心标题 */}
        <Card className="border-0 bg-slate-800 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-white/20 rounded-lg">
                  <Activity className="w-8 h-8" />
                </div>
                <div>
                  <h1 className="text-3xl font-bold">隧道监控中心</h1>
                  <p className="text-white/90">
                    RelayX 全局隧道状态监控和管理 · 共 {tunnels.length} 个隧道
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                  实时监控
                </Badge>
                <Button 
                  variant="secondary" 
                  size="sm"
                  onClick={loadData}
                  disabled={refreshing}
                >
                  <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                  刷新
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 隧道统计概览 */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <SystemStatsCard
            title="隧道总数"
            value={stats.total}
            icon={<Activity className="w-5 h-5" />}
            color="blue"
            description="全平台隧道数量"
            trend={{
              value: 15,
              type: 'up',
              label: '较上周'
            }}
          />
          <SystemStatsCard
            title="运行中"
            value={stats.enabled}
            icon={<Wifi className="w-5 h-5" />}
            color="green"
            description="正常运行的隧道"
            trend={{
              value: 8,
              type: 'up',
              label: '较上周'
            }}
          />
          <SystemStatsCard
            title="已停用"
            value={stats.disabled}
            icon={<AlertCircle className="w-5 h-5" />}
            color="red"
            description="暂停或禁用的隧道"
          />
          <SystemStatsCard
            title="总流量"
            value={formatBytes(stats.totalTraffic)}
            icon={<TrendingUp className="w-5 h-5" />}
            color="purple"
            description="累计数据传输量"
            trend={{
              value: 23,
              type: 'up',
              label: '较上周'
            }}
          />
        </div>

        {/* 搜索和过滤 */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5" />
                  隧道监控列表
                </CardTitle>
                <CardDescription>
                  全平台隧道实时状态监控和流量分析
                </CardDescription>
              </div>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    placeholder="搜索隧道名称或描述..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-64"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-muted-foreground" />
                  <Select value={userFilter} onValueChange={setUserFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="选择用户" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">所有用户</SelectItem>
                      {users.map((user: any) => (
                        <SelectItem key={user.id} value={user.id}>
                          {user.username}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex gap-1">
                  <Button
                    variant={statusFilter === 'all' ? 'admin' : 'outline'}
                    size="sm"
                    onClick={() => setStatusFilter('all')}
                  >
                    全部
                  </Button>
                  <Button
                    variant={statusFilter === 'enabled' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setStatusFilter('enabled')}
                  >
                    运行中
                  </Button>
                  <Button
                    variant={statusFilter === 'disabled' ? 'secondary' : 'outline'}
                    size="sm"
                    onClick={() => setStatusFilter('disabled')}
                  >
                    已停用
                  </Button>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {filteredTunnels.length === 0 ? (
              <div className="text-center py-12">
                <Activity className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <CardTitle className="mb-2">
                  {searchTerm || userFilter || statusFilter !== 'all' 
                    ? '未找到匹配的隧道' 
                    : '暂无隧道数据'}
                </CardTitle>
                <CardDescription>
                  {searchTerm || userFilter || statusFilter !== 'all'
                    ? '请尝试调整搜索条件或过滤器'
                    : '等待用户创建隧道'}
                </CardDescription>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredTunnels.map((tunnel) => {
                  const user = users.find((u: any) => u.id === tunnel.user_id);
                  return (
                    <TunnelMonitorCard
                      key={tunnel.id}
                      tunnel={tunnel}
                      user={user}
                      onToggle={handleToggleTunnel}
                    />
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* 协议使用情况 */}
        {Object.keys(protocolStats).length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5" />
                协议分布统计
              </CardTitle>
              <CardDescription>
                不同协议类型的隧道使用分布
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {Object.entries(protocolStats).map(([protocol, count]) => (
                  <div key={protocol} className="text-center p-4 bg-muted/50 rounded-lg">
                    <Badge variant="outline" className="mb-2">
                      {getProtocolText(protocol)}
                    </Badge>
                    <div className="text-2xl font-bold">{count}</div>
                    <div className="text-xs text-muted-foreground">个隧道</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </ProtectedRoute>
  );
}


