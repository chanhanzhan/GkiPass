/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { api } from '@/lib/api';
import { getNodeTypeText, cn } from '@/lib/utils';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { CreateNodeDialog } from '@/components/admin/CreateNodeDialog';
import { SystemStatsCard } from '@/components/admin/SystemStatsCard';
import { useToast } from '@/components/ui/Toast';
import { 
  Server,
  Wifi, 
  WifiOff,
  Search,
  Eye,
  Key,
  Trash2,
  CheckSquare,
  Square,
  Filter,
  MapPin,
  Hash
} from 'lucide-react';
import type { Node, NodeGroup } from '@/types';

export default function AdminNodesPage() {
  const [nodes, setNodes] = useState<Node[]>([]);
  const [nodeGroups, setNodeGroups] = useState<NodeGroup[]>([]);
  const [filteredNodes, setFilteredNodes] = useState<Node[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedNodes, setSelectedNodes] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [groupFilter, setGroupFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<'all' | 'entry' | 'exit'>('all');
  const { showToast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  // 节点过滤逻辑
  useEffect(() => {
    let filtered = nodes;

    // 按节点组过滤
    if (groupFilter !== 'all') {
      filtered = filtered.filter(node => node.group_id === groupFilter);
    }

    // 按状态过滤
    if (statusFilter !== 'all') {
      filtered = filtered.filter(node => 
        statusFilter === 'online' ? node.status === 'online' : node.status !== 'online'
      );
    }

    // 按类型过滤
    if (typeFilter !== 'all') {
      filtered = filtered.filter(node => node.type === typeFilter);
    }

    // 按搜索词过滤
    if (searchTerm) {
      filtered = filtered.filter(node => 
        node.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        node.ip.includes(searchTerm) ||
        node.uuid?.includes(searchTerm) ||
        node.id.includes(searchTerm)
      );
    }

    setFilteredNodes(filtered);
  }, [nodes, groupFilter, statusFilter, typeFilter, searchTerm]);

  async function loadData() {
    try {
      const [nodesData, groupsData] = await Promise.all([
        api.nodes.list(),
        api.nodeGroups.list(),
      ]);
      setNodes(Array.isArray(nodesData?.data) ? nodesData.data : Array.isArray(nodesData) ? nodesData : []);
      setNodeGroups(Array.isArray(groupsData?.data) ? groupsData.data : Array.isArray(groupsData) ? groupsData : []);
    } catch (error) {
      console.error('Failed to load data:', error);
      setNodes([]);
      setNodeGroups([]);
    } finally {
      setLoading(false);
    }
  }

  const generateCK = async (nodeId: string, nodeName: string) => {
    if (!confirm(`确定要为节点 "${nodeName}" 生成新的 Connection Key 吗？\n旧的 CK 将失效。`)) {
      return;
    }

    try {
      const result = await api.nodes.generateCK(nodeId);
      showToast('success', 'Connection Key 生成成功');
      // 这里可以显示CK或者通过其他方式处理
    } catch (error: any) {
      showToast('error', error.data?.error || '生成失败');
    }
  };

  const stats = {
    total: nodes.length,
    online: nodes.filter(n => n.status === 'online').length,
    offline: nodes.filter(n => n.status === 'offline').length,
    entry: nodes.filter(n => n.type === 'entry').length,
    exit: nodes.filter(n => n.type === 'exit').length,
  };

  const handleBatchDelete = async () => {
    if (selectedNodes.length === 0) return;
    if (!confirm(`确定要永久删除选中的 ${selectedNodes.length} 个节点吗？此操作不可逆！`)) return;
    
    try {
      await Promise.all(selectedNodes.map(id => api.nodes.delete(id)));
      setSelectedNodes([]);
      await loadData();
      showToast('success', `成功删除 ${selectedNodes.length} 个节点`);
    } catch (error: any) {
      showToast('error', error.data?.error || '批量删除失败');
    }
  };

  const toggleSelectAll = () => {
    if (selectedNodes.length === filteredNodes.length && filteredNodes.length > 0) {
      setSelectedNodes([]);
    } else {
      setSelectedNodes(filteredNodes.map(n => n.id));
    }
  };

  const toggleNodeSelection = (nodeId: string) => {
    setSelectedNodes(prev => 
      prev.includes(nodeId) 
        ? prev.filter(id => id !== nodeId)
        : [...prev, nodeId]
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-slate-400">正在加载节点数据...</p>
        </div>
      </div>
    );
  }

  return (
    <ProtectedRoute requireAdmin>
      <div className="space-y-6">
        {/* RelayX 节点管理标题 - 与截图匹配 */}
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-6">
        <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-muted rounded-lg">
                  <Server className="w-8 h-8 text-slate-100" />
                </div>
          <div>
                  <h1 className="text-3xl font-bold text-slate-100">节点管理</h1>
                  <p className="text-slate-400">
                    RelayX 网络节点配置和监控 · 共 {nodes.length} 个节点
                  </p>
                </div>
          </div>
          <div className="flex gap-3">
            {selectedNodes.length > 0 && (
                  <Button 
                    variant="destructive" 
                onClick={handleBatchDelete}
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    删除选中 ({selectedNodes.length})
                  </Button>
                )}
                <CreateNodeDialog nodeGroups={nodeGroups} onNodeCreated={loadData} />
          </div>
        </div>
          </CardContent>
        </Card>

        {/* RelayX 风格的节点统计 */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card className="bg-slate-800 border-slate-700 p-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-slate-100">{stats.total}</div>
              <div className="text-sm text-slate-400 mt-1">节点总数</div>
      </div>
          </Card>
          
          <Card className="bg-slate-800 border-slate-700 p-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-500">{stats.online}</div>
              <div className="text-sm text-slate-400 mt-1">在线节点</div>
            </div>
          </Card>
          
          <Card className="bg-slate-800 border-slate-700 p-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-red-500">{stats.offline}</div>
              <div className="text-sm text-slate-400 mt-1">离线节点</div>
            </div>
          </Card>
          
          <Card className="bg-slate-800 border-slate-700 p-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-400">{stats.entry}</div>
              <div className="text-sm text-slate-400 mt-1">入口节点</div>
            </div>
          </Card>
          
          <Card className="bg-slate-800 border-slate-700 p-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-400">{stats.exit}</div>
              <div className="text-sm text-slate-400 mt-1">出口节点</div>
            </div>
          </Card>
        </div>

        {/* 搜索和过滤 */}
        <Card>
          <CardHeader>
          <div className="flex items-center justify-between">
            <div>
                <CardTitle className="flex items-center gap-2">
                  <Server className="w-5 h-5" />
                  节点列表
                </CardTitle>
                <CardDescription>
                  系统网络节点监控和管理
                </CardDescription>
            </div>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                  <Input
                    placeholder="搜索节点名称、IP或UUID..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-64"
                  />
          </div>
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-slate-400" />
                  <div className="flex gap-1">
                    <Button
                      variant={typeFilter === 'all' ? 'admin' : 'outline'}
                      size="sm"
                      onClick={() => setTypeFilter('all')}
                    >
                      全部
                    </Button>
                    <Button
                      variant={typeFilter === 'entry' ? 'relay' : 'outline'}
                      size="sm"
                      onClick={() => setTypeFilter('entry')}
                    >
                      入口
                    </Button>
                    <Button
                      variant={typeFilter === 'exit' ? 'tunnel' : 'outline'}
                      size="sm"
                      onClick={() => setTypeFilter('exit')}
                    >
                      出口
                    </Button>
        </div>
      </div>
                <div className="flex gap-1">
                  <Button
                    variant={statusFilter === 'all' ? 'admin' : 'outline'}
                    size="sm"
            onClick={() => setStatusFilter('all')}
          >
            全部状态
                  </Button>
                  <Button
                    variant={statusFilter === 'online' ? 'default' : 'outline'}
                    size="sm"
            onClick={() => setStatusFilter('online')}
                  >
                    在线
                  </Button>
                  <Button
                    variant={statusFilter === 'offline' ? 'secondary' : 'outline'}
                    size="sm"
                    onClick={() => setStatusFilter('offline')}
                  >
                    离线
                  </Button>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {filteredNodes.length === 0 ? (
              <div className="text-center py-12">
                <Server className="w-12 h-12 mx-auto text-slate-400 mb-4" />
                <CardTitle className="mb-2">
                  {searchTerm || typeFilter !== 'all' || statusFilter !== 'all' 
                    ? '未找到匹配的节点' 
                    : '还没有节点'}
                </CardTitle>
                <CardDescription className="mb-6">
                  {searchTerm || typeFilter !== 'all' || statusFilter !== 'all'
                    ? '请尝试调整搜索条件或过滤器'
                    : '创建第一个 RelayX 网络节点'}
                </CardDescription>
                {!searchTerm && typeFilter === 'all' && statusFilter === 'all' && (
                  <CreateNodeDialog nodeGroups={nodeGroups} onNodeCreated={loadData} />
                )}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={toggleSelectAll}
                        className="p-0 h-auto"
                      >
                        {selectedNodes.length === filteredNodes.length && filteredNodes.length > 0 ? (
                          <CheckSquare className="w-4 h-4" />
                        ) : (
                          <Square className="w-4 h-4" />
                        )}
                      </Button>
                    </TableHead>
                    <TableHead>节点信息</TableHead>
                    <TableHead>类型</TableHead>
                    <TableHead>网络地址</TableHead>
                    <TableHead>UUID</TableHead>
                    <TableHead>状态</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredNodes.map((node) => (
                    <TableRow key={node.id}>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleNodeSelection(node.id)}
                          className="p-0 h-auto"
                        >
                          {selectedNodes.includes(node.id) ? (
                            <CheckSquare className="w-4 h-4" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </Button>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{node.name}</div>
                        <div className="text-sm text-slate-400">
                          {nodeGroups.find(g => g.id === node.group_id)?.name || '未分组'}
                </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={node.type === 'entry' ? 'relay' : 'tunnel'}>
                          {getNodeTypeText(node.type)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4 text-slate-400" />
                          <span className="font-mono">{node.ip}:{node.port}</span>
              </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Hash className="w-4 h-4 text-slate-400" />
                          <code className="text-xs font-mono bg-muted px-2 py-1 rounded">
                            {(node.uuid || node.id).substring(0, 8)}...
                </code>
              </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={node.status === 'online' ? 'success' : 'secondary'}>
                          {node.status === 'online' ? (
                            <div className="flex items-center gap-1">
                              <Wifi className="w-3 h-3" />
                              在线
              </div>
                          ) : (
                            <div className="flex items-center gap-1">
                              <WifiOff className="w-3 h-3" />
                              离线
        </div>
      )}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/nodes/${node.id}`}>
                              <Eye className="w-4 h-4" />
                    </Link>
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                      onClick={() => generateCK(node.id, node.name)}
                          >
                            <Key className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

    </div>
    </ProtectedRoute>
  );
}

