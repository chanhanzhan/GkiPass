/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { api } from '@/lib/api';
import { getNodeTypeText } from '@/lib/utils';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { CreateNodeDialog } from '@/components/admin/CreateNodeDialog';
import { useToast } from '@/components/ui/Toast';
import { 
  Server,
  Plus,
  Search,
  Filter
} from 'lucide-react';
import type { Node, NodeGroup } from '@/types';

export default function AdminNodesPage() {
  const [nodes, setNodes] = useState<Node[]>([]);
  const [nodeGroups, setNodeGroups] = useState<NodeGroup[]>([]);
  const [filteredNodes, setFilteredNodes] = useState<Node[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedNodes, setSelectedNodes] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'entry' | 'exit'>('all');
  const { showToast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  // 节点过滤逻辑
  useEffect(() => {
    let filtered = nodes;

    // 按类型过滤
    if (typeFilter !== 'all') {
      filtered = filtered.filter(node => node.type === typeFilter);
    }

    // 按搜索词过滤
    if (searchTerm) {
      filtered = filtered.filter(node => 
        node.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        node.ip.includes(searchTerm) ||
        node.uuid?.includes(searchTerm) ||
        node.id.includes(searchTerm)
      );
    }

    setFilteredNodes(filtered);
  }, [nodes, typeFilter, searchTerm]);

  async function loadData() {
    try {
      const [nodesData, groupsData] = await Promise.all([
        api.nodes.list(),
        api.nodeGroups.list(),
      ]);
      setNodes(Array.isArray(nodesData?.data) ? nodesData.data : Array.isArray(nodesData) ? nodesData : []);
      setNodeGroups(Array.isArray(groupsData?.data) ? groupsData.data : Array.isArray(groupsData) ? groupsData : []);
    } catch (error) {
      console.error('Failed to load data:', error);
      setNodes([]);
      setNodeGroups([]);
    } finally {
      setLoading(false);
    }
  }

  const generateCK = async (nodeId: string, nodeName: string) => {
    if (!confirm(`确定要为节点 "${nodeName}" 生成新的 Connection Key 吗？\n旧的 CK 将失效。`)) {
      return;
    }

    try {
      const result = await api.nodes.generateCK(nodeId);
      showToast('success', 'Connection Key 生成成功');
    } catch (error: any) {
      showToast('error', error.data?.error || '生成失败');
    }
  };

  const stats = {
    total: nodes.length,
    online: nodes.filter(n => n.status === 'online').length,
    offline: nodes.filter(n => n.status === 'offline').length,
    entry: nodes.filter(n => n.type === 'entry').length,
    exit: nodes.filter(n => n.type === 'exit').length,
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">正在加载节点数据...</p>
        </div>
      </div>
    );
  }

  return (
    <ProtectedRoute requireAdmin>
      <div className="space-y-6">
        {/* RelayX 标题区域 - 完全匹配截图 */}
        <div className="bg-card rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-muted rounded-lg">
                <Server className="w-6 h-6 text-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">节点管理</h1>
                <p className="text-muted-foreground">
                  RelayX 网络节点配置和监控 · 共 {nodes.length} 个节点
                </p>
              </div>
            </div>
            <div className="flex gap-3">
              <CreateNodeDialog nodeGroups={nodeGroups} onNodeCreated={loadData} />
            </div>
          </div>
        </div>

        {/* 完全按照RelayX截图的统计卡片布局 */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card className="bg-card p-6 text-center">
            <div className="text-3xl font-bold text-foreground">{stats.total}</div>
            <div className="text-sm text-muted-foreground">节点总数</div>
          </Card>
          
          <Card className="bg-card p-6 text-center">
            <div className="text-3xl font-bold text-green-400">{stats.online}</div>
            <div className="text-sm text-muted-foreground">在线节点</div>
          </Card>
          
          <Card className="bg-card p-6 text-center">
            <div className="text-3xl font-bold text-red-400">{stats.offline}</div>
            <div className="text-sm text-muted-foreground">离线节点</div>
          </Card>
          
          <Card className="bg-card p-6 text-center">
            <div className="text-3xl font-bold text-primary">{stats.entry}</div>
            <div className="text-sm text-muted-foreground">入口节点</div>
          </Card>
          
          <Card className="bg-card p-6 text-center">
            <div className="text-3xl font-bold text-primary">{stats.exit}</div>
            <div className="text-sm text-muted-foreground">出口节点</div>
          </Card>
        </div>

        {/* RelayX 风格的节点列表 */}
        <Card className="bg-card">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Server className="w-5 h-5 text-foreground" />
                <CardTitle className="text-foreground">节点列表</CardTitle>
              </div>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    placeholder="搜索节点..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-64 bg-muted border-border"
                  />
                </div>
                <div className="flex gap-1">
                  <Button
                    variant={typeFilter === 'all' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setTypeFilter('all')}
                  >
                    全部
                  </Button>
                  <Button
                    variant={typeFilter === 'entry' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setTypeFilter('entry')}
                  >
                    入口
                  </Button>
                  <Button
                    variant={typeFilter === 'exit' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setTypeFilter('exit')}
                  >
                    出口
                  </Button>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {filteredNodes.length === 0 ? (
              <div className="text-center py-12">
                <Server className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">
                  {searchTerm || typeFilter !== 'all' ? '未找到匹配的节点' : '还没有节点'}
                </h3>
                <p className="text-muted-foreground mb-6">
                  {searchTerm || typeFilter !== 'all'
                    ? '请尝试调整搜索条件'
                    : '创建第一个网络节点'}
                </p>
                {!searchTerm && typeFilter === 'all' && (
                  <CreateNodeDialog nodeGroups={nodeGroups} onNodeCreated={loadData} />
                )}
              </div>
            ) : (
              <div className="divide-y divide-border">
                {filteredNodes.map((node) => (
                  <div key={node.id} className="p-4 hover:bg-muted/50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className={`w-3 h-3 rounded-full ${
                          node.status === 'online' ? 'bg-green-400' : 'bg-red-400'
                        }`} />
                        <div>
                          <h3 className="font-medium text-foreground">{node.name}</h3>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                            <Badge variant="outline">{getNodeTypeText(node.type)}</Badge>
                            <span>{node.ip}:{node.port}</span>
                            <span className="font-mono text-xs">
                              {(node.uuid || node.id).substring(0, 8)}...
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm" asChild>
                          <Link href={`/nodes/${node.id}`}>查看</Link>
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => generateCK(node.id, node.name)}
                        >
                          生成CK
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </ProtectedRoute>
  );
}
