'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/hooks/useAuth';
import { Sidebar } from '@/components/layout/Sidebar';
import { Navbar } from '@/components/layout/Navbar';

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const { isAuthenticated, user, checkAuth, isInitialized } = useAuth();
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    console.log('🔄 Dashboard layout mounting...');
    setIsMounted(true);
    checkAuth();
  }, [checkAuth]);

  useEffect(() => {
    console.log('🔍 Auth state:', { isMounted, isInitialized, isAuthenticated });
    if (isMounted && isInitialized && !isAuthenticated) {
      console.log('🚀 Redirecting to /login...');
      router.push('/login');
    }
  }, [isMounted, isInitialized, isAuthenticated, router]);

  // Show loading state until client-side hydration is complete
  if (!isMounted || !isInitialized) {
    console.log('⏳ Loading (mounted:', isMounted, ', initialized:', isInitialized, ')');
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  // Redirect to login if not authenticated
  if (!isAuthenticated) {
    console.log('🔒 Not authenticated, showing loading before redirect...');
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在跳转到登录页...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex bg-gray-50">
      <Sidebar isAdmin={user?.is_admin} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar />
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}






