/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/Toast';
import { formatDate, formatBytes } from '@/lib/utils';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { APIKeyManager } from '@/components/profile/APIKeyManager';
import { NotificationSettings } from '@/components/profile/NotificationSettings';
import { 
  User, 
  CreditCard, 
  Shield, 
  Wallet,
  Crown,
  Calendar,
  Hash,
  Mail,
  UserCheck,
  Settings,
  Key,
  Bell,
  Lock
} from 'lucide-react';

export default function ProfilePage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [balance, setBalance] = useState(0);
  const [subscription, setSubscription] = useState<any>(null);
  const [passwordForm, setPasswordForm] = useState({
    current_password: '',
    new_password: '',
    confirm_password: '',
  });
  const { showToast } = useToast();

  useEffect(() => {
    loadUserData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadUserData() {
    try {
      const [walletData, subData] = await Promise.all([
        api.wallet.getBalance().catch(() => ({ balance: 0 })),
        api.plans.getMySubscription().catch(() => null),
      ]);
      setBalance(walletData.balance || 0);
      setSubscription(subData);
    } catch (error) {
      console.error('Failed to load user data:', error);
    }
  }

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();

    if (passwordForm.new_password !== passwordForm.confirm_password) {
      showToast('error', '两次输入的新密码不一致');
      return;
    }

    if (passwordForm.new_password.length < 8) {
      showToast('error', '密码长度至少为 8 位');
      return;
    }

    setLoading(true);
    try {
      await api.auth.changePassword({
        current_password: passwordForm.current_password,
        new_password: passwordForm.new_password,
      });
      showToast('success', '密码修改成功');
      setPasswordForm({
        current_password: '',
        new_password: '',
        confirm_password: '',
      });
    } catch (err) {
      const error = err as { data?: { error?: string } };
      showToast('error', error.data?.error || '密码修改失败');
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-relay-600 mx-auto"></div>
          <p className="mt-4 text-muted-foreground">正在加载用户信息...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* RelayX 个人中心标题 */}
      <Card className="border-0 bg-slate-700 text-white">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-2xl font-bold">
              {user.username?.[0]?.toUpperCase() || 'U'}
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-1">个人中心</h1>
              <div className="flex items-center gap-3">
                <span className="text-white/90">欢迎回来，{user.username}</span>
                <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                  {user.is_admin ? '管理员' : '用户'}
                </Badge>
              </div>
            </div>
            <div className="text-6xl opacity-50">
              {user.is_admin ? <Crown className="w-16 h-16" /> : <User className="w-16 h-16" />}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 账户概览卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* 钱包余额 */}
        <Card className="border-0 bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-white/80 text-sm">钱包余额</p>
              <Wallet className="w-8 h-8 text-white/60" />
            </div>
            <p className="text-4xl font-bold mb-3">¥{balance.toFixed(2)}</p>
            <Button variant="secondary" size="sm" asChild>
              <a href="/wallet">查看详情</a>
            </Button>
          </CardContent>
        </Card>

        {/* 套餐状态 */}
        <Card className="border-0 bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-white/80 text-sm">当前套餐</p>
              <CreditCard className="w-8 h-8 text-white/60" />
            </div>
            <p className="text-2xl font-bold mb-1">{subscription?.plan?.name || '无套餐'}</p>
            <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
              {subscription?.status === 'active' ? '正常使用' : '未订阅'}
            </Badge>
          </CardContent>
        </Card>

        {/* 账号类型 */}
        <Card className="border-0 bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-white/80 text-sm">账号类型</p>
              {user.is_admin ? <Crown className="w-8 h-8 text-white/60" /> : <User className="w-8 h-8 text-white/60" />}
            </div>
            <p className="text-2xl font-bold mb-1">{user.is_admin ? '管理员' : '普通用户'}</p>
            <p className="text-sm text-white/80">
              {user.id && `ID: ${user.id.substring(0, 8)}...`}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* 详细设置面板 */}
      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="profile" className="flex items-center gap-2">
            <User className="w-4 h-4" />
            个人信息
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Lock className="w-4 h-4" />
            安全设置
          </TabsTrigger>
          <TabsTrigger value="api" className="flex items-center gap-2">
            <Key className="w-4 h-4" />
            API密钥
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="w-4 h-4" />
            通知设置
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          {/* 基本信息 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                基本信息
              </CardTitle>
              <CardDescription>
                查看和管理您的账户基本信息
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center space-x-6">
                <div className="w-24 h-24 rounded-full bg-slate-600 flex items-center justify-center text-white text-4xl font-bold shadow-sm">
                  {user.username?.[0]?.toUpperCase() || 'U'}
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold">{user.username}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{user.email || '未设置邮箱'}</span>
                  </div>
                  <div className="mt-3">
                    <Badge variant={user.is_admin ? "destructive" : "relay"}>
                      {user.is_admin ? (
                        <div className="flex items-center gap-1">
                          <Crown className="w-3 h-3" />
                          管理员
                        </div>
                      ) : (
                        <div className="flex items-center gap-1">
                          <UserCheck className="w-3 h-3" />
                          普通用户
                        </div>
                      )}
                    </Badge>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-6 border-t">
                <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                  <Hash className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">用户 ID</p>
                    <p className="font-mono text-sm">{user.id || '-'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                  <Calendar className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">注册时间</p>
                    <p className="text-sm">{user.created_at ? formatDate(user.created_at) : '-'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                  <Shield className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">角色权限</p>
                    <p className="text-sm">{user.role || '普通用户'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                  <UserCheck className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">账户状态</p>
                    <Badge variant="success">正常</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 套餐详情 */}
          {subscription && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="w-5 h-5" />
                  订阅套餐
                </CardTitle>
                <CardDescription>
                  当前套餐使用情况和配额信息
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <p className="text-sm text-blue-600 mb-1">隧道规则</p>
                    <p className="text-2xl font-bold text-blue-900">
                      {subscription.used_rules || 0} / {subscription.plan?.max_rules || 0}
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                    <p className="text-sm text-purple-600 mb-1">流量使用</p>
                    <p className="text-lg font-bold text-purple-900">
                      {formatBytes(subscription.used_traffic || 0)}
                    </p>
                  </div>
                  <div className="p-4 bg-pink-50 rounded-lg border border-pink-200">
                    <p className="text-sm text-pink-600 mb-1">最大带宽</p>
                    <p className="text-lg font-bold text-pink-900">
                      {formatBytes(subscription.plan?.max_bandwidth || 0)}/s
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                    <p className="text-sm text-green-600 mb-1">到期时间</p>
                    <p className="text-sm font-semibold text-green-900">
                      {subscription.end_date ? formatDate(subscription.end_date, false) : '-'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          {/* 修改密码 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="w-5 h-5" />
                修改密码
              </CardTitle>
              <CardDescription>
                更新您的登录密码以保护账户安全
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleChangePassword} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="current_password">当前密码</Label>
                  <Input
                    id="current_password"
                    type="password"
                    required
                    value={passwordForm.current_password}
                    onChange={(e) =>
                      setPasswordForm({ ...passwordForm, current_password: e.target.value })
                    }
                    placeholder="请输入当前密码"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="new_password">新密码</Label>
                  <Input
                    id="new_password"
                    type="password"
                    required
                    value={passwordForm.new_password}
                    onChange={(e) =>
                      setPasswordForm({ ...passwordForm, new_password: e.target.value })
                    }
                    placeholder="至少 8 位字符"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirm_password">确认新密码</Label>
                  <Input
                    id="confirm_password"
                    type="password"
                    required
                    value={passwordForm.confirm_password}
                    onChange={(e) =>
                      setPasswordForm({ ...passwordForm, confirm_password: e.target.value })
                    }
                    placeholder="再次输入新密码"
                  />
                </div>

                <div className="flex justify-end pt-4">
                  <Button type="submit" disabled={loading} variant="relay">
                    {loading ? '修改中...' : '修改密码'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* 安全提示 */}
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-blue-500 rounded-lg text-white">
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-blue-900 mb-2">安全建议</h3>
                  <div className="text-sm text-blue-800 space-y-2">
                    <p>• 定期更换密码可以提高账号安全性</p>
                    <p>• 请使用包含字母、数字和特殊字符的强密码</p>
                    <p>• 不要与他人分享您的密码和API密钥</p>
                    <p>• 如发现异常登录行为，请立即修改密码</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="api">
          <APIKeyManager />
        </TabsContent>

        <TabsContent value="notifications">
          <NotificationSettings />
        </TabsContent>
      </Tabs>
    </div>
  );
}

