/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useState, useEffect } from 'react';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { api } from '@/lib/api';
import { useToast } from '@/components/ui/Toast';
import { PaymentDialog } from '@/components/payment/PaymentDialog';

export default function PlansPage() {
  const { showToast } = useToast();
  const [plans, setPlans] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [showPayment, setShowPayment] = useState(false);

  useEffect(() => {
    loadPlans();
  }, []);

  async function loadPlans() {
    try {
      const data = await api.plans.list();
      setPlans(data.plans || data.data || []);
    } catch (error) {
      console.error('Failed to load plans:', error);
      showToast('error', '加载套餐失败');
    } finally {
      setLoading(false);
    }
  }

  const handlePurchase = (plan: any) => {
    setSelectedPlan(plan);
    setShowPayment(true);
  };

  const getPlanIcon = (type: string) => {
    const icons: Record<string, string> = {
      basic: '🌱',
      standard: '🚀',
      premium: '👑',
      pro: '💎',
    };
    return icons[type] || '📦';
  };

  const getPlanGradient = (index: number) => {
    const gradients = [
      'from-blue-500 to-cyan-500',
      'from-purple-500 to-pink-500',
      'from-orange-500 to-red-500',
      'from-green-500 to-emerald-500',
    ];
    return gradients[index % gradients.length];
  };

  if (loading) {
    return (
      <ProtectedRoute>
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">正在加载...</p>
          </div>
        </div>
      </ProtectedRoute>
    );
  }

  return (
    <ProtectedRoute>
      <div className="space-y-6">
        {/* 页面标题 */}
        <div className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-2xl p-6 text-white shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-black mb-2">套餐购买</h1>
              <p className="text-purple-100">选择适合您的套餐，享受更多服务</p>
            </div>
            <div className="text-6xl">🎁</div>
          </div>
        </div>

        {/* 套餐列表 */}
        {plans.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-xl p-12 text-center">
            <div className="text-6xl mb-4">📦</div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">暂无可用套餐</h3>
            <p className="text-gray-500">请稍后再来查看</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {plans.map((plan, index) => (
              <div
                key={plan.id}
                className="bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2"
              >
                {/* 套餐头部 */}
                <div className={`bg-gradient-to-r ${getPlanGradient(index)} p-6 text-white`}>
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-5xl">{getPlanIcon(plan.type)}</span>
                    <div>
                      <h3 className="text-2xl font-black">{plan.name}</h3>
                      <p className="text-sm opacity-90">{plan.description || '优质套餐'}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-baseline gap-2">
                    <span className="text-5xl font-black">¥{plan.price}</span>
                    <span className="text-lg opacity-90">/{plan.duration}天</span>
                  </div>
                </div>

                {/* 套餐特性 */}
                <div className="p-6 space-y-4">
                  <div className="space-y-3">
                    {plan.traffic > 0 && (
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">📊</span>
                        <div>
                          <div className="font-bold text-gray-900">流量额度</div>
                          <div className="text-sm text-gray-600">
                            {plan.traffic >= 1024 ? `${(plan.traffic / 1024).toFixed(0)} TB` : `${plan.traffic} GB`}
                          </div>
                        </div>
                      </div>
                    )}

                    {plan.max_tunnels > 0 && (
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">🔌</span>
                        <div>
                          <div className="font-bold text-gray-900">隧道数量</div>
                          <div className="text-sm text-gray-600">{plan.max_tunnels} 个</div>
                        </div>
                      </div>
                    )}

                    {plan.max_bandwidth > 0 && (
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">⚡</span>
                        <div>
                          <div className="font-bold text-gray-900">带宽限制</div>
                          <div className="text-sm text-gray-600">{plan.max_bandwidth} Mbps</div>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center gap-3">
                      <span className="text-2xl">📅</span>
                      <div>
                        <div className="font-bold text-gray-900">有效期</div>
                        <div className="text-sm text-gray-600">{plan.duration} 天</div>
                      </div>
                    </div>

                    {plan.features && (
                      <div className="mt-4 pt-4 border-t border-gray-200">
                        <div className="font-bold text-gray-900 mb-2">套餐特权</div>
                        <ul className="space-y-1 text-sm text-gray-600">
                          {plan.features.split(',').map((feature: string, i: number) => (
                            <li key={i} className="flex items-center gap-2">
                              <span className="text-green-500">✓</span>
                              <span>{feature.trim()}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>

                  {/* 购买按钮 */}
                  <button
                    onClick={() => handlePurchase(plan)}
                    className={`w-full py-3 bg-gradient-to-r ${getPlanGradient(index)} hover:opacity-90 text-white rounded-xl font-bold transition-all shadow-lg hover:shadow-xl`}
                  >
                    立即购买
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 温馨提示 */}
        <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-6">
          <h4 className="text-lg font-bold text-gray-900 mb-3">💡 购买须知</h4>
          <ul className="space-y-2 text-sm text-gray-700">
            <li>• 套餐购买后立即生效，有效期从购买时开始计算</li>
            <li>• 流量不会过期，用完可随时续费</li>
            <li>• 多个套餐可叠加使用，流量和隧道数会累计</li>
            <li>• 如有问题请联系客服获取帮助</li>
          </ul>
        </div>
      </div>

      {/* 支付对话框 */}
      {selectedPlan && (
        <PaymentDialog
          open={showPayment}
          onClose={() => {
            setShowPayment(false);
            setSelectedPlan(null);
          }}
          amount={selectedPlan.price}
          type="purchase"
          onSuccess={() => {
            showToast('success', '购买成功！');
            // 可以刷新订阅信息或跳转到订阅页面
          }}
        />
      )}
    </ProtectedRoute>
  );
}
