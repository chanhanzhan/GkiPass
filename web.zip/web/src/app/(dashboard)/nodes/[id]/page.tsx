/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable react-hooks/exhaustive-deps */
'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { api } from '@/lib/api';
import { useNodeStatus } from '@/hooks/useWebSocket';
import { formatDate, getNodeTypeText, formatBytes } from '@/lib/utils';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { NodeMetricsCard } from '@/components/nodes/NodeMetricsCard';
import { 
  ArrowLeft, 
  Server, 
  RefreshCw,
  Info,
  MapPin,
  Hash,
  Calendar,
  Globe,
  Shield,
  Activity
} from 'lucide-react';
import type { Node } from '@/types';

export default function NodeDetailPage() {
  const params = useParams();
  const nodeId = params.id as string;
  
  const [node, setNode] = useState<Node | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  
  // 使用 WebSocket 实时获取节点状态
  const { status: wsStatus, isConnected } = useNodeStatus(nodeId);
  const [status, setStatus] = useState<any>(null);

  useEffect(() => {
    loadNodeData();
  }, []);

  // 当 WebSocket 状态更新时，更新本地状态
  useEffect(() => {
    if (wsStatus) {
      setStatus(wsStatus);
    }
  }, [wsStatus]);

  async function loadNodeData() {
    try {
      const nodeData = await api.nodes.get(nodeId);
      setNode(nodeData);
      
      // 首次加载时也获取状态
      try {
        const statusData = await api.nodes.getStatus(nodeId);
        setStatus(statusData);
      } catch (err) {
        console.log('Status API not available, using WebSocket only');
      }
    } catch (error) {
      console.error('Failed to load node data:', error);
    } finally {
      setLoading(false);
    }
  }

  async function loadNodeStatus() {
    setRefreshing(true);
    try {
      const statusData = await api.nodes.getStatus(nodeId);
      setStatus(statusData);
    } catch (error) {
      console.error('Failed to load node status:', error);
    } finally {
      setRefreshing(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-relay-600 mx-auto"></div>
          <p className="mt-4 text-muted-foreground">正在加载节点详情...</p>
        </div>
      </div>
    );
  }

  if (!node) {
    return (
      <div className="flex items-center justify-center h-full">
        <Card className="max-w-md text-center">
          <CardContent className="p-12">
            <div className="text-6xl mb-4">❌</div>
            <CardTitle className="mb-2">节点不存在</CardTitle>
            <CardDescription className="mb-6">
              请检查节点ID是否正确
            </CardDescription>
            <Button asChild variant="relay">
              <Link href="/nodes">
                <ArrowLeft className="w-4 h-4 mr-2" />
                返回列表
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* RelayX 节点详情标题 */}
      <Card className="border-0 bg-gradient-to-r from-relay-500 to-tunnel-500 text-white">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/20 rounded-lg">
                <Server className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-3xl font-bold">{node.name}</h1>
                <div className="flex items-center gap-3 mt-2">
                  <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                    {getNodeTypeText(node.type)}
                  </Badge>
                  <Badge variant={node.status === 'online' ? 'success' : 'secondary'}>
                    {node.status === 'online' ? '在线' : '离线'}
                  </Badge>
                  <span className="text-white/90 text-sm">
                    {node.ip}:{node.port}
                  </span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button 
                variant="secondary" 
                size="sm"
                onClick={loadNodeStatus}
                disabled={refreshing}
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                刷新状态
              </Button>
              <Button variant="secondary" asChild>
                <Link href="/nodes">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  返回列表
                </Link>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 实时状态监控 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <NodeMetricsCard 
            status={status} 
            isConnected={isConnected}
          />
        </div>
        
        {/* 快速统计 */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Activity className="w-5 h-5" />
                快速统计
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">运行时长</span>
                <span className="font-medium">
                  {status?.uptime ? `${Math.floor(status.uptime / 3600)}h` : '--'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">平均负载</span>
                <span className="font-medium">
                  {status?.load_average ? status.load_average.toFixed(2) : '--'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">网络延迟</span>
                <span className="font-medium text-green-600">
                  {status?.latency ? `${status.latency}ms` : '< 50ms'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">数据传输</span>
                <span className="font-medium">
                  {status?.bytes_sent ? formatBytes(status.bytes_sent) : '--'}
                </span>
              </div>
            </CardContent>
          </Card>
          
          {/* 安全状态 */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Shield className="w-5 h-5" />
                安全状态
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                <span className="text-sm">SSL/TLS 加密</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                <span className="text-sm">防火墙保护</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                <span className="text-sm">访问控制</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* 节点详细信息 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 基本信息 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Info className="w-5 h-5" />
              基本信息
            </CardTitle>
            <CardDescription>
              节点的基础配置和标识信息
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                <Server className="w-5 h-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">节点名称</p>
                  <p className="font-medium">{node.name}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                <Globe className="w-5 h-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">节点类型</p>
                  <Badge variant={node.type === 'entry' ? 'relay' : 'tunnel'}>
                    {getNodeTypeText(node.type)}
                  </Badge>
                </div>
              </div>
              
              <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                <MapPin className="w-5 h-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">网络地址</p>
                  <p className="font-mono font-medium">{node.ip}:{node.port}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                <Calendar className="w-5 h-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">创建时间</p>
                  <p className="font-medium">{formatDate(node.created_at)}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 技术信息 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Hash className="w-5 h-5" />
              技术信息
            </CardTitle>
            <CardDescription>
              节点的技术标识和配置参数
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground mb-2">节点 UUID</p>
              <code className="text-sm bg-muted px-3 py-2 rounded-lg block font-mono break-all">
                {node.uuid || node.id}
              </code>
            </div>
            
            <div>
              <p className="text-sm text-muted-foreground mb-2">节点 ID</p>
              <code className="text-sm bg-muted px-3 py-2 rounded-lg block font-mono">
                {node.id}
              </code>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">协议版本</p>
                <p className="font-medium mt-1">v2.1.0</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">加密方式</p>
                <p className="font-medium mt-1">AES-256</p>
              </div>
            </div>
            
            <div className="pt-4 border-t">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span>节点正常运行，所有系统检查通过</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

