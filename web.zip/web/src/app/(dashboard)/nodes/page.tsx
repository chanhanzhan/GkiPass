'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import { useToast } from '@/components/ui/Toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { NodeStatusCard } from '@/components/nodes/NodeStatusCard';
import { NodeStatsOverview } from '@/components/nodes/NodeStatsOverview';
import { 
  Server, 
  Search, 
  Filter,
  RefreshCw,
  CreditCard,
  Wallet,
  Activity
} from 'lucide-react';
import type { Node } from '@/types';

export default function NodesPage() {
  const router = useRouter();
  const [nodes, setNodes] = useState<Node[]>([]);
  const [filteredNodes, setFilteredNodes] = useState<Node[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasSubscription, setHasSubscription] = useState(true);
  const [planName, setPlanName] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<'all' | 'entry' | 'exit'>('all');
  const [refreshing, setRefreshing] = useState(false);
  const { showToast } = useToast();

  useEffect(() => {
    loadNodes();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // 过滤节点
  useEffect(() => {
    let filtered = nodes;
    
    // 按类型过滤
    if (selectedType !== 'all') {
      filtered = filtered.filter(node => node.type === selectedType);
    }
    
    // 按搜索词过滤
    if (searchTerm) {
      filtered = filtered.filter(node => 
        node.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        node.ip.includes(searchTerm) ||
        node.id.includes(searchTerm)
      );
    }
    
    setFilteredNodes(filtered);
  }, [nodes, searchTerm, selectedType]);

  async function loadNodes() {
    setRefreshing(true);
    try {
      const data = await api.nodes.available();
      
      if (data.has_subscription === false) {
        setHasSubscription(false);
        setNodes([]);
        showToast('warning', data.message || '请先购买套餐');
      } else {
        setHasSubscription(true);
        setPlanName(data.plan_name || '');
        const nodeList = data.nodes || [];
        setNodes(Array.isArray(nodeList) ? nodeList : []);
      }
    } catch (error) {
      console.error('Failed to load nodes:', error);
      showToast('error', '加载节点列表失败');
      setNodes([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-relay-600 mx-auto"></div>
          <p className="mt-4 text-muted-foreground">正在加载节点信息...</p>
        </div>
      </div>
    );
  }

  // 无订阅引导
  if (!hasSubscription) {
    return (
      <div className="flex items-center justify-center h-full">
        <Card className="max-w-md mx-auto text-center">
          <CardContent className="p-12">
            <div className="text-8xl mb-6">🔐</div>
            <CardTitle className="text-3xl mb-4">需要订阅套餐</CardTitle>
            <CardDescription className="mb-6 text-lg">
              订阅套餐后，您可以查看和使用套餐内的节点
            </CardDescription>
            <div className="flex gap-4 justify-center">
              <Button 
                onClick={() => router.push('/plans')}
                variant="relay"
                size="lg"
              >
                <CreditCard className="w-4 h-4 mr-2" />
                查看套餐
              </Button>
              <Button 
                onClick={() => router.push('/wallet')}
                variant="outline"
                size="lg"
              >
                <Wallet className="w-4 h-4 mr-2" />
                充值钱包
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* RelayX 节点状态页面标题 */}
      <Card className="border-0 bg-slate-700 text-white">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/20 rounded-lg">
                <Server className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-3xl font-bold">节点状态</h1>
                <p className="text-white/90">
                  {planName} 套餐 • 共 {nodes.length} 个节点可用
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                实时监控
              </Badge>
              <Button 
                variant="secondary" 
                size="sm"
                onClick={loadNodes}
                disabled={refreshing}
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                刷新
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 节点统计概览 */}
      <NodeStatsOverview nodes={nodes} />

      {/* 搜索和过滤 */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5" />
                节点列表
              </CardTitle>
              <CardDescription>
                管理和监控您的所有节点状态
              </CardDescription>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  placeholder="搜索节点名称、IP或ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-muted-foreground" />
                <div className="flex gap-1">
                  <Button
                    variant={selectedType === 'all' ? 'relay' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedType('all')}
                  >
                    全部
                  </Button>
                  <Button
                    variant={selectedType === 'entry' ? 'relay' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedType('entry')}
                  >
                    入口
                  </Button>
                  <Button
                    variant={selectedType === 'exit' ? 'tunnel' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedType('exit')}
                  >
                    出口
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {filteredNodes.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🖥️</div>
              <CardTitle className="mb-2">
                {searchTerm || selectedType !== 'all' ? '未找到匹配的节点' : '套餐内暂无节点'}
              </CardTitle>
              <CardDescription>
                {searchTerm || selectedType !== 'all' 
                  ? '请尝试调整搜索条件或过滤器' 
                  : '请联系管理员或升级套餐以获取更多节点'
                }
              </CardDescription>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredNodes.map((node) => (
                <NodeStatusCard key={node.id} node={node} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
