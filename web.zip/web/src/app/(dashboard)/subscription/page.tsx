'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { formatBytes, formatDate, calculatePercentage } from '@/lib/utils';
import type { Subscription } from '@/types';

export default function SubscriptionPage() {
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSubscription();
  }, []);

  async function loadSubscription() {
    try {
      const data = await api.plans.getMySubscription();
      setSubscription(data);
    } catch (error) {
      console.error('Failed to load subscription:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  if (!subscription) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">我的订阅</h1>
          <p className="mt-1 text-sm text-gray-500">
            管理您的订阅套餐
          </p>
        </div>

        <div className="bg-white rounded-lg shadow p-12 text-center">
          <div className="text-6xl mb-4">💳</div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            还没有订阅
          </h3>
          <p className="text-gray-500">
            请联系管理员分配套餐
          </p>
        </div>
      </div>
    );
  }

  const plan = subscription.plan;

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">我的订阅</h1>
        <p className="mt-1 text-sm text-gray-500">
          管理您的订阅套餐和配额使用情况
        </p>
      </div>

      {/* 套餐信息 */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">套餐信息</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <p className="text-sm text-gray-500">套餐名称</p>
            <p className="text-lg font-medium text-gray-900 mt-1">{plan.name}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">套餐状态</p>
            <p className="text-lg font-medium text-gray-900 mt-1">
              <span
                className={`px-3 py-1 text-sm font-medium rounded ${
                  subscription.status === 'active'
                    ? 'bg-green-100 text-green-800'
                    : 'bg-red-100 text-red-800'
                }`}
              >
                {subscription.status === 'active' ? '正常' : '已过期'}
              </span>
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-500">计费周期</p>
            <p className="text-lg font-medium text-gray-900 mt-1">
              {plan.billing_cycle === 'monthly'
                ? '月付'
                : plan.billing_cycle === 'yearly'
                ? '年付'
                : '永久'}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-500">到期时间</p>
            <p className="text-lg font-medium text-gray-900 mt-1">
              {formatDate(subscription.end_date)}
            </p>
          </div>
          {plan.description && (
            <div className="md:col-span-2">
              <p className="text-sm text-gray-500">套餐描述</p>
              <p className="text-gray-900 mt-1">{plan.description}</p>
            </div>
          )}
        </div>
      </div>

      {/* 配额使用情况 */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">配额使用情况</h2>
        <div className="space-y-6">
          <QuotaItem
            label="隧道规则"
            used={subscription.used_rules}
            max={plan.max_rules}
            icon="🔗"
          />
          <QuotaItem
            label="流量使用"
            used={subscription.used_traffic}
            max={plan.max_traffic}
            formatter={formatBytes}
            icon="📊"
          />
          <QuotaItem
            label="带宽"
            used={subscription.used_bandwidth}
            max={plan.max_bandwidth}
            formatter={formatBytes}
            unit="/s"
            icon="⚡"
          />
          <QuotaItem
            label="连接数"
            used={subscription.used_connections}
            max={plan.max_connections}
            icon="🔌"
          />
        </div>
      </div>
    </div>
  );
}

function QuotaItem({
  label,
  used,
  max,
  formatter = (v: number) => v.toString(),
  unit = '',
  icon,
}: {
  label: string;
  used: number;
  max: number;
  formatter?: (value: number) => string;
  unit?: string;
  icon: string;
}) {
  const percentage = calculatePercentage(used, max);

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center space-x-2">
          <span className="text-xl">{icon}</span>
          <span className="text-sm font-medium text-gray-700">{label}</span>
        </div>
        <span className="text-sm text-gray-900">
          {formatter(used)}
          {unit} / {formatter(max)}
          {unit}
        </span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div
          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
          style={{ width: `${percentage}%` }}
        />
      </div>
      <p className="text-xs text-gray-500 mt-1">{percentage.toFixed(1)}% 已使用</p>
    </div>
  );
}






