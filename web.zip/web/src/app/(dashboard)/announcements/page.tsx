'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { formatDate } from '@/lib/utils';
import { useToast } from '@/components/ui/Toast';

interface Announcement {
  id: string;
  title: string;
  content: string;
  type: 'notice' | 'maintenance' | 'update' | 'warning';
  priority: 'low' | 'normal' | 'high';
  start_time: string;
  end_time: string;
  created_at: string;
}

export default function AnnouncementsPage() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const { showToast } = useToast();

  useEffect(() => {
    loadAnnouncements();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadAnnouncements() {
    try {
      const data = await api.announcements.list();
      // 确保data是数组
      setAnnouncements(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Failed to load announcements:', error);
      showToast('error', '加载公告失败');
      setAnnouncements([]);
    } finally {
      setLoading(false);
    }
  }

  const getTypeInfo = (type: string) => {
    const info: Record<string, { icon: string; color: string; bg: string; text: string }> = {
      notice: { icon: '📢', color: 'from-blue-500 to-blue-600', bg: 'bg-blue-50', text: '通知' },
      maintenance: { icon: '🔧', color: 'from-orange-500 to-orange-600', bg: 'bg-orange-50', text: '维护' },
      update: { icon: '🚀', color: 'from-green-500 to-green-600', bg: 'bg-green-50', text: '更新' },
      warning: { icon: '⚠️', color: 'from-red-500 to-red-600', bg: 'bg-red-50', text: '警告' },
    };
    return info[type] || info.notice;
  };

  const getPriorityBadge = (priority: string) => {
    if (priority === 'high') {
      return <span className="px-2 py-1 bg-red-100 text-red-700 text-xs font-semibold rounded-full">重要</span>;
    }
    return null;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* 页面标题 */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">系统公告</h1>
        <p className="mt-1 text-sm text-gray-500">
          查看系统最新公告和通知
        </p>
      </div>

      {/* 公告列表 */}
      {announcements.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-lg p-16 text-center">
          <div className="text-6xl mb-4">📢</div>
          <p className="text-gray-500 text-lg">暂无公告</p>
        </div>
      ) : (
        <div className="space-y-6">
          {announcements.map((announcement) => {
            const typeInfo = getTypeInfo(announcement.type);
            return (
              <div
                key={announcement.id}
                className="bg-white rounded-2xl shadow-lg border-2 border-gray-100 overflow-hidden hover:shadow-xl transition-all"
              >
                {/* 顶部彩色条带 */}
                <div className={`h-2 bg-gradient-to-r ${typeInfo.color}`}></div>

                <div className="p-6">
                  {/* 头部 */}
                  <div className="flex items-start gap-4 mb-4">
                    <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${typeInfo.color} flex items-center justify-center text-3xl shadow-lg`}>
                      {typeInfo.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h2 className="text-2xl font-bold text-gray-900">
                          {announcement.title}
                        </h2>
                        <span className={`px-3 py-1 ${typeInfo.bg} text-${typeInfo.color.split('-')[1]}-700 text-xs font-semibold rounded-full`}>
                          {typeInfo.text}
                        </span>
                        {getPriorityBadge(announcement.priority)}
                      </div>
                      <p className="text-sm text-gray-500">
                        发布时间：{formatDate(announcement.created_at)}
                      </p>
                    </div>
                  </div>

                  {/* 内容 */}
                  <div className="prose prose-sm max-w-none">
                    <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                      {announcement.content}
                    </p>
                  </div>

                  {/* 有效期 */}
                  <div className="mt-4 pt-4 border-t border-gray-100">
                    <p className="text-xs text-gray-400">
                      有效期：{formatDate(announcement.start_time)} 至 {formatDate(announcement.end_time)}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
