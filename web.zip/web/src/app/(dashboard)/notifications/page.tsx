'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { formatDate } from '@/lib/utils';
import { useToast } from '@/components/ui/Toast';

interface Notification {
  id: string;
  type: 'system' | 'subscription' | 'traffic' | 'security';
  title: string;
  content: string;
  link?: string;
  is_read: boolean;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  created_at: string;
}

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const { showToast } = useToast();

  useEffect(() => {
    loadNotifications();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadNotifications() {
    try {
      const data = await api.notifications.list();
      const notifications = data.data || data || [];
      setNotifications(Array.isArray(notifications) ? notifications : []);
    } catch (error) {
      console.error('Failed to load notifications:', error);
      showToast('error', '加载通知失败');
      setNotifications([]);
    } finally {
      setLoading(false);
    }
  }

  const handleMarkAsRead = async (id: string) => {
    try {
      await api.notifications.markAsRead(id);
      setNotifications(notifications.map(n => 
        n.id === id ? { ...n, is_read: true } : n
      ));
      showToast('success', '已标记为已读');
    } catch (err) {
      console.error('Failed to mark as read:', err);
      showToast('error', '操作失败');
    }
  };

  const handleMarkAllAsRead = async () => {
    try {
      await api.notifications.markAllAsRead();
      setNotifications(notifications.map(n => ({ ...n, is_read: true })));
      showToast('success', '已全部标记为已读');
    } catch (err) {
      console.error('Failed to mark all as read:', err);
      showToast('error', '操作失败');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('确定要删除这条通知吗？')) return;

    try {
      await api.notifications.delete(id);
      setNotifications(notifications.filter(n => n.id !== id));
      showToast('success', '通知已删除');
    } catch (err) {
      console.error('Failed to delete notification:', err);
      showToast('error', '删除失败');
    }
  };

  const getTypeIcon = (type: string) => {
    const icons: Record<string, string> = {
      system: '🔔',
      subscription: '📦',
      traffic: '📊',
      security: '🔒',
    };
    return icons[type] || '📬';
  };

  const getTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      system: 'from-blue-500 to-blue-600',
      subscription: 'from-green-500 to-green-600',
      traffic: 'from-orange-500 to-orange-600',
      security: 'from-red-500 to-red-600',
    };
    return colors[type] || 'from-gray-500 to-gray-600';
  };

  const getPriorityBadge = (priority: string) => {
    if (priority === 'urgent') return <span className="px-2 py-1 bg-red-100 text-red-700 text-xs font-semibold rounded">紧急</span>;
    if (priority === 'high') return <span className="px-2 py-1 bg-orange-100 text-orange-700 text-xs font-semibold rounded">重要</span>;
    return null;
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">通知中心</h1>
          <p className="mt-1 text-sm text-gray-500">
            {unreadCount > 0 ? `您有 ${unreadCount} 条未读通知` : '没有未读通知'}
          </p>
        </div>
        {unreadCount > 0 && (
          <button
            onClick={handleMarkAllAsRead}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-sm font-medium"
          >
            全部标记为已读
          </button>
        )}
      </div>

      {/* 通知列表 */}
      <div className="space-y-4">
        {notifications.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg p-16 text-center">
            <div className="text-6xl mb-4">📭</div>
            <p className="text-gray-500 text-lg">暂无通知</p>
          </div>
        ) : (
          notifications.map((notification) => (
            <div
              key={notification.id}
              className={`bg-white rounded-xl shadow-md border-2 transition-all hover:shadow-lg ${
                notification.is_read ? 'border-gray-100' : 'border-blue-200 bg-blue-50/30'
              }`}
            >
              <div className="p-6">
                <div className="flex items-start gap-4">
                  {/* 图标 */}
                  <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${getTypeColor(notification.type)} flex items-center justify-center text-2xl shadow-lg`}>
                    {getTypeIcon(notification.type)}
                  </div>

                  {/* 内容 */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className={`text-lg font-semibold ${!notification.is_read ? 'text-gray-900' : 'text-gray-700'}`}>
                            {notification.title}
                          </h3>
                          {getPriorityBadge(notification.priority)}
                          {!notification.is_read && (
                            <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
                          )}
                        </div>
                        <p className="text-gray-600 text-sm leading-relaxed">
                          {notification.content}
                        </p>
                        <p className="text-xs text-gray-400 mt-2">
                          {formatDate(notification.created_at)}
                        </p>
                      </div>

                      {/* 操作按钮 */}
                      <div className="flex flex-col gap-2">
                        {!notification.is_read && (
                          <button
                            onClick={() => handleMarkAsRead(notification.id)}
                            className="px-3 py-1 bg-blue-100 hover:bg-blue-200 text-blue-700 text-xs rounded-md transition-colors font-medium"
                          >
                            标记已读
                          </button>
                        )}
                        <button
                          onClick={() => handleDelete(notification.id)}
                          className="px-3 py-1 bg-red-100 hover:bg-red-200 text-red-700 text-xs rounded-md transition-colors font-medium"
                        >
                          删除
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
