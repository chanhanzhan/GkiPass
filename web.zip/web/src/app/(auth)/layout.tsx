import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: '登录 - GKI Pass',
  description: 'GKI Pass 登录页面',
};

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}


























