'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/hooks/useAuth';
import { ApiClientError, api } from '@/lib/api';
import { ImageCaptcha } from '@/components/ui/Captcha';

export default function RegisterPage() {
  const router = useRouter();
  const { register, isLoading } = useAuth();
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [captchaCode, setCaptchaCode] = useState('');
  const [captchaId, setCaptchaId] = useState('');
  const [showCaptcha, setShowCaptcha] = useState(false);
  const [error, setError] = useState('');

  // 检查是否需要验证码
  useEffect(() => {
    const checkCaptcha = async () => {
      try {
        const config = await api.captcha.getConfig();
        setShowCaptcha(config.enabled && config.enable_register);
      } catch (err) {
        console.error('Failed to get captcha config:', err);
      }
    };
    checkCaptcha();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // 验证密码
    if (formData.password !== formData.confirmPassword) {
      setError('两次输入的密码不一致');
      return;
    }

    if (formData.password.length < 8) {
      setError('密码长度至少为 8 位');
      return;
    }

    // 如果需要验证码但未填写
    if (showCaptcha && (!captchaCode || !captchaId)) {
      setError('请输入验证码');
      return;
    }

    try {
      await register(formData.username, formData.password, formData.email, captchaId, captchaCode);
      router.push('/dashboard');
    } catch (err) {
      if (err instanceof ApiClientError) {
        setError(err.data.error || '注册失败');
      } else {
        setError('注册失败，请稍后重试');
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 px-4">
      <div className="max-w-md w-full space-y-8">
        {/* Logo 和标题 */}
        <div className="text-center">
          <h1 className="text-5xl font-bold text-white mb-3 drop-shadow-lg">GKI Pass</h1>
          <p className="text-white/90 text-lg">隧道控制平台</p>
        </div>

        {/* 注册表单 - 玻璃态效果 */}
        <div className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-2xl p-8 shadow-2xl">
          <h2 className="text-3xl font-semibold text-white mb-6 text-center">
            注册新账号
          </h2>

          {error && (
            <div className="mb-4 p-3 bg-red-500/20 border border-red-300/50 backdrop-blur-sm rounded-lg">
              <p className="text-sm text-white">{error}</p>
            </div>
          )}

          <div className="mb-4 p-3 bg-blue-500/20 border border-blue-300/50 backdrop-blur-sm rounded-lg">
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-white/90 mb-2">
                用户名
              </label>
              <input
                id="username"
                type="text"
                required
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                className="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/50 backdrop-blur-sm transition-all"
                placeholder="请输入用户名"
                disabled={isLoading}
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-white/90 mb-2">
                邮箱
              </label>
              <input
                id="email"
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/50 backdrop-blur-sm transition-all"
                placeholder="请输入邮箱"
                disabled={isLoading}
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-white/90 mb-2">
                密码
              </label>
              <input
                id="password"
                type="password"
                required
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/50 backdrop-blur-sm transition-all"
                placeholder="至少 8 位字符"
                disabled={isLoading}
              />
            </div>

            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-white/90 mb-2">
                确认密码
              </label>
              <input
                id="confirmPassword"
                type="password"
                required
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                className="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/50 backdrop-blur-sm transition-all"
                placeholder="再次输入密码"
                disabled={isLoading}
              />
            </div>

            {showCaptcha && (
              <div className="bg-gradient-to-r from-cyan-50 to-blue-50 border-3 border-cyan-300 rounded-2xl p-5 shadow-lg">
                <ImageCaptcha
                  onChange={(code, id) => {
                    setCaptchaCode(code);
                    setCaptchaId(id);
                  }}
                />
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-white/20 hover:bg-white/30 active:bg-white/40 text-white font-semibold py-3 rounded-lg transition-all duration-200 backdrop-blur-sm border border-white/30 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              {isLoading ? (
                <span className="flex items-center justify-center">
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  注册中...
                </span>
              ) : (
                '注册'
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-white/80">
              已有账号？{' '}
              <Link href="/login" className="text-white font-semibold hover:underline">
                立即登录
              </Link>
            </p>
          </div>
        </div>

        {/* 底部信息 */}
        <div className="text-center text-sm text-white/70">
          <p>© 2025 GKI Pass. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}


















