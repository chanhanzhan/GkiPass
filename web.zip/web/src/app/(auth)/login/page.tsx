'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/hooks/useAuth';
import { ApiClientError, api } from '@/lib/api';
import { ImageCaptcha } from '@/components/ui/Captcha';

export default function LoginPage() {
  const router = useRouter();
  const { login, isLoading } = useAuth();
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const [captchaCode, setCaptchaCode] = useState('');
  const [captchaId, setCaptchaId] = useState('');
  const [showCaptcha, setShowCaptcha] = useState(false);
  const [error, setError] = useState('');

  // 检查是否需要验证码
  useEffect(() => {
    const checkCaptcha = async () => {
      try {
        const config = await api.captcha.getConfig();
        setShowCaptcha(config.enabled && config.enable_login);
      } catch (err) {
        console.error('Failed to get captcha config:', err);
      }
    };
    checkCaptcha();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // 如果需要验证码但未填写
    if (showCaptcha && (!captchaCode || !captchaId)) {
      setError('请输入验证码');
      return;
    }

    try {
      await login(formData.username, formData.password, captchaId, captchaCode);
      router.push('/dashboard');
    } catch (err) {
      if (err instanceof ApiClientError) {
        setError(err.data.error || '登录失败');
      } else {
        setError('登录失败，请稍后重试');
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden px-4">
      {/* 超级多彩的动态背景 */}
      <div className="absolute inset-0 bg-gradient-to-br from-pink-400 via-purple-400 to-indigo-600"></div>
      
      {/* 浮动的彩色圆球 */}
      <div className="absolute inset-0 overflow-hidden opacity-30">
        <div className="absolute top-20 left-20 w-72 h-72 bg-yellow-300 rounded-full mix-blend-multiply filter blur-xl animate-float"></div>
        <div className="absolute top-40 right-20 w-72 h-72 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl animate-float" style={{animationDelay: '2s'}}></div>
        <div className="absolute -bottom-8 left-1/2 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl animate-float" style={{animationDelay: '4s'}}></div>
        <div className="absolute top-1/2 right-1/3 w-72 h-72 bg-cyan-300 rounded-full mix-blend-multiply filter blur-xl animate-float" style={{animationDelay: '3s'}}></div>
      </div>
      
      <div className="relative z-10 w-full max-w-md">
        {/* Logo 和标题 - 超大醒目 */}
        <div className="text-center mb-10">
          <div className="inline-block relative">
            <h1 className="text-7xl font-black bg-gradient-to-r from-white via-yellow-200 to-white bg-clip-text text-transparent drop-shadow-2xl mb-2 tracking-tight">
              GKI Pass
            </h1>
            <div className="absolute -inset-1 bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 rounded-lg blur opacity-20 group-hover:opacity-100 transition duration-1000"></div>
          </div>
          <p className="text-white/90 text-xl font-medium tracking-wide drop-shadow-lg">企业级双向隧道控制平台</p>
          <div className="flex items-center justify-center gap-3 mt-4">
            <div className="h-1 w-16 bg-gradient-to-r from-transparent via-yellow-300 to-transparent rounded-full"></div>
            <span className="text-yellow-300 text-xl">✦</span>
            <div className="h-1 w-16 bg-gradient-to-r from-transparent via-pink-300 to-transparent rounded-full"></div>
          </div>
        </div>

        {/* 登录表单 - 白色卡片，超级醒目 */}
        <div className="bg-white/95 backdrop-blur-xl rounded-3xl p-10 shadow-2xl border-4 border-white/50 hover:shadow-pink-500/20 hover:shadow-[0_20px_70px_rgba(236,72,153,0.3)] transition-all duration-500 transform hover:scale-[1.02]">
          <div className="text-center mb-8">
            <h2 className="text-4xl font-black bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent">
              欢迎回来
            </h2>
            <p className="text-gray-600 mt-2">登录以继续您的旅程</p>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-gradient-to-r from-red-100 to-pink-100 border-2 border-red-300 rounded-2xl shadow-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-red-500 rounded-full flex items-center justify-center text-white text-xl">!</div>
                <p className="text-sm font-medium text-red-700">{error}</p>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="relative group">
              <label htmlFor="username" className="block text-sm font-bold text-gray-700 mb-2 flex items-center gap-2">
                <span className="text-xl">👤</span>
                <span>用户名</span>
              </label>
              <div className="relative">
                <input
                  id="username"
                  type="text"
                  required
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  className="w-full px-5 py-4 bg-gradient-to-r from-purple-50 to-pink-50 border-3 border-transparent focus:border-purple-500 rounded-2xl text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-4 focus:ring-purple-200 transition-all duration-300 font-medium shadow-lg group-hover:shadow-purple-200"
                  placeholder="请输入用户名"
                  disabled={isLoading}
                />
                <div className="absolute right-4 top-1/2 -translate-y-1/2 text-purple-400 opacity-0 group-hover:opacity-100 transition-opacity">
                  ✨
                </div>
              </div>
            </div>

            <div className="relative group">
              <label htmlFor="password" className="block text-sm font-bold text-gray-700 mb-2 flex items-center gap-2">
                <span className="text-xl">🔒</span>
                <span>密码</span>
              </label>
              <div className="relative">
                <input
                  id="password"
                  type="password"
                  required
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full px-5 py-4 bg-gradient-to-r from-pink-50 to-purple-50 border-3 border-transparent focus:border-pink-500 rounded-2xl text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-4 focus:ring-pink-200 transition-all duration-300 font-medium shadow-lg group-hover:shadow-pink-200"
                  placeholder="请输入密码"
                  disabled={isLoading}
                />
                <div className="absolute right-4 top-1/2 -translate-y-1/2 text-pink-400 opacity-0 group-hover:opacity-100 transition-opacity">
                  ✨
                </div>
              </div>
            </div>

            {showCaptcha && (
              <div className="bg-gradient-to-r from-cyan-50 to-blue-50 border-3 border-cyan-300 rounded-2xl p-5 shadow-lg">
                <ImageCaptcha
                  onChange={(code, id) => {
                    setCaptchaCode(code);
                    setCaptchaId(id);
                  }}
                />
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full relative overflow-hidden bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 hover:from-pink-600 hover:via-purple-600 hover:to-indigo-600 text-white font-black text-lg py-5 rounded-2xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-2xl hover:shadow-[0_20px_60px_rgba(236,72,153,0.4)] transform hover:scale-105 hover:-translate-y-1"
            >
              {isLoading ? (
                <span className="flex items-center justify-center">
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  登录中...
                </span>
              ) : (
                '登录'
              )}
            </button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-gray-700">
              还没有账号？{' '}
              <Link href="/register" className="text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-purple-600 font-black hover:from-pink-500 hover:to-purple-500 transition-all text-lg">
                立即注册 →
              </Link>
            </p>
          </div>
        </div>

        {/* 底部信息 */}
        <div className="text-center mt-8">
          <p className="text-white/80 text-sm font-medium drop-shadow-md">© 2025 GKI Pass. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}


















