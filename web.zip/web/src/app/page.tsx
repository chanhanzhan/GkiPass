'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { getAuthToken } from '@/lib/auth';

export default function Home() {
  const router = useRouter();
  const [isChecking, setIsChecking] = useState(true);

  useEffect(() => {
    console.log('🏠 Home page mounted - checking auth');
    
    // 直接在这里检查localStorage，不依赖zustand store
    const checkAndRedirect = () => {
      try {
        const token = getAuthToken();
        console.log('🏠 Token check:', token ? 'exists' : 'none');
        
        if (token) {
          console.log('🏠 Has token, redirecting to /dashboard');
          router.replace('/dashboard');
        } else {
          console.log('🏠 No token, redirecting to /login');
          router.replace('/login');
        }
      } catch (error) {
        console.error('🏠 Error checking auth:', error);
        // 出错时默认跳转到登录页
        router.replace('/login');
      } finally {
        setIsChecking(false);
      }
    };

    // 使用 setTimeout 确保客户端已经完全挂载
    const timer = setTimeout(checkAndRedirect, 100);
    
    return () => clearTimeout(timer);
  }, [router]);

  // 服务端和客户端渲染相同的内容（避免 Hydration Error）
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-900">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-4 text-slate-300">
          {isChecking ? '正在检查登录状态...' : '正在跳转...'}
        </p>
      </div>
    </div>
  );
}
