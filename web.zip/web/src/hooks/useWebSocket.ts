/**
 * WebSocket 实时更新 Hook
 */

/* eslint-disable @typescript-eslint/no-explicit-any */

'use client';

import { useEffect, useRef, useState } from 'react';
import { getAuthToken } from '@/lib/auth';
const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080';
const WS_BASE_URL = API_BASE_URL.replace(/^http/, 'ws');

interface UseWebSocketOptions {
  onMessage?: (data: any) => void;
  onError?: (error: Event) => void;
  reconnect?: boolean;
  reconnectInterval?: number;
}

export function useWebSocket(endpoint: string, options: UseWebSocketOptions = {}) {
  const {
    onMessage,
    onError,
    reconnect = true,
    reconnectInterval = 5000,
  } = options;

  const [data, setData] = useState<any>(null);
  const [isConnected, setIsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    connect();

    return () => {
      disconnect();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [endpoint]);

  const connect = () => {
    const token = getAuthToken();
    if (!token) {
      console.error('No auth token found');
      return;
    }

    const url = `${WS_BASE_URL}${endpoint}`;
    const ws = new WebSocket(url);

    ws.onopen = () => {
      console.log('WebSocket connected:', endpoint);
      setIsConnected(true);
      
      // 清除重连定时器
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = null;
      }
    };

    ws.onmessage = (event) => {
      try {
        const messageData = JSON.parse(event.data);
        setData(messageData);
        if (onMessage) {
          onMessage(messageData);
        }
      } catch (error) {
        console.error('Failed to parse WebSocket message:', error);
      }
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      setIsConnected(false);
      if (onError) {
        onError(error);
      }
    };

    ws.onclose = () => {
      console.log('WebSocket disconnected:', endpoint);
      setIsConnected(false);
      wsRef.current = null;

      // 自动重连
      if (reconnect) {
        reconnectTimeoutRef.current = setTimeout(() => {
          console.log('Attempting to reconnect WebSocket...');
          connect();
        }, reconnectInterval);
      }
    };

    wsRef.current = ws;
  };

  const disconnect = () => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }

    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setIsConnected(false);
  };

  const send = (message: any) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(message));
    } else {
      console.error('WebSocket is not connected');
    }
  };

  return {
    data,
    isConnected,
    send,
    reconnect: connect,
    disconnect,
  };
}

export function useNodeStatus(nodeId: string | null) {
  const [status, setStatus] = useState<any>(null);

  const { isConnected, send } = useWebSocket(
    nodeId ? '/ws/node' : '',
    {
      onMessage: (data) => {
        // 过滤当前节点的状态数据
        if (data.type === 'node_status' && data.node_id === nodeId) {
          setStatus(data.data);
        } else if (data.type === 'heartbeat' && data.data?.node_id === nodeId) {
          setStatus({
            online: true,
            cpu_usage: data.data.cpu_usage,
            memory_usage: data.data.memory_usage,
            connections: data.data.connections,
            last_heartbeat: data.timestamp,
          });
        }
      },
    }
  );

  // 连接建立后订阅特定节点
  useEffect(() => {
    if (isConnected && nodeId) {
      send({
        type: 'subscribe_node',
        node_id: nodeId,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isConnected, nodeId]);

  return { status, isConnected };
}

/**
 * 系统统计实时监控 Hook
 */
export function useSystemStats() {
  const [stats, setStats] = useState<any>(null);

  const { isConnected } = useWebSocket('/ws/stats', {
    onMessage: (data) => {
      if (data.type === 'statistics') {
        setStats(data.data);
      }
    },
  });

  return { stats, isConnected };
}

