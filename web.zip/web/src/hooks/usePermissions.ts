/**
 * 权限管理 Hook
 * 统一管理用户权限判断逻辑
 */

'use client';

import { create } from 'zustand';
import { api } from '@/lib/api';
import type { UserPermissions } from '@/types';

interface PermissionsState {
  permissions: UserPermissions | null;
  isLoading: boolean;
  hasPermission: (resource: string, action: string) => boolean;
  isAdmin: () => boolean;
  canAccessAdminPanel: () => boolean;
  loadPermissions: () => Promise<void>;
  clearPermissions: () => void;
}

export const usePermissions = create<PermissionsState>((set, get) => ({
  permissions: null,
  isLoading: false,

  /**
   * 检查是否有特定权限
   * @param resource 资源名称 (如 'user', 'node', 'tunnel')
   * @param action 操作名称 (如 'read', 'create', 'update', 'delete')
   */
  hasPermission: (resource: string, action: string): boolean => {
    const { permissions } = get();
    if (!permissions) return false;

    // 管理员拥有所有权限
    if (permissions.admin) return true;

    // 检查具体权限
    const resourcePermissions = permissions.permissions[resource as keyof typeof permissions.permissions];
    if (!resourcePermissions) return false;

    return resourcePermissions[action] === true;
  },

  /**
   * 检查是否为管理员
   */
  isAdmin: (): boolean => {
    const { permissions } = get();
    return permissions?.admin === true;
  },

  /**
   * 检查是否可以访问管理员面板
   */
  canAccessAdminPanel: (): boolean => {
    const { permissions } = get();
    return permissions?.can_access_admin_panel === true;
  },

  /**
   * 从后端加载权限数据
   */
  loadPermissions: async () => {
    set({ isLoading: true });
    try {
      const data = await api.user.getPermissions();
      set({ permissions: data, isLoading: false });
    } catch (error) {
      console.error('Failed to load permissions:', error);
      set({ permissions: null, isLoading: false });
    }
  },

  /**
   * 清除权限数据
   */
  clearPermissions: () => {
    set({ permissions: null });
  },
}));

