/**
 * 认证相关 Hook
 */

'use client';

import { create } from 'zustand';
import { api } from '@/lib/api';
import { setAuthToken, setAuthUser, removeAuthToken, getAuthToken, getAuthUser } from '@/lib/auth';
import type { User } from '@/types';

interface AuthState {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  isInitialized: boolean;
  login: (username: string, password: string, captchaId?: string, captchaCode?: string) => Promise<void>;
  register: (username: string, password: string, email: string, captchaId?: string, captchaCode?: string) => Promise<void>;
  logout: () => Promise<void>;
  checkAuth: () => void;
  refreshUser: () => Promise<void>;
}

export const useAuth = create<AuthState>((set, get) => ({
  user: null,
  isLoading: false,
  isAuthenticated: false,
  isInitialized: false,

  login: async (username: string, password: string, captchaId?: string, captchaCode?: string) => {
    set({ isLoading: true });
    try {
      const response = await api.auth.login({ username, password, captcha_id: captchaId, captcha_code: captchaCode });
      console.log('🔐 Login response:', response);
      
      const user = {
        id: response.user_id,
        username: response.username,
        role: response.role,
        is_admin: response.role === 'admin',
      };
      
      console.log('💾 Saving token:', response.token);
      setAuthToken(response.token);
      setAuthUser(user);
      
      console.log('✅ Token saved to localStorage');
      set({ user, isAuthenticated: true, isInitialized: true, isLoading: false });
    } catch (error) {
      console.error('❌ Login failed:', error);
      set({ isLoading: false });
      throw error;
    }
  },

  register: async (username: string, password: string, email: string, captchaId?: string, captchaCode?: string) => {
    set({ isLoading: true });
    try {
      const response = await api.auth.register({ username, password, email, captcha_id: captchaId, captcha_code: captchaCode });
      console.log('📝 Register response:', response);
      
      const user = {
        id: response.user_id,
        username: response.username,
        role: response.role,
        is_admin: response.role === 'admin',
      };
      
      console.log('💾 Saving token:', response.token);
      setAuthToken(response.token);
      setAuthUser(user);
      
      console.log('✅ Token saved to localStorage');
      set({ user, isAuthenticated: true, isInitialized: true, isLoading: false });
    } catch (error) {
      console.error('❌ Register failed:', error);
      set({ isLoading: false });
      throw error;
    }
  },

  logout: async () => {
    try {
      await api.auth.logout();
    } catch (error) {
      // 即使 API 调用失败也要登出
      console.error('Logout API call failed:', error);
    } finally {
      removeAuthToken();
      set({ user: null, isAuthenticated: false });
    }
  },

  checkAuth: () => {
    // Only run on client side
    if (typeof window === 'undefined') {
      console.log('⚠️ checkAuth called on server side, skipping');
      return;
    }
    
    console.log('🔍 Checking auth...');
    const token = getAuthToken();
    const userData = getAuthUser();
    console.log('🔑 Token:', token ? 'exists' : 'none');
    console.log('👤 User data:', userData);
    
    if (token && userData) {
      const user = userData as unknown as User;
      console.log('✅ User authenticated:', user);
      set({ user, isAuthenticated: true, isInitialized: true });
      
      // 从后端获取最新用户信息
      get().refreshUser().catch(err => {
        console.error('Failed to refresh user data:', err);
      });
    } else {
      console.log('❌ User not authenticated');
      set({ user: null, isAuthenticated: false, isInitialized: true });
    }
    
    console.log('🔍 Auth check complete, state updated');
  },

  refreshUser: async () => {
    try {
      const token = getAuthToken();
      if (!token) {
        console.log('No token available, skipping refresh');
        return;
      }

      console.log('🔄 Refreshing user data from server...');
      const userData = await api.user.getCurrentUser();
      
      const user: User = {
        id: userData.id,
        username: userData.username,
        email: userData.email,
        role: userData.role,
        is_admin: userData.is_admin,
        created_at: userData.created_at,
        last_login: userData.last_login,
        enabled: userData.enabled,
        provider: userData.provider,
      };

      // 更新localStorage和状态
      setAuthUser(user);
      set({ user, isAuthenticated: true });
      console.log('✅ User data refreshed successfully');
    } catch (error) {
      console.error('❌ Failed to refresh user data:', error);
      // 如果刷新失败，可能token已过期，清除认证状态
      removeAuthToken();
      set({ user: null, isAuthenticated: false });
    }
  },
}));


















