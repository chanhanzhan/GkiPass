// 主题切换（暗黑/浅色模式）
export type Theme = 'light' | 'dark' | 'auto';

type ThemeListener = (theme: 'light' | 'dark') => void;

export class ThemeManager {
  private currentTheme: Theme = 'auto';
  private listeners: ThemeListener[] = [];

  constructor() {
    this.loadTheme();
    this.applyTheme();
    this.watchSystemTheme();
  }

  private loadTheme(): void {
    const saved = localStorage.getItem('theme') as Theme;
    if (saved && ['light', 'dark', 'auto'].includes(saved)) {
      this.currentTheme = saved;
    }
  }

  private saveTheme(): void {
    localStorage.setItem('theme', this.currentTheme);
  }

  getTheme(): Theme {
    return this.currentTheme;
  }

  setTheme(theme: Theme): void {
    this.currentTheme = theme;
    this.saveTheme();
    this.applyTheme();
  }

  private applyTheme(): void {
    const resolvedTheme = this.resolveTheme();
    
    if (resolvedTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    this.notifyListeners(resolvedTheme);
  }

  private resolveTheme(): 'light' | 'dark' {
    if (this.currentTheme === 'auto') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    return this.currentTheme;
  }

  private watchSystemTheme(): void {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    
    const handler = (): void => {
      if (this.currentTheme === 'auto') {
        this.applyTheme();
      }
    };

    // Modern browsers
    if (mediaQuery.addEventListener) {
      mediaQuery.addEventListener('change', handler);
    }
  }

  subscribe(callback: ThemeListener): () => void {
    this.listeners.push(callback);
    return () => {
      const index = this.listeners.indexOf(callback);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  private notifyListeners(theme: 'light' | 'dark'): void {
    this.listeners.forEach(listener => listener(theme));
  }
}

export const themeManager = new ThemeManager();
