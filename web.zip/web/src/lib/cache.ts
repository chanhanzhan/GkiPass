// 前端缓存策略（LocalStorage + Memory Cache）
interface CacheItem<T = unknown> {
  data: T;
  expiry: number;
}

export class CacheManager {
  private memoryCache: Map<string, CacheItem> = new Map();
  private storagePrefix = 'gkipass_';

  set<T = unknown>(key: string, data: T, ttl = 3600000): void {
    const expiry = Date.now() + ttl;
    
    // Memory cache
    this.memoryCache.set(key, { data, expiry });
    
    // LocalStorage cache (with size limit)
    try {
      const item = { data, expiry };
      localStorage.setItem(this.storagePrefix + key, JSON.stringify(item));
    } catch {
      console.warn('LocalStorage full, clearing old items');
      this.clearExpired();
    }
  }

  get<T = unknown>(key: string): T | null {
    // Try memory cache first
    const memItem = this.memoryCache.get(key);
    if (memItem && memItem.expiry > Date.now()) {
      return memItem.data as T;
    }

    // Try localStorage
    try {
      const stored = localStorage.getItem(this.storagePrefix + key);
      if (stored) {
        const item: CacheItem = JSON.parse(stored);
        if (item.expiry > Date.now()) {
          // Restore to memory cache
          this.memoryCache.set(key, item);
          return item.data as T;
        } else {
          // Expired, remove it
          localStorage.removeItem(this.storagePrefix + key);
        }
      }
    } catch {
      console.error('Cache read error');
    }

    return null;
  }

  remove(key: string): void {
    this.memoryCache.delete(key);
    localStorage.removeItem(this.storagePrefix + key);
  }

  clear(): void {
    this.memoryCache.clear();
    Object.keys(localStorage).forEach(key => {
      if (key.startsWith(this.storagePrefix)) {
        localStorage.removeItem(key);
      }
    });
  }

  clearExpired(): void {
    const now = Date.now();
    
    // Clear memory cache
    this.memoryCache.forEach((value, key) => {
      if (value.expiry <= now) {
        this.memoryCache.delete(key);
      }
    });

    // Clear localStorage
    Object.keys(localStorage).forEach(key => {
      if (key.startsWith(this.storagePrefix)) {
        try {
          const item: CacheItem = JSON.parse(localStorage.getItem(key) || '{}');
          if (item.expiry && item.expiry <= now) {
            localStorage.removeItem(key);
          }
        } catch {
          localStorage.removeItem(key);
        }
      }
    });
  }
}

export const cache = new CacheManager();
