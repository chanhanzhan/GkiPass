/* eslint-disable @typescript-eslint/no-explicit-any */

const AUTH_TOKEN_KEY = 'auth_token';
const AUTH_USER_KEY = 'auth_user';

/**
 * 获取认证令牌
 */
export function getAuthToken(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem(AUTH_TOKEN_KEY);
}

/**
 * 设置认证令牌
 */
export function setAuthToken(token: string): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(AUTH_TOKEN_KEY, token);
}

/**
 * 移除认证令牌
 */
export function removeAuthToken(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(AUTH_TOKEN_KEY);
}

/**
 * 获取用户信息
 */
export function getAuthUser(): any {
  if (typeof window === 'undefined') return null;
  const userStr = localStorage.getItem(AUTH_USER_KEY);
  if (!userStr || userStr === 'undefined' || userStr === 'null') return null;
  try {
    return JSON.parse(userStr);
  } catch {
    return null;
  }
}

/**
 * 设置用户信息
 */
export function setAuthUser(user: any): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(AUTH_USER_KEY, JSON.stringify(user));
}

/**
 * 移除用户信息
 */
export function removeAuthUser(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(AUTH_USER_KEY);
}

/**
 * 检查是否已认证
 */
export function isAuthenticated(): boolean {
  if (typeof window === 'undefined') return false;
  const token = getAuthToken();
  return !!token;
}

/**
 * 清除所有认证信息
 */
export function clearAuth(): void {
  removeAuthToken();
  removeAuthUser();
}

/**
 * 从JWT token中解析用户信息
 */
export function parseJWT(token: string): any {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split('')
        .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );
    return JSON.parse(jsonPayload);
  } catch {
    return null;
  }
}

/**
 * 检查token是否过期
 */
export function isTokenExpired(token: string): boolean {
  try {
    const payload = parseJWT(token);
    if (!payload || !payload.exp) return true;
    return Date.now() >= payload.exp * 1000;
  } catch {
    return true;
  }
}

/**
 * 验证并返回当前认证状态
 */
export function checkAuth(): { isAuthenticated: boolean; user: any } {
  const token = getAuthToken();
  if (!token || isTokenExpired(token)) {
    clearAuth();
    return { isAuthenticated: false, user: null };
  }

  const user = getAuthUser();
  return { isAuthenticated: true, user };
}
