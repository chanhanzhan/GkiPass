// 性能监控工具
interface PerformanceMetric {
  name: string;
  value: number;
  timestamp: number;
}

export class PerformanceMonitor {
  private static metrics: Map<string, PerformanceMetric[]> = new Map();
  private static maxMetricsPerName = 100;

  static startMeasure(name: string): void {
    if (typeof performance !== 'undefined' && performance.mark) {
      performance.mark(`${name}-start`);
    }
  }

  static endMeasure(name: string): number | null {
    if (typeof performance !== 'undefined' && performance.mark && performance.measure) {
      performance.mark(`${name}-end`);
      
      try {
        performance.measure(name, `${name}-start`, `${name}-end`);
        const measure = performance.getEntriesByName(name, 'measure')[0];
        
        if (measure) {
          const value = measure.duration;
          this.recordMetric(name, value);
          
          // Cleanup
          performance.clearMarks(`${name}-start`);
          performance.clearMarks(`${name}-end`);
          performance.clearMeasures(name);
          
          return value;
        }
      } catch (error) {
        console.error('Performance measurement error:', error);
      }
    }
    return null;
  }

  private static recordMetric(name: string, value: number): void {
    if (!this.metrics.has(name)) {
      this.metrics.set(name, []);
    }

    const metrics = this.metrics.get(name)!;
    metrics.push({
      name,
      value,
      timestamp: Date.now(),
    });

    // Keep only recent metrics
    if (metrics.length > this.maxMetricsPerName) {
      metrics.shift();
    }
  }

  static getMetrics(name: string): PerformanceMetric[] {
    return this.metrics.get(name) || [];
  }

  static getAllMetrics(): Record<string, PerformanceMetric[]> {
    const result: Record<string, PerformanceMetric[]> = {};
    this.metrics.forEach((metrics, name) => {
      result[name] = metrics;
    });
    return result;
  }

  static getAverageMetric(name: string): number | null {
    const metrics = this.metrics.get(name);
    if (!metrics || metrics.length === 0) {
      return null;
    }

    const sum = metrics.reduce((acc, m) => acc + m.value, 0);
    return sum / metrics.length;
  }

  static clearMetrics(name?: string): void {
    if (name) {
      this.metrics.delete(name);
    } else {
      this.metrics.clear();
    }
  }

  static reportCustomMetric(name: string, value: number | string): void {
    if (typeof value === 'number') {
      this.recordMetric(name, value);
    } else {
      console.log(`Custom metric [${name}]:`, value);
    }
  }
}
