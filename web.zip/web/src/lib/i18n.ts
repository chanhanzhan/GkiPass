// 国际化支持
export type Locale = 'zh-CN' | 'en-US';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type TranslationValue = string | Record<string, any>;
type Translations = Record<string, TranslationValue>;

const translations: Record<Locale, Translations> = {
  'zh-CN': {
    common: {
      save: '保存',
      cancel: '取消',
      delete: '删除',
      edit: '编辑',
      add: '添加',
      search: '搜索',
      loading: '加载中...',
      error: '错误',
      success: '成功',
    },
    auth: {
      login: '登录',
      logout: '登出',
      register: '注册',
      username: '用户名',
      password: '密码',
      email: '邮箱',
    },
    nav: {
      dashboard: '仪表板',
      tunnels: '隧道',
      nodes: '节点',
      settings: '设置',
    },
  },
  'en-US': {
    common: {
      save: 'Save',
      cancel: 'Cancel',
      delete: 'Delete',
      edit: 'Edit',
      add: 'Add',
      search: 'Search',
      loading: 'Loading...',
      error: 'Error',
      success: 'Success',
    },
    auth: {
      login: 'Login',
      logout: 'Logout',
      register: 'Register',
      username: 'Username',
      password: 'Password',
      email: 'Email',
    },
    nav: {
      dashboard: 'Dashboard',
      tunnels: 'Tunnels',
      nodes: 'Nodes',
      settings: 'Settings',
    },
  },
};

type ListenerCallback = () => void;

export class I18n {
  private locale: Locale = 'zh-CN';
  private listeners: ListenerCallback[] = [];

  constructor() {
    this.loadLocale();
  }

  private loadLocale(): void {
    const saved = localStorage.getItem('locale') as Locale;
    if (saved && translations[saved]) {
      this.locale = saved;
    } else {
      // Auto-detect from browser
      const browserLang = navigator.language;
      if (browserLang.startsWith('zh')) {
        this.locale = 'zh-CN';
      } else {
        this.locale = 'en-US';
      }
    }
  }

  private saveLocale(): void {
    localStorage.setItem('locale', this.locale);
  }

  getLocale(): Locale {
    return this.locale;
  }

  setLocale(locale: Locale): void {
    if (translations[locale]) {
      this.locale = locale;
      this.saveLocale();
      this.notifyListeners();
    }
  }

  t(key: string, params?: Record<string, string | number>): string {
    const keys = key.split('.');
    let value: TranslationValue | undefined = translations[this.locale];

    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        return key; // Fallback to key if not found
      }
    }

    if (typeof value !== 'string') {
      return key;
    }

    // Replace params
    if (params) {
      let result = value;
      Object.entries(params).forEach(([k, v]) => {
        result = result.replace(new RegExp(`\\{${k}\\}`, 'g'), String(v));
      });
      return result;
    }

    return value;
  }

  subscribe(callback: ListenerCallback): () => void {
    this.listeners.push(callback);
    return () => {
      const index = this.listeners.indexOf(callback);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  private notifyListeners(): void {
    this.listeners.forEach(listener => listener());
  }
}

export const i18n = new I18n();
