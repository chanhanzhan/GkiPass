/**
 * RelayX 性能优化工具函数
 */
/* eslint-disable @typescript-eslint/no-explicit-any */

// 防抖函数，优化频繁的用户输入
export function debounce<T extends (...args: unknown[]) => unknown>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout
  return (...args: Parameters<T>) => {
    clearTimeout(timeout)
    timeout = setTimeout(() => func(...args), wait)
  }
}

// 节流函数，限制函数调用频率
export function throttle<T extends (...args: unknown[]) => unknown>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let inThrottle: boolean
  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      func(...args)
      inThrottle = true
      setTimeout(() => (inThrottle = false), wait)
    }
  }
}

// 内存化函数，缓存计算结果
export function memoize<T extends (...args: any[]) => any>(fn: T): T {
  const cache = new Map()
  
  return ((...args: Parameters<T>): ReturnType<T> => {
    const key = JSON.stringify(args)
    
    if (cache.has(key)) {
      return cache.get(key)
    }
    
    const result = fn(...args)
    cache.set(key, result)
    return result
  }) as T
}

// 格式化文件大小（缓存版本）
export const formatBytesOptimized = memoize((bytes: number, decimals: number = 2): string => {
  if (bytes === 0) return '0 Bytes'

  const k = 1024
  const dm = decimals < 0 ? 0 : decimals
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB']

  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i]
})

// 虚拟滚动辅助函数
export function calculateVirtualItems({
  itemHeight,
  containerHeight,
  scrollTop,
  totalItems,
  overscan = 5
}: {
  itemHeight: number
  containerHeight: number
  scrollTop: number
  totalItems: number
  overscan?: number
}) {
  const startIndex = Math.max(0, Math.floor(scrollTop / itemHeight) - overscan)
  const endIndex = Math.min(
    totalItems - 1,
    Math.ceil((scrollTop + containerHeight) / itemHeight) + overscan
  )

  return {
    startIndex,
    endIndex,
    visibleItems: endIndex - startIndex + 1,
    offsetY: startIndex * itemHeight,
    totalHeight: totalItems * itemHeight
  }
}

// 图片预加载
export function preloadImages(imageUrls: string[]): Promise<void[]> {
  const promises = imageUrls.map(url => {
    return new Promise<void>((resolve, reject) => {
      const img = new Image()
      img.onload = () => resolve()
      img.onerror = () => reject(new Error(`Failed to load image: ${url}`))
      img.src = url
    })
  })

  return Promise.all(promises)
}

// 组件懒加载
export function createLazyComponent<T>(
  importFunc: () => Promise<{ default: React.ComponentType<T> }>
) {
  return React.lazy(importFunc)
}

// 批处理状态更新
export function batchUpdates(callback: () => void) {
  if (typeof window !== 'undefined' && 'requestIdleCallback' in window) {
    requestIdleCallback(callback)
  } else {
    setTimeout(callback, 0)
  }
}

// 性能监控
export class PerformanceMonitor {
  private static metrics: Map<string, number> = new Map()

  static mark(name: string) {
    if (typeof performance !== 'undefined') {
      performance.mark(name)
    }
    this.metrics.set(name, Date.now())
  }

  static measure(name: string, startMark: string, endMark?: string) {
    if (typeof performance !== 'undefined') {
      performance.mark(endMark || `${name}-end`)
      performance.measure(name, startMark, endMark || `${name}-end`)
      
      const entry = performance.getEntriesByName(name)[0]
      console.log(`Performance [${name}]:`, entry.duration.toFixed(2), 'ms')
      return entry.duration
    }
    
    const startTime = this.metrics.get(startMark)
    if (startTime) {
      const duration = Date.now() - startTime
      console.log(`Performance [${name}]:`, duration, 'ms')
      return duration
    }
    
    return 0
  }

  static getMetrics() {
    if (typeof performance !== 'undefined') {
      return performance.getEntriesByType('measure')
    }
    return []
  }
}

// React性能优化hooks
import React, { useCallback, useMemo } from 'react'

export function useDebounce<T extends (...args: unknown[]) => unknown>(
  callback: T,
  delay: number
): T {
  // eslint-disable-next-line react-hooks/exhaustive-deps
  return useCallback(debounce(callback, delay), [callback, delay]) as T
}

export function useThrottle<T extends (...args: unknown[]) => unknown>(
  callback: T,
  delay: number
): T {
  // eslint-disable-next-line react-hooks/exhaustive-deps
  return useCallback(throttle(callback, delay), [callback, delay]) as T
}

export function useMemoizedValue<T>(factory: () => T, deps: React.DependencyList): T {
  // eslint-disable-next-line react-hooks/exhaustive-deps
  return useMemo(factory, deps)
}
