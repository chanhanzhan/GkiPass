/**
 * API 客户端封装
 * 处理所有与后端的 HTTP 通信
 */

/* eslint-disable @typescript-eslint/no-explicit-any */

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080';

interface ApiError {
  error: string;
  code?: string;
}

export class ApiClientError extends Error {
  constructor(public statusCode: number, public data: ApiError) {
    super(data.error);
    this.name = 'ApiClientError';
  }
}

/**
 * 通用请求函数
 */
async function request<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const url = `${API_BASE_URL}${endpoint}`;
  
  const token = typeof window !== 'undefined' 
    ? localStorage.getItem('auth_token') 
    : null;

  console.log('📡 API Request:', endpoint, 'Token:', token ? token.substring(0, 20) + '...' : 'None');

  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  if (token) {
    (headers as Record<string, string>)['Authorization'] = `Bearer ${token}`;
    console.log('🔑 Added Authorization header');
  }

  const response = await fetch(url, {
    ...options,
    headers,
  });
  
  console.log('📥 Response status:', response.status, endpoint);

  const contentType = response.headers.get('content-type');
  if (contentType && !contentType.includes('application/json')) {
    if (!response.ok) {
      throw new ApiClientError(response.status, {
        error: 'Request failed',
      });
    }
    return response as unknown as T;
  }

  const result = await response.json();

  if (!response.ok) {
    // 提取错误消息
    const errorData = {
      error: result.message || result.error || 'Request failed',
      code: result.code,
    };
    throw new ApiClientError(response.status, errorData);
  }

  return result.data !== undefined ? result.data : result;
}

/**
 * API 客户端
 */
export const api = {
  // ===== 认证相关 =====
  auth: {
    login: (credentials: { username: string; password: string; captcha_id?: string; captcha_code?: string }) =>
      request<{ token: string; user_id: string; username: string; role: string; expires_at: number }>('/api/v1/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials),
      }),

    register: (userData: { username: string; password: string; email: string; captcha_id?: string; captcha_code?: string }) =>
      request<{ token: string; user_id: string; username: string; role: string; expires_at: number }>('/api/v1/auth/register', {
        method: 'POST',
        body: JSON.stringify(userData),
      }),

    logout: () =>
      request('/api/v1/auth/logout', { method: 'POST' }),

    getProfile: () =>
      request<any>('/api/v1/users/profile'),

    changePassword: (data: { current_password: string; new_password: string }) =>
      request('/api/v1/users/password', {
        method: 'PUT',
        body: JSON.stringify(data),
      }),
  },

  // ===== 用户信息相关 =====
  user: {
    // 获取当前用户完整信息（包括订阅、钱包、权限）
    getCurrentUser: () =>
      request<any>('/api/v1/users/me'),

    // 获取用户权限详情
    getPermissions: () =>
      request<any>('/api/v1/users/permissions'),

    // 获取基本信息（保留兼容）
    getProfile: () =>
      request<any>('/api/v1/users/profile'),

    // 修改密码
    updatePassword: (data: { old_password: string; new_password: string }) =>
      request('/api/v1/users/password', {
        method: 'PUT',
        body: JSON.stringify(data),
      }),
  },

  // ===== 用户管理（管理员）=====
  users: {
    // 获取所有用户列表
    list: () =>
      request<any>('/api/v1/users'),

    get: (id: string) =>
      request<any>(`/api/v1/users/${id}`),

    create: (data: any) =>
      request<any>('/api/v1/users', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    // 更新用户状态
    toggleStatus: (id: string) =>
      request<any>(`/api/v1/users/${id}/status`, {
        method: 'PUT',
      }),

    // 更新用户角色
    updateRole: (id: string, role: string) =>
      request<any>(`/api/v1/users/${id}/role`, {
        method: 'PUT',
        body: JSON.stringify({ role }),
      }),

    // 删除用户
    delete: (id: string) =>
      request<void>(`/api/v1/users/${id}`, {
        method: 'DELETE',
      }),

    assignPlan: (userId: string, planId: string) =>
      request<any>(`/api/v1/users/${userId}/assign-plan`, {
        method: 'POST',
        body: JSON.stringify({ plan_id: planId }),
      }),
  },

  // ===== 隧道管理 =====
  tunnels: {
    list: (params?: { page?: number; limit?: number }) => {
      const query = new URLSearchParams();
      if (params?.page) query.set('page', params.page.toString());
      if (params?.limit) query.set('limit', params.limit.toString());
      return request<any>(`/api/v1/tunnels?${query}`);
    },

    get: (id: string) =>
      request<any>(`/api/v1/tunnels/${id}`),

    create: (data: any) =>
      request<any>('/api/v1/tunnels', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    update: (id: string, data: any) =>
      request<any>(`/api/v1/tunnels/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      }),

    delete: (id: string) =>
      request<void>(`/api/v1/tunnels/${id}`, { method: 'DELETE' }),

    toggle: (id: string) =>
      request<any>(`/api/v1/tunnels/${id}/toggle`, { method: 'POST' }),
  },

  // ===== 节点管理 =====
  nodes: {
    list: () =>
      request<any>('/api/v1/nodes'),

    // 获取用户可用节点（基于套餐）
    available: () =>
      request<any>('/api/v1/nodes/available'),

    get: (id: string) =>
      request<any>(`/api/v1/nodes/${id}`),

    getStatus: (id: string) =>
      request<any>(`/api/v1/nodes/${id}/status`),

    listStatus: (groupType?: string) => {
      const query = new URLSearchParams();
      if (groupType) query.set('type', groupType);
      return request<any>(`/api/v1/nodes/status/list?${query}`);
    },

    create: (data: any) =>
      request<any>('/api/v1/nodes', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    generateCK: (id: string) =>
      request<{ ck: string }>(`/api/v1/nodes/${id}/generate-ck`, {
        method: 'POST',
      }),

    downloadCert: (id: string) =>
      request<Response>(`/api/v1/nodes/${id}/cert/download`),

    delete: (id: string) =>
      request<void>(`/api/v1/nodes/${id}`, { method: 'DELETE' }),
  },

  // ===== 节点组管理 =====
  nodeGroups: {
    list: () =>
      request<any>('/api/v1/node-groups'),

    create: (data: any) =>
      request<any>('/api/v1/node-groups', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    // 节点部署
    createNode: (groupId: string, data: any) =>
      request<any>(`/api/v1/node-groups/${groupId}/nodes`, {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    listNodes: (groupId: string) =>
      request<any>(`/api/v1/node-groups/${groupId}/nodes`),

    // 节点组配置
    getConfig: (groupId: string) =>
      request<any>(`/api/v1/node-groups/${groupId}/config`),

    updateConfig: (groupId: string, data: any) =>
      request<any>(`/api/v1/node-groups/${groupId}/config`, {
        method: 'PUT',
        body: JSON.stringify(data),
      }),

    resetConfig: (groupId: string) =>
      request<any>(`/api/v1/node-groups/${groupId}/config/reset`, {
        method: 'POST',
      }),
  },

  // ===== 套餐管理 =====
  plans: {
    list: () =>
      request<any>('/api/v1/plans'),

    get: (id: string) =>
      request<any>(`/api/v1/plans/${id}`),

    getMySubscription: () =>
      request<any>('/api/v1/plans/my/subscription'),

    subscribe: (planId: string) =>
      request<any>(`/api/v1/plans/${planId}/subscribe`, {
        method: 'GET',
      }),

    purchase: (planId: string) =>
      request<any>('/api/v1/plans/purchase', {
        method: 'POST',
        body: JSON.stringify({ plan_id: planId }),
      }),

    create: (data: any) =>
      request<any>('/api/v1/plans', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    update: (id: string, data: any) =>
      request<any>(`/api/v1/plans/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      }),

    delete: (id: string) =>
      request<void>(`/api/v1/plans/${id}`, { method: 'DELETE' }),

    toggle: (id: string) =>
      request<any>(`/api/v1/plans/${id}/toggle`, { method: 'POST' }),
  },

  // ===== 统计数据 =====
  statistics: {
    overview: () =>
      request<any>('/api/v1/statistics/overview'),
  },


  // ===== 策略管理 =====
  policies: {
    list: () =>
      request<any>('/api/v1/policies'),

    get: (id: string) =>
      request<any>(`/api/v1/policies/${id}`),

    create: (data: any) =>
      request<any>('/api/v1/policies', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    update: (id: string, data: any) =>
      request<any>(`/api/v1/policies/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      }),

    delete: (id: string) =>
      request<void>(`/api/v1/policies/${id}`, { method: 'DELETE' }),

    deploy: (id: string) =>
      request<any>(`/api/v1/policies/${id}/deploy`, {
        method: 'POST',
      }),
  },

  // ===== 证书管理 =====
  certificates: {
    list: () =>
      request<any>('/api/v1/certificates'),

    get: (id: string) =>
      request<any>(`/api/v1/certificates/${id}`),

    generateCA: (data: any) =>
      request<any>('/api/v1/certificates/ca', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    generateLeaf: (data: any) =>
      request<any>('/api/v1/certificates/leaf', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    revoke: (id: string) =>
      request<any>(`/api/v1/certificates/${id}/revoke`, {
        method: 'POST',
      }),

    download: (id: string) =>
      request<Response>(`/api/v1/certificates/${id}/download`),
  },

  // ===== 钱包管理 =====
  wallet: {
    getBalance: () =>
      request<{ balance: number; frozen: number }>('/api/v1/wallet/balance'),

    getTransactions: (params?: { page?: number; limit?: number }) => {
      const query = new URLSearchParams();
      if (params?.page) query.set('page', params.page.toString());
      if (params?.limit) query.set('limit', params.limit.toString());
      return request<any>(`/api/v1/wallet/transactions?${query}`);
    },

    recharge: (amount: number, paymentMethod = 'alipay') =>
      request<any>('/api/v1/payment/recharge', {
        method: 'POST',
        body: JSON.stringify({ amount, payment_method: paymentMethod }),
      }),

    simulatePaymentCallback: (data: any) =>
      request<any>('/api/v1/payment/callback', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
  },

  // ===== 支付管理 =====
  payment: {
    createOrder: (amount: number, paymentMethod: string, type = 'recharge', relatedId?: string) =>
      request<any>('/api/v1/payment/recharge', {
        method: 'POST',
        body: JSON.stringify({ amount, payment_method: paymentMethod, type, related_id: relatedId }),
      }),

    queryOrder: (orderId: string) =>
      request<any>(`/api/v1/payment/orders/${orderId}`),

    listOrders: (page = 1, limit = 20, status?: string) => {
      const query = new URLSearchParams();
      query.set('page', page.toString());
      query.set('limit', limit.toString());
      if (status) query.set('status', status);
      return request<any>(`/api/v1/payment/orders?${query}`);
    },

    getConfigs: () =>
      request<any>('/api/v1/admin/payment/configs'),

    getConfig: (id: string) =>
      request<any>(`/api/v1/admin/payment/config/${id}`),

    updateConfig: (id: string, data: any) =>
      request<any>(`/api/v1/admin/payment/config/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      }),

    toggleConfig: (id: string) =>
      request<any>(`/api/v1/admin/payment/config/${id}/toggle`, {
        method: 'POST',
      }),
  },

  // ===== 订阅管理 =====
  subscriptions: {
    current: () =>
      request<any>('/api/v1/subscriptions/current'),

    list: () =>
      request<any>('/api/v1/subscriptions'),
  },

  // ===== 通知管理 =====
  notifications: {
    list: (params?: { page?: number; limit?: number }) => {
      const query = new URLSearchParams();
      if (params?.page) query.set('page', params.page.toString());
      if (params?.limit) query.set('limit', params.limit.toString());
      return request<any>(`/api/v1/notifications?${query}`);
    },

    markAsRead: (id: string) =>
      request<any>(`/api/v1/notifications/${id}/read`, {
        method: 'POST',
      }),

    markAllAsRead: () =>
      request<any>('/api/v1/notifications/read-all', {
        method: 'POST',
      }),

    delete: (id: string) =>
      request<void>(`/api/v1/notifications/${id}`, {
        method: 'DELETE',
      }),

    // 管理员创建通知
    create: (data: any) =>
      request<any>('/api/v1/admin/notifications', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
  },

  // ===== 公告管理 =====
  announcements: {
    // 用户端
    list: () =>
      request<any[]>('/api/v1/announcements'),

    get: (id: string) =>
      request<any>(`/api/v1/announcements/${id}`),

    // 管理员端
    listAll: (params?: { page?: number; limit?: number }) => {
      const query = new URLSearchParams();
      if (params?.page) query.set('page', params.page.toString());
      if (params?.limit) query.set('limit', params.limit.toString());
      return request<any>(`/api/v1/admin/announcements?${query}`);
    },

    create: (data: any) =>
      request<any>('/api/v1/admin/announcements', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    update: (id: string, data: any) =>
      request<any>(`/api/v1/admin/announcements/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      }),

    delete: (id: string) =>
      request<void>(`/api/v1/admin/announcements/${id}`, {
        method: 'DELETE',
      }),
  },

  // ===== 验证码 =====
  captcha: {
    getConfig: () =>
      request<{
        enabled: boolean;
        type: string;
        enable_login: boolean;
        enable_register: boolean;
        turnstile_site_key: string;
      }>('/api/v1/captcha/config'),

    getImage: () =>
      request<{ captcha_id: string; image_data: string }>('/api/v1/captcha/image'),

    verify: (captchaId: string, code: string) =>
      request<{ valid: boolean }>('/api/v1/captcha/verify', {
        method: 'POST',
        body: JSON.stringify({ captcha_id: captchaId, code }),
      }),
  },

  // ===== 系统设置（管理员）=====
  settings: {
    // 验证码设置
    getCaptchaSettings: () =>
      request<any>('/api/v1/admin/settings/captcha'),

    updateCaptchaSettings: (data: any) =>
      request<any>('/api/v1/admin/settings/captcha', {
        method: 'PUT',
        body: JSON.stringify(data),
      }),
    
    // 通用设置
    getGeneralSettings: () =>
      request<any>('/api/v1/admin/settings/general'),
    
    updateGeneralSettings: (data: any) =>
      request<any>('/api/v1/admin/settings/general', {
        method: 'PUT',
        body: JSON.stringify(data),
      }),
    
    // 安全设置
    getSecuritySettings: () =>
      request<any>('/api/v1/admin/settings/security'),
    
    updateSecuritySettings: (data: any) =>
      request<any>('/api/v1/admin/settings/security', {
        method: 'PUT',
        body: JSON.stringify(data),
      }),
    
    // 通知设置
    getNotificationSettings: () =>
      request<any>('/api/v1/admin/settings/notification'),
    
    updateNotificationSettings: (data: any) =>
      request<any>('/api/v1/admin/settings/notification', {
        method: 'PUT',
        body: JSON.stringify(data),
      }),
  },

  // ===== 管理员统计 =====
  adminStats: {
    overview: () =>
      request<any>('/api/v1/admin/statistics/overview'),
  },

  // ===== 流量统计 =====
  trafficStats: {
    list: (params?: { tunnel_id?: string; page?: number; limit?: number }) => {
      const query = new URLSearchParams();
      if (params?.tunnel_id) query.set('tunnel_id', params.tunnel_id);
      if (params?.page) query.set('page', params.page.toString());
      if (params?.limit) query.set('limit', params.limit.toString());
      return request<any>(`/api/v1/traffic/stats?${query}`);
    },

    getSummary: (params?: { tunnel_id?: string; start_date?: string; end_date?: string }) => {
      const query = new URLSearchParams();
      if (params?.tunnel_id) query.set('tunnel_id', params.tunnel_id);
      if (params?.start_date) query.set('start_date', params.start_date);
      if (params?.end_date) query.set('end_date', params.end_date);
      return request<any>(`/api/v1/traffic/summary?${query}`);
    },
  },
};

