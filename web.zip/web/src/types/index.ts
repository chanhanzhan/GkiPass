/**
 * 全局类型定义
 */

// ===== 用户相关 =====
export interface User {
  id: string;
  username: string;
  role: string;
  is_admin: boolean;
  email?: string;
  created_at?: string;
  last_login?: string;
  enabled?: boolean;
  provider?: string;
}

export interface UserPermissions {
  user_id: string;
  role: string;
  admin: boolean;
  can_access_admin_panel: boolean;
  permissions: {
    user?: Record<string, boolean>;
    node?: Record<string, boolean>;
    tunnel?: Record<string, boolean>;
    plan?: Record<string, boolean>;
    announcement?: Record<string, boolean>;
    settings?: Record<string, boolean>;
    statistics?: Record<string, boolean>;
    profile?: Record<string, boolean>;
    wallet?: Record<string, boolean>;
    subscription?: Record<string, boolean>;
  };
}

export interface UserInfo {
  id: string;
  username: string;
  email: string;
  role: string;
  is_admin: boolean;
  enabled: boolean;
  provider: string;
  created_at: string;
  last_login: string | null;
  subscription: {
    id: string;
    plan_id: string;
    status: string;
    start_at: string;
    expires_at: string;
    traffic: number;
    used_traffic: number;
    max_tunnels: number;
    max_bandwidth: number;
  } | null;
  wallet: {
    id: string;
    balance: number;
    frozen: number;
  };
  permissions: string[];
}

// ===== 节点相关 =====
export type NodeType = 'entry' | 'exit';

export interface Node {
  id: string;
  uuid: string;
  name: string;
  type: NodeType;
  group_id: string;
  ip: string;
  port: number;
  status: 'online' | 'offline';
  connection_key?: string;
  cert_id?: string;
  created_at: string;
  updated_at: string;
}

export interface NodeStatus {
  online: boolean;
  cpu_usage: number;
  memory_usage: number;
  connections: number;
  last_heartbeat: string;
}

export interface NodeGroup {
  id: string;
  name: string;
  type: NodeType;
  description?: string;
  node_count: number;
  created_at: string;
}

// ===== 隧道相关 =====
export type TunnelProtocol = 'tcp' | 'udp' | 'http' | 'https' | 'socks';

export interface TunnelTarget {
  host: string;
  port: number;
  weight: number;
}

export interface Tunnel {
  id: string;
  user_id: string;
  name: string;
  description?: string;
  protocol: TunnelProtocol;
  entry_group_id: string;
  exit_group_id: string;
  local_port: number;
  targets: TunnelTarget[];
  enabled: boolean;
  max_bandwidth?: number;
  traffic_used: number;
  connections: number;
  created_at: string;
  updated_at: string;
}

// ===== 套餐相关 =====
export interface Plan {
  id: string;
  name: string;
  description?: string;
  price: number;
  billing_cycle: 'monthly' | 'yearly' | 'lifetime';
  max_rules: number;
  max_traffic: number;
  max_bandwidth: number;
  max_connections: number;
  allowed_nodes?: string[];
  enabled: boolean;
  is_default?: boolean;
  created_at: string;
}

export interface Subscription {
  id: string;
  user_id: string;
  plan_id: string;
  plan: Plan;
  status: 'active' | 'expired' | 'cancelled';
  used_rules: number;
  used_traffic: number;
  used_bandwidth: number;
  used_connections: number;
  start_date: string;
  end_date: string;
  created_at: string;
}

// ===== 统计相关 =====
export interface StatisticsOverview {
  total_tunnels: number;
  active_tunnels: number;
  total_nodes: number;
  online_nodes: number;
  total_traffic: number;
  traffic_today: number;
  traffic_history: Array<{
    date: string;
    upload: number;
    download: number;
  }>;
}

// ===== WebSocket 消息 =====
export interface WSMessage {
  type: string;
  timestamp: string;
  data: unknown;
}

// ===== API 响应 =====
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  total_pages: number;
}

// ===== 设置相关 =====
export interface GeneralSettings {
  site_name: string;
  site_description: string;
  site_logo: string;
  allow_register: boolean;
  require_email_verification: boolean;
}

export interface SecuritySettings {
  password_min_length: number;
  password_require_uppercase: boolean;
  password_require_lowercase: boolean;
  password_require_number: boolean;
  password_require_special: boolean;
  login_max_attempts: number;
  login_lockout_duration: number;
  enable_2fa: boolean;
  session_timeout: number;
}

export interface CaptchaSettings {
  enabled: boolean;
  type: string;
  site_key: string;
  secret_key: string;
  image_width: number;
  image_height: number;
  code_length: number;
}

export interface NotificationSettings {
  email_enabled: boolean;
  email_host: string;
  email_port: number;
  email_username: string;
  email_password: string;
  email_from: string;
  system_notify_enabled: boolean;
  webhook_enabled: boolean;
  webhook_url: string;
  notify_on_user_register: boolean;
  notify_on_payment: boolean;
  notify_on_node_offline: boolean;
}


















